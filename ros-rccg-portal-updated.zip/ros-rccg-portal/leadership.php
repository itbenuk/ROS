<?php
require_once __DIR__ . '/config/config.php';
$pageTitle = 'Our Leadership';

$pdo = getDB();
$allProfiles = get_leadership_profiles($pdo, true);
$facultyLeaders = get_public_faculty($pdo);

// Split the admin-managed leadership_profiles into the two page sections:
// General Overseer & Wife stays its own section at the top, everything
// else admin-managed (Parish Pastor, his wife, and any "Other" leaders
// added later) forms the ROS Leadership team.
$goSection = array_values(array_filter($allProfiles, fn($p) => in_array($p['category'], ['general_overseer', 'overseer_wife'], true)));
$rosSection = array_values(array_filter($allProfiles, fn($p) => in_array($p['category'], ['parish_pastor', 'pastor_wife', 'other'], true)));

/**
 * Render a "read more" biography block. Bios longer than the truncate
 * length are collapsed by default with a Bootstrap collapse toggle - no
 * custom JS needed, matching the rest of the app's use of Bootstrap.
 */
function render_bio_with_readmore(?string $bio, string $collapseId): void
{
    $bio = trim((string) $bio);
    if ($bio === '') return;
    $limit = 140;

    if (strlen($bio) <= $limit) {
        echo '<p class="small bio-text mb-0">' . nl2br(e($bio)) . '</p>';
        return;
    }

    $short = rtrim(substr($bio, 0, $limit));
    ?>
    <p class="small bio-text mb-1"><?= nl2br(e($short)) ?>&hellip;</p>
    <div class="collapse" id="<?= e($collapseId) ?>">
      <p class="small bio-text mb-1"><?= nl2br(e(substr($bio, $limit))) ?></p>
    </div>
    <a class="bio-toggle-link collapsed" data-bs-toggle="collapse" href="#<?= e($collapseId) ?>" role="button"
       aria-expanded="false" aria-controls="<?= e($collapseId) ?>">
      <span class="link-more">Read more <i class="fa-solid fa-chevron-down small"></i></span>
      <span class="link-less">Read less <i class="fa-solid fa-chevron-up small"></i></span>
    </a>
    <?php
}

/** Render one leadership/faculty profile card. $photoUrl is a fully-built media.php URL. */
function render_leader_card(string $name, string $title, ?string $bio, ?string $photoUrl, string $collapseId, ?string $badge = null): void
{
    ?>
    <div class="col-md-6 col-lg-3">
      <div class="feature-card p-3 h-100 text-center d-flex flex-column">
        <div class="leader-photo-frame">
          <?php if ($photoUrl): ?>
            <img src="<?= e($photoUrl) ?>" alt="<?= e($name) ?>">
          <?php else: ?>
            <i class="fa-solid fa-circle-user fa-6x"></i>
          <?php endif; ?>
        </div>
        <?php if ($badge): ?>
          <span class="badge text-bg-light mb-2 align-self-center text-uppercase small"><?= e($badge) ?></span>
        <?php endif; ?>
        <h5 class="mb-1"><?= e($name) ?></h5>
        <p class="text-gold fw-semibold small mb-3"><?= e($title) ?></p>
        <?php render_bio_with_readmore($bio, $collapseId); ?>
      </div>
    </div>
    <?php
}

include __DIR__ . '/includes/header.php';
?>
<style>
/* Swap the two labels on a read-more link when its collapse is open/closed. */
.bio-toggle-link .link-less { display: none; }
.bio-toggle-link[aria-expanded="true"] .link-more { display: none; }
.bio-toggle-link[aria-expanded="true"] .link-less { display: inline; }
</style>
<div class="container py-5">
  <h1 class="section-title text-center mx-auto" style="border-left:none; border-top:4px solid var(--gold); display:inline-block; padding-left:0; padding-top:10px;">Our Leadership</h1>
  <p class="text-center text-muted col-lg-7 mx-auto mb-4">Meet the shepherds and the team guiding our church and this institution.</p>

  <nav class="leadership-subnav">
    <a class="nav-link" href="#general-overseer-wife"><i class="fa-solid fa-cross me-1"></i>General Overseer &amp; Wife</a>
    <a class="nav-link" href="#ros-leadership"><i class="fa-solid fa-people-roof me-1"></i>ROS Leadership</a>
    <a class="nav-link" href="#faculty-members"><i class="fa-solid fa-chalkboard-user me-1"></i>Faculty Members</a>
  </nav>

  <!-- ===================== General Overseer & Wife ===================== -->
  <section id="general-overseer-wife" class="mb-5 pb-2">
    <h2 class="h4 fw-bold text-center mb-4" style="color:var(--deep-green);">General Overseer &amp; Wife</h2>

    <?php if (!$goSection): ?>
      <div class="empty-state"><i class="fa-solid fa-cross"></i><p>This profile will be published here shortly.</p></div>
    <?php else: ?>
    <div class="row g-4 justify-content-center">
      <?php foreach ($goSection as $p):
        $photoUrl = $p['photo'] ? BASE_URL . '/media.php?type=leadership&file=' . urlencode($p['photo']) : null;
        render_leader_card($p['full_name'], $p['title'], $p['bio'], $photoUrl, 'bio-leader-' . (int) $p['id'], leadership_category_label($p['category']));
      endforeach; ?>
    </div>
    <?php endif; ?>
  </section>

  <!-- ===================== ROS Leadership ===================== -->
  <section id="ros-leadership" class="mb-5 pb-2">
    <h2 class="h4 fw-bold text-center mb-2" style="color:var(--deep-green);">ROS Leadership</h2>
    <p class="text-center text-muted small col-lg-6 mx-auto mb-4">The ROS leadership team.</p>

    <?php if (!$rosSection): ?>
      <div class="empty-state"><i class="fa-solid fa-people-roof"></i><p>Leadership team profiles will be published here shortly.</p></div>
    <?php else: ?>
    <div class="row g-4 justify-content-center">
      <?php foreach ($rosSection as $p):
        $photoUrl = $p['photo'] ? BASE_URL . '/media.php?type=leadership&file=' . urlencode($p['photo']) : null;
        render_leader_card($p['full_name'], $p['title'], $p['bio'], $photoUrl, 'bio-leader-' . (int) $p['id'], leadership_category_label($p['category']));
      endforeach; ?>
    </div>
    <?php endif; ?>
  </section>

  <!-- ===================== Faculty Members ===================== -->
  <section id="faculty-members" class="pt-3">
    <h2 class="h4 fw-bold text-center mb-2" style="color:var(--deep-green);">Faculty Members</h2>
    <p class="text-center text-muted small col-lg-6 mx-auto mb-4">Faculty members and their profiles.</p>

    <?php if (!$facultyLeaders): ?>
      <div class="empty-state"><i class="fa-solid fa-chalkboard-user"></i><p>Faculty profiles will be published here shortly.</p></div>
    <?php else: ?>
    <div class="row g-4 justify-content-center">
      <?php foreach ($facultyLeaders as $f):
        $photoUrl = $f['photo'] ? BASE_URL . '/media.php?type=faculty&id=' . (int) $f['id'] : null;
        $name = trim($f['title'] . ' ' . $f['first_name'] . ' ' . $f['last_name']);
        render_leader_card($name, $f['staff_id'], $f['bio'], $photoUrl, 'bio-faculty-' . (int) $f['id'], $f['department'] ?: null);
      endforeach; ?>
    </div>
    <?php endif; ?>
  </section>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
