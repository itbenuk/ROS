<?php
require_once __DIR__ . '/config/config.php';
$pageTitle = 'Home';

$pdo = getDB();
$stats = [
    'students'  => $pdo->query("SELECT COUNT(*) c FROM students")->fetch()['c'],
    'faculty'   => $pdo->query("SELECT COUNT(*) c FROM faculty")->fetch()['c'],
    'materials' => $pdo->query("SELECT COUNT(*) c FROM materials WHERE status='published'")->fetch()['c'],
    'courses'   => $pdo->query("SELECT COUNT(*) c FROM courses WHERE is_active=1")->fetch()['c'],
];

$openBatches = get_open_enrollment_batches($pdo);

include __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <div class="container position-relative text-center">
    <h1>ROS RCCG Student Registration &amp;<br>Faculty Learning Management Portal</h1>
    <p class="lead col-lg-8 mx-auto mt-3">Register for training programmes, access learning materials from our faculty,
      track announcements, and grow in ministry &mdash; all in one secure academic portal.</p>
  </div>
</section>

<div class="container">
  <div class="row g-4 text-center" style="margin-top:-60px;">
    <?php
    $cards = [
      ['icon'=>'fa-user-graduate','label'=>'Registered Students','value'=>$stats['students']],
      ['icon'=>'fa-chalkboard-user','label'=>'Faculty Members','value'=>$stats['faculty']],
      ['icon'=>'fa-book-open','label'=>'Learning Materials','value'=>$stats['materials']],
      ['icon'=>'fa-graduation-cap','label'=>'Active Programmes','value'=>$stats['courses']],
    ];
    foreach ($cards as $c): ?>
    <div class="col-6 col-lg-3">
      <div class="stat-card h-100">
        <div class="stat-icon bg-deepgreen mx-auto mb-2"><i class="fa-solid <?= $c['icon'] ?>"></i></div>
        <div class="stat-value"><?= (int)$c['value'] ?></div>
        <div class="stat-label"><?= e($c['label']) ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Portal Access: Student / Faculty / Admin, each with a description and its own login button -->
<div class="container py-5 mt-4">
  <h2 class="section-title text-center mx-auto" style="border-left:none; border-top:4px solid var(--gold); display:inline-block; padding-left:0; padding-top:10px;">Access Your Portal</h2>
  <p class="text-center text-muted mb-4">Choose the portal that matches your role to sign in.</p>
  <div class="row g-4">
    <div class="col-md-4">
      <div class="feature-card p-4 h-100 d-flex flex-column text-center">
        <div class="icon-wrap mx-auto mb-3"><i class="fa-solid fa-user-graduate"></i></div>
        <h5>Student Portal</h5>
        <p class="text-muted mb-4">Access your learning materials, tests and results.<br>Track your training progress and timetable anytime.</p>
        <a href="<?= BASE_URL ?>/student-login.php" class="btn btn-gold mt-auto"><i class="fa-solid fa-right-to-bracket me-2"></i>Student Login</a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="feature-card p-4 h-100 d-flex flex-column text-center">
        <div class="icon-wrap mx-auto mb-3"><i class="fa-solid fa-chalkboard-user"></i></div>
        <h5>Faculty Portal</h5>
        <p class="text-muted mb-4">Upload materials, manage tests and track student engagement.<br>Publish announcements to your students.</p>
        <a href="<?= BASE_URL ?>/faculty-login.php" class="btn btn-gold mt-auto"><i class="fa-solid fa-right-to-bracket me-2"></i>Faculty Login</a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="feature-card p-4 h-100 d-flex flex-column text-center">
        <div class="icon-wrap mx-auto mb-3"><i class="fa-solid fa-shield-halved"></i></div>
        <h5>Admin Portal</h5>
        <p class="text-muted mb-4">Manage students, faculty, courses and batches.<br>Oversee tests, reports and system settings.</p>
        <a href="<?= BASE_URL ?>/admin-login.php" class="btn btn-gold mt-auto"><i class="fa-solid fa-right-to-bracket me-2"></i>Admin Login</a>
      </div>
    </div>
  </div>
</div>

<?php if ($openBatches): ?>
<!-- Enrol Now: only rendered when at least one batch is genuinely open for enrollment -->
<div class="container pb-5">
  <h2 class="section-title">New Batch Enrolling Now</h2>
  <div class="row g-4">
    <?php foreach ($openBatches as $b): ?>
      <div class="col-md-6 col-lg-4">
        <div class="card p-4 h-100 d-flex flex-column">
          <span class="badge badge-active align-self-start px-3 py-2 mb-2"><i class="fa-solid fa-circle-check me-1"></i>Enrollment Open</span>
          <h5 class="mb-1"><?= e($b['name']) ?></h5>
          <p class="text-muted small mb-3"><?= e($b['batch_code']) ?></p>
          <ul class="list-unstyled small mb-4">
            <li class="mb-1"><i class="fa-solid fa-book text-gold me-2"></i><?= e($b['course_name'] ?? 'General Programme') ?></li>
            <?php if ($b['training_start_date']): ?>
              <li class="mb-1"><i class="fa-solid fa-calendar text-gold me-2"></i>Starts <?= date('M j, Y', strtotime($b['training_start_date'])) ?></li>
            <?php endif; ?>
          </ul>
          <a href="<?= BASE_URL ?>/student-register.php?batch_id=<?= (int)$b['id'] ?>" class="btn btn-gold mt-auto"><i class="fa-solid fa-pen-to-square me-2"></i>Enrol Now</a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<div class="container py-5 mt-4">
  <h2 class="section-title">What You Can Do Here</h2>
  <div class="row g-4">
    <?php
    $features = [
      ['icon'=>'fa-file-signature','title'=>'Easy Registration','text'=>'Complete your student registration online with secure, validated forms.'],
      ['icon'=>'fa-book','title'=>'Learning Materials','text'=>'Access notes, videos, audio sermons and e-books uploaded by faculty.'],
      ['icon'=>'fa-bullhorn','title'=>'Announcements','text'=>'Stay updated with the latest news and notices from the institution.'],
      ['icon'=>'fa-shield-halved','title'=>'Secure Access','text'=>'Role-based portals for students, faculty and administrators.'],
      ['icon'=>'fa-chart-line','title'=>'Track Progress','text'=>'Faculty can track downloads and engagement with their materials.'],
      ['icon'=>'fa-mobile-screen','title'=>'Mobile Friendly','text'=>'Fully responsive design that works on phones, tablets and desktops.'],
    ];
    foreach ($features as $f): ?>
    <div class="col-md-6 col-lg-4">
      <div class="feature-card p-4">
        <div class="icon-wrap mb-3"><i class="fa-solid <?= $f['icon'] ?>"></i></div>
        <h5><?= e($f['title']) ?></h5>
        <p class="text-muted mb-0"><?= e($f['text']) ?></p>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
