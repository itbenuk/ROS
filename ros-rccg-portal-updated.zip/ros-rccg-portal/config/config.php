<?php
/**
 * Global bootstrap file. Included at the top of every page.
 * Handles: secure session start, error display policy, timezone, includes.
 */

// --- Error handling: never show raw errors to users in production ---
error_reporting(E_ALL);
ini_set('display_errors', '0');      // set to '1' only in local dev if needed
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../error.log');

date_default_timezone_set('Africa/Lagos');

// --- Secure session configuration (must run before session_start) ---
if (session_status() === PHP_SESSION_NONE) {
    $secure = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $secure,   // true when served over HTTPS
        'httponly' => true,      // no JS access to session cookie
        'samesite' => 'Lax',
    ]);
    ini_set('session.use_strict_mode', '1');
    session_name('ROSRCCG_SESSID');
    session_start();
}

require_once __DIR__ . '/constants.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// --- Idle session timeout ---
if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_LIFETIME) {
        session_unset();
        session_destroy();
        header('Location: ' . BASE_URL . '/student-login.php?expired=1');
        exit;
    }
    $_SESSION['last_activity'] = time();
}
