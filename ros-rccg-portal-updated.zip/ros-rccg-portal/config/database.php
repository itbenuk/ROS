<?php
/**
 * Database connection (PDO, MySQL 8+)
 * Edit the constants below to match your environment.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'ros_rccg_portal');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // real prepared statements
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Never leak DB details to the browser.
            error_log('DB Connection Error: ' . $e->getMessage());
            http_response_code(500);
            die('A system error occurred. Please try again later.');
        }
    }

    return $pdo;
}
