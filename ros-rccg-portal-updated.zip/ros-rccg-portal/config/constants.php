<?php
/**
 * Application constants.
 */

// Base URL - auto-detected from where this project actually lives on the
// server, so it keeps working no matter what you name the folder or where
// you place it (root of the domain, a subfolder, XAMPP/WAMP/LAMP, etc.).
// If auto-detection ever gives the wrong value on your host, you can
// override it by hardcoding a string here instead, e.g.:
//   define('BASE_URL', '/ros-rccg-portal');
if (!defined('BASE_URL')) {
    $__projectRoot = str_replace('\\', '/', realpath(dirname(__DIR__)));
    $__docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])) : false;

    if ($__projectRoot && $__docRoot && strpos($__projectRoot, $__docRoot) === 0) {
        $__base = substr($__projectRoot, strlen($__docRoot));
        $__base = '/' . ltrim($__base, '/');
        $__base = rtrim($__base, '/');
    } else {
        // Fallback if DOCUMENT_ROOT isn't available (e.g. some CLI/proxy setups)
        $__base = '';
    }
    define('BASE_URL', $__base);
    unset($__projectRoot, $__docRoot, $__base);
}

define('APP_NAME', 'ROS RCCG Portal');

// Absolute filesystem path to project root
define('ROOT_PATH', dirname(__DIR__));

// Uploads live OUTSIDE the web root's executable reach is ideal; here we keep
// them inside /uploads but block PHP execution via .htaccess and always
// stream files through a controller script rather than direct linking.
define('UPLOAD_MATERIALS_PATH', ROOT_PATH . '/uploads/materials/');
define('UPLOAD_PASSPORTS_PATH', ROOT_PATH . '/uploads/passports/');
define('UPLOAD_LEADERSHIP_PATH', ROOT_PATH . '/uploads/leadership/');

define('MAX_UPLOAD_BYTES', 25 * 1024 * 1024); // 25 MB default, overridden by system_settings
define('MAX_PASSPORT_BYTES', 2 * 1024 * 1024); // 2 MB
define('MAX_LEADERSHIP_PHOTO_BYTES', 3 * 1024 * 1024); // 3 MB

// Allowed material file types => allowed MIME types (never trust extension alone)
define('ALLOWED_MATERIAL_TYPES', [
    'pdf'  => ['application/pdf'],
    'doc'  => ['application/msword'],
    'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
    'ppt'  => ['application/vnd.ms-powerpoint'],
    'pptx' => ['application/vnd.openxmlformats-officedocument.presentationml.presentation'],
    'zip'  => ['application/zip', 'application/x-zip-compressed'],
    'mp4'  => ['video/mp4'],
    'mov'  => ['video/quicktime'],
    'mp3'  => ['audio/mpeg'],
    'wav'  => ['audio/wav', 'audio/x-wav'],
    'jpg'  => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png'  => ['image/png'],
]);

define('ALLOWED_PASSPORT_TYPES', [
    'jpg'  => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png'  => ['image/png'],
]);

define('ALLOWED_LEADERSHIP_PHOTO_TYPES', [
    'jpg'  => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png'  => ['image/png'],
]);

// Session / cookie lifetime (seconds)
define('SESSION_LIFETIME', 60 * 60 * 2); // 2 hours idle timeout

// Login throttling
define('MAX_FAILED_LOGINS', 5);
define('LOCKOUT_MINUTES', 15);
