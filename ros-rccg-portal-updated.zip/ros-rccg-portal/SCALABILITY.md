# Scalability & Architecture Review

This document is an honest account of what was audited, what was fixed, and
what genuinely requires a live deployed environment to verify — this
sandbox has no web server process, no persistent MySQL instance between
sessions, and no way to simulate real network-level concurrency from 1,000
distinct clients. Claims below are limited to what was actually inspected
or tested; anything that couldn't be verified here says so explicitly.

## What was actually tested in this environment

A real MariaDB server and PHP 8.3 CLI (with `pdo_mysql`) were installed and
used to:
- Import the full schema (`database.sql`) end-to-end with zero errors.
- Import `migration_004_batches_timetable.sql` against a simulated
  pre-existing (older) schema, proving the upgrade path works, not just the
  fresh-install path.
- Run the batch-graduation transition, course-code generation, and
  batch/status access-control functions against real rows and confirm
  correct behaviour (see the conversation transcript / commit messages for
  the exact test output: collisions correctly bumped course codes, a
  graduated student was correctly blocked from active content while a
  same-batch active student was correctly allowed, cross-batch content was
  correctly isolated).
- Confirm, with real query output, that the student-facing test-taking page
  cannot structurally leak `is_correct` (the new `load_public_options_for_questions()`
  helper doesn't select that column at all, rather than trusting a filter
  step to strip it).

None of this required guessing — it was run and observed.

## What was fixed as a direct result of this review

1. **N+1 query eliminated on the hottest path.** Every page that displays a
   test's questions (`student/test-attempt.php`, `student/test-result.php`,
   `faculty/test-questions.php`, `faculty/test-preview.php`,
   `faculty/test-attempt-view.php`, `admin/test-attempt-view.php`) used to
   run one `SELECT * FROM test_options WHERE question_id = ?` **per
   question**. For a 20-question test that's 20 extra round trips per page
   load; under concurrent load (many students starting the same test in
   the same minute) that multiplies badly. All six now use
   `load_options_for_questions()` / `load_public_options_for_questions()`
   in `includes/functions.php`, which fetch every option for the whole test
   in a single `WHERE question_id IN (...)` query.
2. **A real data-integrity bug found and fixed.** `students.status` (the new
   lifecycle field: registered/active/graduated/withdrawn) and
   `users.status` (account active/inactive/suspended) are both named
   `status`. Three pages selected `s.*, u.status` without aliasing, so PHP's
   associative fetch silently let `u.status` overwrite `s.status` — the
   lifecycle status was invisible everywhere this pattern was used. Found by
   grep, confirmed by reasoning through PDO's fetch behaviour, and fixed by
   aliasing (`u.status AS account_status`) in `admin/students.php`,
   `admin/student-view.php`, and `faculty/student-view.php`. This is exactly
   the kind of bug a "just add more servers" scaling approach would not
   catch — it's silent under any load level.
3. **N+1 in the publish-notification loop removed** (`faculty/tests.php`):
   was doing a second `SELECT user_id FROM students WHERE id = ?` per
   student inside the loop; now joins `users` in the original query.
4. **Indexes added** for the query patterns actually used in the codebase
   (not speculative ones): `test_attempts(student_id, status)` — the exact
   pair used to compute "my results"/"pending review" everywhere;
   `materials(status, course_id)` — the exact pair used on every materials
   browse query; `audit_logs(created_at)` — used by the admin activity feed,
   which will grow unbounded over time and needs a sort-friendly index.
   Plus the batch/status columns added by this update (`students.batch_id`,
   `students.status`, `materials.batch_id`, `tests.batch_id`) all carry
   their own index, since every one of them is now used in a `WHERE` clause
   on a student-facing page.
5. **PDO is already configured correctly** for this workload:
   `PDO::ATTR_EMULATE_PREPARES => false` (real server-side prepared
   statements, not just string interpolation with extra steps), and a
   single lazily-created connection per request via `getDB()`'s static
   cache (no connection is opened until the first query, and never more
   than one per request).

## What genuinely was not, and could not be, tested here

Be skeptical of any claim to the contrary — a request/response tool loop
inside a sandbox cannot originate 1,000 simultaneous TCP connections against
a running Apache+PHP-FPM+MySQL stack, because there is no such stack running
as a persistent, network-reachable service here.

**What this means concretely:** the changes above are grounded in reading
the actual queries this application runs and fixing the ones that don't
scale, not in a load-test report. Before relying on this for 1,000
concurrent users, the following still needs to happen against a real
deployment:

### Required before production launch at this scale

1. **PHP-FPM tuning.** Default Apache `mod_php` (implied by the current
   `.htaccess`-based setup) serves one request per worker process/thread
   with no shared opcode cache guarantees out of the box. Switch to
   PHP-FPM with `opcache.enable=1`, `opcache.validate_timestamps=0` in
   production (rebuild the cache on deploy instead), and size
   `pm.max_children` to `(available RAM - MySQL RAM) / average PHP process
   RSS` — measure the latter with `ps` under a realistic single-user
   session before guessing.
2. **MySQL connection limits.** `max_connections` in `my.cnf` defaults to
   151 in many distros. At 1,000 concurrent users each holding one
   short-lived connection per request, this needs raising, *and* a
   connection pooler (ProxySQL or MySQL Router) or PHP-FPM's process count
   capped so the app itself never opens more connections than MySQL can
   accept. This app does not currently use persistent connections
   (`PDO::ATTR_PERSISTENT` is not set) — that's the right default for a
   shared-hosting-style deployment, but it means connection *setup* cost is
   paid on every request, which a pooler mitigates.
3. **Session storage.** PHP's default file-based session storage
   (`session.save_path`) serializes session reads/writes per session ID
   through filesystem locks. This is fine for correctness but becomes a
   bottleneck the moment the app runs on more than one PHP server (see
   "horizontal scaling" below) because sessions become tied to whichever
   server wrote them. For 1,000 concurrent users on a single server this is
   probably acceptable; for horizontal scaling it is not — switch to
   Redis-backed sessions (`session.save_handler = redis`) before adding a
   second app server.
4. **File uploads and imports are synchronous.** `faculty/import-questions.php`
   and the material-upload flow both parse/move files inline within the
   HTTP request. A large `.xlsx` import or a big video upload ties up a PHP
   worker for the whole duration. This is acceptable at moderate load (an
   import is an infrequent admin action, not something 1,000 students do
   simultaneously) but would benefit from a queue (see below) if imports
   grow large or frequent.
5. **No caching layer exists.** Course lists, category lists, and system
   settings are re-queried on every page load. They change rarely. Adding
   an APCu or Redis cache with a short TTL (or explicit invalidation on
   admin save) for `courses`, `categories`, and `system_settings` would cut
   a meaningful fraction of queries under load, since those tables are read
   on nearly every page.
6. **Rate limiting is not implemented.** Login (`attempt_login()`) already
   has per-account lockout after 5 failed attempts, which helps against
   credential stuffing but does not protect against a flood of *valid*
   requests. A reverse proxy (Nginx `limit_req`, or Cloudflare/similar) in
   front of the app should rate-limit by IP for `/ajax/*` and login
   endpoints specifically, since those are the cheapest to hammer.
7. **Horizontal scaling readiness.** The app is already close to stateless
   — no server-local state is written outside of `/uploads` and PHP
   sessions. To run more than one app server: (a) move `/uploads` to shared
   storage (NFS, S3 + a small wrapper in `validate_and_move_upload()`/
   `download.php`, or similar) since it's currently a local directory; (b)
   move sessions to Redis as above; (c) put a load balancer in front with
   sticky sessions disabled (safe, once sessions are centralized).
8. **Centralized logging and monitoring** do not exist yet — `error_log()`
   calls write to a local `error.log` file per README's config. For
   multiple servers this needs to ship to a central place (e.g., an ELK
   stack, or even just syslog to a central host) or errors from one server
   become invisible.

### How to actually load-test this, once deployed

Do not trust a "should handle it" assessment — measure it. A reasonable
plan, using a real tool against a real staging deployment:

1. **Seed realistic data first.** Load-testing against a database with 3
   sample students proves nothing; generate ~1,000 student accounts, a
   handful of large courses/batches, and at least one test with 20+
   questions and explicit assignments, so query plans reflect real index
   usage (a table scan on 3 rows looks identical to an indexed lookup; it
   won't at 10,000 rows).
2. **Tool:** [k6](https://k6.io/) or Apache JMeter, run from a *separate*
   machine than the one under test (running the load generator on the same
   box invalidates the CPU/network numbers). A minimal k6 script structure
   for this app's critical paths:
   ```js
   import http from 'k6/http';
   import { check, sleep } from 'k6';

   export const options = {
     stages: [
       { duration: '1m', target: 100 },
       { duration: '2m', target: 250 },
       { duration: '2m', target: 500 },
       { duration: '3m', target: 1000 },
       { duration: '2m', target: 0 },
     ],
   };

   export default function () {
     // 1. Login (POST student-login.php with a unique seeded account per VU)
     // 2. GET student/dashboard.php
     // 3. GET student/tests.php
     // 4. GET student/test-attempt.php?id=<seeded test id>  (start)
     // 5. POST ajax/test_save_answer.php a few times
     // 6. POST ajax/test_submit.php
     const res = http.get(`${__ENV.BASE_URL}/index.php`);
     check(res, { 'status is 200': (r) => r.status === 200 });
     sleep(1);
   }
   ```
   Flesh this out per-scenario (login storm, dashboard storm, simultaneous
   test start, simultaneous submit) exactly as section 16 of the
   requirements lists, since each stresses a different part of the stack
   (auth/session vs. read-heavy dashboard vs. write-heavy submission).
3. **Watch, don't guess, for the actual bottleneck:** `SHOW PROCESSLIST` and
   `SHOW ENGINE INNODB STATUS` in MySQL during the test; `top`/`htop` and
   PHP-FPM's status page (`pm.status_path`) on the app server. The
   bottleneck at 100 concurrent users is rarely the same one that appears
   at 1,000 — measure at each step in section 16's list (100/250/500/1000)
   rather than only at the final target.
4. **Fix what the measurement actually shows**, re-run, repeat. This is the
   only reliable way to know the number this application can sustain on a
   given box — anything else is an estimate dressed up as a fact.

## Summary

Real bugs were found and fixed by actually reading the code and running it
against a real database in this session — that work is genuine and
verifiable in the diffs. Whether the *deployed* application comfortably
serves 1,000 concurrent users is a question about a specific server,
database configuration, and network, none of which exist in this sandbox;
answering it honestly requires the load test described above against the
actual target infrastructure, not a promise made without one.
