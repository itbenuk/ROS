<?php $current = basename($_SERVER['SCRIPT_NAME']); ?>
<div class="sidebar bg-deepgreen text-white" id="appSidebar">
  <div class="sidebar-header d-flex align-items-center justify-content-between px-3 py-3 border-bottom border-light border-opacity-25">
    <div class="d-flex align-items-center gap-2 overflow-hidden">
      <i class="fa-solid fa-chalkboard-user text-gold flex-shrink-0"></i>
      <span class="fw-semibold sidebar-label">Faculty Panel</span>
    </div>
    <button type="button" class="sidebar-collapse-btn d-none d-lg-flex" id="sidebarCollapseBtn" aria-label="Collapse sidebar" title="Collapse sidebar" onclick="document.querySelector('.dash-wrapper').classList.toggle('sidebar-collapsed'); localStorage.setItem('sidebarCollapsed', document.querySelector('.dash-wrapper').classList.contains('sidebar-collapsed') ? '1' : '0');">
      <i class="fa-solid fa-angles-left"></i>
    </button>
  </div>
  <ul class="nav flex-column py-2">
    <li class="nav-item"><a class="nav-link <?= $current === 'dashboard.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/faculty/dashboard.php" data-bs-toggle="tooltip" data-bs-title="Dashboard"><i class="fa-solid fa-gauge"></i> <span class="sidebar-label">Dashboard</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'profile.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/faculty/profile.php" data-bs-toggle="tooltip" data-bs-title="My Profile"><i class="fa-solid fa-id-card"></i> <span class="sidebar-label">My Profile</span></a></li>
    <li class="nav-item"><a class="nav-link <?= in_array($current, ['students.php','student-view.php']) ? 'active' : '' ?>" href="<?= BASE_URL ?>/faculty/students.php" data-bs-toggle="tooltip" data-bs-title="Students"><i class="fa-solid fa-user-graduate"></i> <span class="sidebar-label">Students</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'courses.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/faculty/courses.php" data-bs-toggle="tooltip" data-bs-title="Courses/Classes"><i class="fa-solid fa-book"></i> <span class="sidebar-label">Courses/Classes</span></a></li>
    <li class="nav-item"><a class="nav-link <?= in_array($current, ['materials.php','upload-material.php','edit-material.php']) ? 'active' : '' ?>" href="<?= BASE_URL ?>/faculty/materials.php" data-bs-toggle="tooltip" data-bs-title="Manage Materials"><i class="fa-solid fa-folder-open"></i> <span class="sidebar-label">Manage Materials</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'upload-material.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/faculty/upload-material.php" data-bs-toggle="tooltip" data-bs-title="Upload Material"><i class="fa-solid fa-cloud-arrow-up"></i> <span class="sidebar-label">Upload Material</span></a></li>
    <li class="nav-item"><a class="nav-link <?= in_array($current, ['tests.php','test-form.php','test-questions.php','test-preview.php']) ? 'active' : '' ?>" href="<?= BASE_URL ?>/faculty/tests.php" data-bs-toggle="tooltip" data-bs-title="Tests"><i class="fa-solid fa-file-pen"></i> <span class="sidebar-label">Tests</span></a></li>
    <li class="nav-item"><a class="nav-link <?= in_array($current, ['test-results.php','test-attempt-view.php']) ? 'active' : '' ?>" href="<?= BASE_URL ?>/faculty/tests.php" data-bs-toggle="tooltip" data-bs-title="Results/Analytics"><i class="fa-solid fa-chart-simple"></i> <span class="sidebar-label">Results/Analytics</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'timetable.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/faculty/timetable.php" data-bs-toggle="tooltip" data-bs-title="Timetable"><i class="fa-solid fa-calendar-days"></i> <span class="sidebar-label">Timetable</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'announcements.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/faculty/announcements.php" data-bs-toggle="tooltip" data-bs-title="Announcements"><i class="fa-solid fa-bullhorn"></i> <span class="sidebar-label">Announcements</span></a></li>
    <li class="nav-item sidebar-logout-item">
      <form method="post" action="<?= BASE_URL ?>/logout.php">
        <?= csrf_field() ?>
        <button class="nav-link w-100 text-start border-0 bg-transparent" type="submit" data-bs-toggle="tooltip" data-bs-title="Logout"><i class="fa-solid fa-right-from-bracket"></i> <span class="sidebar-label">Logout</span></button>
      </form>
    </li>
  </ul>
</div>
