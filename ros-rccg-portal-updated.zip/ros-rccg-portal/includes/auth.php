<?php
/**
 * Authentication & Role-Based Authorization
 *
 * Every protected page MUST call require_role() (or require_login())
 * as the very first thing after config.php is included.
 */

function current_user(): ?array
{
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    return [
        'id'    => $_SESSION['user_id'],
        'role'  => $_SESSION['user_role'],
        'email' => $_SESSION['user_email'],
        'name'  => $_SESSION['user_name'] ?? '',
        'ref_id'=> $_SESSION['ref_id'] ?? null, // students.id or faculty.id
    ];
}

function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

function require_login(): void
{
    if (!is_logged_in()) {
        flash('warning', 'Your session has expired. Please log in again.');
        redirect('/student-login.php');
    }
}

/**
 * Restrict a page to one or more roles. Redirects unauthenticated users to
 * login, and shows a 403 to authenticated users with the wrong role.
 */
function require_role($roles): void
{
    if (is_string($roles)) {
        $roles = [$roles];
    }

    if (!is_logged_in()) {
        $loginPage = in_array('admin', $roles, true) ? '/admin-login.php'
            : (in_array('faculty', $roles, true) ? '/faculty-login.php' : '/student-login.php');
        redirect($loginPage);
    }

    if (!in_array($_SESSION['user_role'], $roles, true)) {
        http_response_code(403);
        die('<h2 style="font-family:sans-serif;text-align:center;margin-top:80px;">403 &mdash; Unauthorized Access</h2>
             <p style="text-align:center;">You do not have permission to view this page.</p>');
    }

    // Regenerate CSRF token scope check passes silently; nothing else needed here.
}

/**
 * Attempt to log a user in. Implements brute-force lockout.
 * Returns ['success'=>bool,'message'=>string]
 */
function attempt_login(string $email, string $password, string $expectedRole): array
{
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = ? LIMIT 1");
    $stmt->execute([$email, $expectedRole]);
    $user = $stmt->fetch();

    if (!$user) {
        return ['success' => false, 'message' => 'Invalid login credentials.'];
    }

    // Brute-force lockout check
    if (!empty($user['locked_until']) && strtotime($user['locked_until']) > time()) {
        $mins = ceil((strtotime($user['locked_until']) - time()) / 60);
        return ['success' => false, 'message' => "Account temporarily locked. Try again in {$mins} minute(s)."];
    }

    if ($user['status'] !== 'active') {
        return ['success' => false, 'message' => 'Your account is inactive. Please contact the administrator.'];
    }

    if (!password_verify($password, $user['password_hash'])) {
        $failed = $user['failed_logins'] + 1;
        $lockedUntil = null;
        if ($failed >= MAX_FAILED_LOGINS) {
            $lockedUntil = date('Y-m-d H:i:s', time() + LOCKOUT_MINUTES * 60);
            $failed = 0;
        }
        $upd = $pdo->prepare("UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?");
        $upd->execute([$failed, $lockedUntil, $user['id']]);
        return ['success' => false, 'message' => 'Invalid login credentials.'];
    }

    // Success: reset throttle counters, update last login
    $pdo->prepare("UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = NOW() WHERE id = ?")
        ->execute([$user['id']]);

    // Fetch profile name + ref id
    $name = $user['email'];
    $refId = null;
    if ($expectedRole === 'student') {
        $s = $pdo->prepare("SELECT id, first_name, last_name FROM students WHERE user_id = ?");
        $s->execute([$user['id']]);
        if ($row = $s->fetch()) {
            $name = $row['first_name'] . ' ' . $row['last_name'];
            $refId = $row['id'];
        }
    } elseif ($expectedRole === 'faculty') {
        $f = $pdo->prepare("SELECT id, first_name, last_name FROM faculty WHERE user_id = ?");
        $f->execute([$user['id']]);
        if ($row = $f->fetch()) {
            $name = $row['first_name'] . ' ' . $row['last_name'];
            $refId = $row['id'];
        }
    } else {
        $name = 'Administrator';
    }

    // Prevent session fixation
    session_regenerate_id(true);

    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_role']  = $user['role'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_name']  = $name;
    $_SESSION['ref_id']     = $refId;
    $_SESSION['last_activity'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // fresh token per session

    audit_log($user['id'], 'login', "Role: {$expectedRole}");

    return ['success' => true, 'message' => 'Login successful.'];
}

function logout_user(): void
{
    $uid = $_SESSION['user_id'] ?? null;
    audit_log($uid, 'logout');

    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_unset();
    session_destroy();
}
