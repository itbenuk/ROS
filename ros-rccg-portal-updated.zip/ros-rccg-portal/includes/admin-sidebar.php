<?php $current = basename($_SERVER['SCRIPT_NAME']); ?>
<div class="sidebar bg-deepgreen text-white" id="appSidebar">
  <div class="sidebar-header d-flex align-items-center justify-content-between px-3 py-3 border-bottom border-light border-opacity-25">
    <div class="d-flex align-items-center gap-2 overflow-hidden">
      <i class="fa-solid fa-shield-halved text-gold flex-shrink-0"></i>
      <span class="fw-semibold sidebar-label">Admin Panel</span>
    </div>
    <button type="button" class="sidebar-collapse-btn d-none d-lg-flex" id="sidebarCollapseBtn" aria-label="Collapse sidebar" title="Collapse sidebar" onclick="document.querySelector('.dash-wrapper').classList.toggle('sidebar-collapsed'); localStorage.setItem('sidebarCollapsed', document.querySelector('.dash-wrapper').classList.contains('sidebar-collapsed') ? '1' : '0');">
      <i class="fa-solid fa-angles-left"></i>
    </button>
  </div>
  <ul class="nav flex-column py-2">
    <li class="nav-item"><a class="nav-link <?= $current === 'dashboard.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/dashboard.php" data-bs-toggle="tooltip" data-bs-title="Dashboard"><i class="fa-solid fa-gauge"></i> <span class="sidebar-label">Dashboard</span></a></li>
    <li class="nav-item"><a class="nav-link <?= in_array($current,['students.php','student-view.php']) ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/students.php" data-bs-toggle="tooltip" data-bs-title="Students"><i class="fa-solid fa-user-graduate"></i> <span class="sidebar-label">Students</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'alumni.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/alumni.php" data-bs-toggle="tooltip" data-bs-title="Alumni"><i class="fa-solid fa-graduation-cap"></i> <span class="sidebar-label">Alumni</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'batches.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/batches.php" data-bs-toggle="tooltip" data-bs-title="Batches"><i class="fa-solid fa-people-group"></i> <span class="sidebar-label">Batches</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'faculty.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/faculty.php" data-bs-toggle="tooltip" data-bs-title="Faculty"><i class="fa-solid fa-chalkboard-user"></i> <span class="sidebar-label">Faculty</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'leadership.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/leadership.php" data-bs-toggle="tooltip" data-bs-title="Leadership"><i class="fa-solid fa-people-roof"></i> <span class="sidebar-label">Leadership</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'courses.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/courses.php" data-bs-toggle="tooltip" data-bs-title="Courses"><i class="fa-solid fa-book"></i> <span class="sidebar-label">Courses</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'categories.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/categories.php" data-bs-toggle="tooltip" data-bs-title="Categories"><i class="fa-solid fa-tags"></i> <span class="sidebar-label">Categories</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'materials.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/materials.php" data-bs-toggle="tooltip" data-bs-title="Materials"><i class="fa-solid fa-folder-open"></i> <span class="sidebar-label">Materials</span></a></li>
    <li class="nav-item"><a class="nav-link <?= in_array($current,['tests.php','test-form.php','test-questions.php','test-preview.php']) ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/tests.php" data-bs-toggle="tooltip" data-bs-title="Tests"><i class="fa-solid fa-file-pen"></i> <span class="sidebar-label">Tests</span></a></li>
    <li class="nav-item"><a class="nav-link <?= in_array($current,['test-results.php','test-attempt-view.php']) ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/tests.php" data-bs-toggle="tooltip" data-bs-title="Test Results"><i class="fa-solid fa-chart-simple"></i> <span class="sidebar-label">Test Results</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'timetable.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/timetable.php" data-bs-toggle="tooltip" data-bs-title="Timetable"><i class="fa-solid fa-calendar-days"></i> <span class="sidebar-label">Timetable</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'announcements.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/announcements.php" data-bs-toggle="tooltip" data-bs-title="Announcements"><i class="fa-solid fa-bullhorn"></i> <span class="sidebar-label">Announcements</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'reports.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/reports.php" data-bs-toggle="tooltip" data-bs-title="Reports"><i class="fa-solid fa-chart-line"></i> <span class="sidebar-label">Reports</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'settings.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/settings.php" data-bs-toggle="tooltip" data-bs-title="Settings"><i class="fa-solid fa-gear"></i> <span class="sidebar-label">Settings</span></a></li>
    <li class="nav-item sidebar-logout-item">
      <form method="post" action="<?= BASE_URL ?>/logout.php">
        <?= csrf_field() ?>
        <button class="nav-link w-100 text-start border-0 bg-transparent" type="submit" data-bs-toggle="tooltip" data-bs-title="Logout"><i class="fa-solid fa-right-from-bracket"></i> <span class="sidebar-label">Logout</span></button>
      </form>
    </li>
  </ul>
</div>
