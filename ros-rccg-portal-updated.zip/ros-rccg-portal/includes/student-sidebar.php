<?php $current = basename($_SERVER['SCRIPT_NAME']); ?>
<div class="sidebar bg-deepgreen text-white" id="appSidebar">
  <div class="sidebar-header d-flex align-items-center justify-content-between px-3 py-3 border-bottom border-light border-opacity-25">
    <div class="d-flex align-items-center gap-2 overflow-hidden">
      <i class="fa-solid fa-graduation-cap text-gold flex-shrink-0"></i>
      <span class="fw-semibold sidebar-label">Student Panel</span>
    </div>
    <button type="button" class="sidebar-collapse-btn d-none d-lg-flex" id="sidebarCollapseBtn" aria-label="Collapse sidebar" title="Collapse sidebar" onclick="document.querySelector('.dash-wrapper').classList.toggle('sidebar-collapsed'); localStorage.setItem('sidebarCollapsed', document.querySelector('.dash-wrapper').classList.contains('sidebar-collapsed') ? '1' : '0');">
      <i class="fa-solid fa-angles-left"></i>
    </button>
  </div>
  <ul class="nav flex-column py-2">
    <li class="nav-item"><a class="nav-link <?= $current === 'dashboard.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/student/dashboard.php" data-bs-toggle="tooltip" data-bs-title="Dashboard"><i class="fa-solid fa-gauge"></i> <span class="sidebar-label">Dashboard</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'profile.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/student/profile.php" data-bs-toggle="tooltip" data-bs-title="My Profile"><i class="fa-solid fa-id-card"></i> <span class="sidebar-label">My Profile</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'courses.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/student/courses.php" data-bs-toggle="tooltip" data-bs-title="My Courses"><i class="fa-solid fa-book"></i> <span class="sidebar-label">My Courses</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'materials.php' || $current === 'material-view.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/student/materials.php" data-bs-toggle="tooltip" data-bs-title="Learning Materials"><i class="fa-solid fa-book-open"></i> <span class="sidebar-label">Learning Materials</span></a></li>
    <li class="nav-item"><a class="nav-link <?= in_array($current, ['tests.php','test-attempt.php']) ? 'active' : '' ?>" href="<?= BASE_URL ?>/student/tests.php" data-bs-toggle="tooltip" data-bs-title="Available Tests"><i class="fa-solid fa-file-pen"></i> <span class="sidebar-label">Available Tests</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'test-result.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/student/tests.php?tab=completed" data-bs-toggle="tooltip" data-bs-title="My Results"><i class="fa-solid fa-square-poll-vertical"></i> <span class="sidebar-label">My Results</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'timetable.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/student/timetable.php" data-bs-toggle="tooltip" data-bs-title="Timetable"><i class="fa-solid fa-calendar-days"></i> <span class="sidebar-label">Timetable</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'announcements.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/student/announcements.php" data-bs-toggle="tooltip" data-bs-title="Announcements"><i class="fa-solid fa-bullhorn"></i> <span class="sidebar-label">Announcements</span></a></li>
    <li class="nav-item"><a class="nav-link <?= $current === 'change-password.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/student/change-password.php" data-bs-toggle="tooltip" data-bs-title="Change Password"><i class="fa-solid fa-key"></i> <span class="sidebar-label">Change Password</span></a></li>
    <li class="nav-item sidebar-logout-item">
      <form method="post" action="<?= BASE_URL ?>/logout.php">
        <?= csrf_field() ?>
        <button class="nav-link w-100 text-start border-0 bg-transparent" type="submit" data-bs-toggle="tooltip" data-bs-title="Logout"><i class="fa-solid fa-right-from-bracket"></i> <span class="sidebar-label">Logout</span></button>
      </form>
    </li>
  </ul>
</div>
