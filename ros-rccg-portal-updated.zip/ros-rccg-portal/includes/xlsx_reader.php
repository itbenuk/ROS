<?php
/**
 * Minimal .xlsx reader.
 *
 * An .xlsx file is a ZIP archive of XML parts. This reader extracts just
 * enough to read a single flat worksheet of text/number cells - exactly
 * what's needed for the question-import template. It intentionally avoids
 * any third-party library (there is no Composer/Packagist access in this
 * environment) and relies only on PHP's built-in ext-zip and SimpleXML.
 *
 * Supports .xlsx only. Legacy binary .xls files are not parsed - callers
 * should ask the user to re-save as .xlsx (Excel: File > Save As > .xlsx).
 */

/** Convert a spreadsheet column letter (A, B, ..., Z, AA, AB, ...) to a 0-based index. */
function xlsx_col_to_index(string $col): int
{
    $col = strtoupper($col);
    $index = 0;
    for ($i = 0; $i < strlen($col); $i++) {
        $index = $index * 26 + (ord($col[$i]) - ord('A') + 1);
    }
    return $index - 1;
}

/**
 * Read all rows of the first worksheet in an .xlsx file.
 * Returns a zero-indexed array of rows, each row a zero-indexed array of
 * string cell values (numbers/dates are returned as their raw string form).
 * Throws a RuntimeException with a user-facing message on any failure.
 */
function read_xlsx_rows(string $path): array
{
    if (!class_exists('ZipArchive')) {
        throw new RuntimeException('The server is missing the PHP zip extension required to read Excel files.');
    }

    $zip = new ZipArchive();
    if ($zip->open($path) !== true) {
        throw new RuntimeException('The uploaded file is not a valid .xlsx file.');
    }

    // Shared strings (most text cells reference this table by index rather than storing text inline)
    $sharedStrings = [];
    $sharedXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($sharedXml !== false) {
        $sx = @simplexml_load_string($sharedXml);
        if ($sx !== false) {
            foreach ($sx->si as $si) {
                // A shared string can be a single <t> or multiple <r><t> "rich text" runs.
                if (isset($si->t)) {
                    $sharedStrings[] = (string) $si->t;
                } else {
                    $text = '';
                    foreach ($si->r as $run) {
                        $text .= (string) $run->t;
                    }
                    $sharedStrings[] = $text;
                }
            }
        }
    }

    // Locate the first worksheet part. Most single-sheet exports use sheet1.xml,
    // but we scan the archive to be safe rather than assuming the filename.
    $sheetPath = null;
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        if (preg_match('#^xl/worksheets/sheet\d+\.xml$#', $name)) {
            $sheetPath = $name;
            break;
        }
    }
    if ($sheetPath === null) {
        $zip->close();
        throw new RuntimeException('Could not find a worksheet inside the uploaded file.');
    }

    $sheetXml = $zip->getFromName($sheetPath);
    $zip->close();

    if ($sheetXml === false) {
        throw new RuntimeException('Could not read the worksheet inside the uploaded file.');
    }

    $xml = @simplexml_load_string($sheetXml);
    if ($xml === false || !isset($xml->sheetData)) {
        throw new RuntimeException('The worksheet format could not be understood.');
    }

    $rows = [];
    foreach ($xml->sheetData->row as $row) {
        $rowData = [];
        foreach ($row->c as $cell) {
            $ref = (string) $cell['r']; // e.g. "C4"
            $colLetters = preg_replace('/[0-9]/', '', $ref);
            $colIndex = $colLetters !== '' ? xlsx_col_to_index($colLetters) : count($rowData);
            $type = (string) $cell['t'];

            if ($type === 's') { // shared string
                $idx = (int) $cell->v;
                $value = $sharedStrings[$idx] ?? '';
            } elseif ($type === 'inlineStr') {
                $value = isset($cell->is->t) ? (string) $cell->is->t : '';
            } elseif ($type === 'str') { // formula result string
                $value = (string) $cell->v;
            } else { // numeric / boolean / empty
                $value = isset($cell->v) ? (string) $cell->v : '';
            }

            $rowData[$colIndex] = trim($value);
        }
        if ($rowData) {
            ksort($rowData);
            $max = max(array_keys($rowData));
            $normalized = [];
            for ($i = 0; $i <= $max; $i++) {
                $normalized[$i] = $rowData[$i] ?? '';
            }
            $rows[] = $normalized;
        } else {
            $rows[] = [];
        }
    }

    return $rows;
}
