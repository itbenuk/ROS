<footer class="site-footer text-center py-4 mt-5">
  <div class="container">
    <p class="mb-1">&copy; <?= date('Y') ?> ROS RCCG. All rights reserved.</p>
    <p class="small mb-0 text-muted">Student Registration &amp; Faculty Learning Management Portal</p>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/sidebar.js"></script>
</body>
</html>
