<?php
/**
 * Shared <head> + top navigation. Include after config.php.
 * Optional $pageTitle variable can be set before include.
 */
$pageTitle = $pageTitle ?? APP_NAME;
$user = current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> | <?= e(APP_NAME) ?></title>
<link rel="preconnect" href="https://cdn.jsdelivr.net">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark main-navbar sticky-top">
  <div class="container-fluid px-3 px-lg-4">
    <?php if ($user): ?>
      <button class="btn sidebar-toggle-btn me-2 d-flex align-items-center justify-content-center" id="sidebarToggleBtn" type="button" aria-label="Toggle menu">
        <i class="fa-solid fa-bars"></i>
      </button>
    <?php endif; ?>
    <a class="navbar-brand d-flex align-items-center gap-2" href="<?= BASE_URL ?>/index.php">
      <i class="fa-solid fa-cross"></i>
      <span>ROS <strong>RCCG</strong> Portal</span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
        <?php if (!$user): ?>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/about.php">About</a></li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="<?= BASE_URL ?>/leadership.php" id="leadershipNavDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Leadership</a>
            <ul class="dropdown-menu" aria-labelledby="leadershipNavDropdown">
              <li><a class="dropdown-item" href="<?= BASE_URL ?>/leadership.php#general-overseer-wife">General Overseer &amp; Wife</a></li>
              <li><a class="dropdown-item" href="<?= BASE_URL ?>/leadership.php#ros-leadership">ROS Leadership</a></li>
              <li><a class="dropdown-item" href="<?= BASE_URL ?>/leadership.php#faculty-members">Faculty Members</a></li>
            </ul>
          </li>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/alumni.php">Alumni</a></li>
          <li class="nav-item"><a class="btn btn-outline-light btn-sm ms-lg-2" href="<?= BASE_URL ?>/student-register.php">Register</a></li>
        <?php else:
          $unreadCount = get_unread_notification_count($user['id']);
          $recentNotifs = get_recent_notifications($user['id'], 8);
        ?>
          <li class="nav-item dropdown">
            <a class="nav-link position-relative" href="#" role="button" data-bs-toggle="dropdown" aria-label="Notifications">
              <i class="fa-solid fa-bell fs-5"></i>
              <?php if ($unreadCount > 0): ?>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size:.6rem;">
                  <?= $unreadCount > 9 ? '9+' : $unreadCount ?>
                </span>
              <?php endif; ?>
            </a>
            <div class="dropdown-menu dropdown-menu-end p-0" style="width:320px; max-height:420px; overflow-y:auto;">
              <div class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom">
                <span class="fw-semibold small">Notifications</span>
                <?php if ($unreadCount > 0): ?>
                <form method="post" action="<?= BASE_URL ?>/ajax/notifications_read.php">
                  <?= csrf_field() ?>
                  <input type="hidden" name="mark" value="all">
                  <button class="btn btn-link btn-sm p-0 small" type="submit">Mark all read</button>
                </form>
                <?php endif; ?>
              </div>
              <?php if (!$recentNotifs): ?>
                <div class="text-center text-muted small py-4"><i class="fa-solid fa-bell-slash d-block mb-2 fs-4"></i>No notifications yet.</div>
              <?php else: foreach ($recentNotifs as $n): ?>
                <a href="<?= $n['link'] ? BASE_URL . e($n['link']) : '#' ?>" class="dropdown-item white-space-normal py-2 border-bottom <?= !$n['is_read'] ? 'bg-light' : '' ?>">
                  <div class="small fw-semibold"><?= e($n['title']) ?></div>
                  <?php if ($n['message']): ?><div class="small text-muted"><?= e($n['message']) ?></div><?php endif; ?>
                  <div class="small text-muted"><?= time_ago($n['created_at']) ?></div>
                </a>
              <?php endforeach; endif; ?>
            </div>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<script id="flash-data" type="application/json"><?= json_encode(get_flashes(), JSON_HEX_TAG | JSON_HEX_APOS) ?></script>
