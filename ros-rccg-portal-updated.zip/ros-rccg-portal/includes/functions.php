<?php
/**
 * Reusable helper functions shared across the whole application.
 */

/* ---------------------------------------------------------------
 * Output / escaping
 * --------------------------------------------------------------- */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/* ---------------------------------------------------------------
 * CSRF protection
 * --------------------------------------------------------------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): bool
{
    $sent = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    return !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $sent);
}

function require_csrf_or_die(): void
{
    if (!verify_csrf()) {
        http_response_code(419);
        if (is_ajax_request()) {
            json_response(['success' => false, 'message' => 'Invalid or expired security token. Please refresh and try again.'], 419);
        }
        die('Invalid security token. Please go back and try again.');
    }
}

function is_ajax_request(): bool
{
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
        strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

function json_response(array $data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/* ---------------------------------------------------------------
 * Flash messages (stored in session, shown once)
 * --------------------------------------------------------------- */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function get_flashes(): array
{
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flashes;
}

/** One-time retrieval of row-level import errors set by faculty/import-questions.php. */
function get_import_errors(): array
{
    $errors = $_SESSION['import_errors'] ?? [];
    unset($_SESSION['import_errors']);
    return $errors;
}

/* ---------------------------------------------------------------
 * Validation helpers
 * --------------------------------------------------------------- */
function is_valid_email(string $email): bool
{
    return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

function is_strong_password(string $password): bool
{
    // Minimum 8 chars, at least one letter and one number
    return strlen($password) >= 8 && preg_match('/[A-Za-z]/', $password) && preg_match('/[0-9]/', $password);
}

function clean_str(?string $value): string
{
    return trim($value ?? '');
}

/* ---------------------------------------------------------------
 * ID / registration number generation
 * --------------------------------------------------------------- */
function generate_reg_number(PDO $pdo): string
{
    $year = date('Y');
    $stmt = $pdo->prepare("SELECT COUNT(*) AS cnt FROM students WHERE reg_number LIKE ?");
    $stmt->execute(["RCCG/$year/%"]);
    $count = (int) $stmt->fetch()['cnt'] + 1;
    return sprintf('RCCG/%s/%04d', $year, $count);
}

function generate_staff_id(PDO $pdo): string
{
    $stmt = $pdo->query("SELECT COUNT(*) AS cnt FROM faculty");
    $count = (int) $stmt->fetch()['cnt'] + 1;
    return sprintf('FAC-%04d', $count);
}

/**
 * Auto-generate a unique course code from the course name, e.g.
 * "Diploma in Theology" -> "DTH101". Common short filler words (of, in,
 * the, and, for, a) are skipped when building the initials so the code
 * stays meaningful. The admin can still edit the result before saving;
 * uniqueness is re-checked on the backend regardless of what is submitted.
 */
function generate_course_code(PDO $pdo, string $name): string
{
    $stopWords = ['of', 'in', 'the', 'and', 'for', 'a', 'an', 'to', '&'];
    $words = preg_split('/\s+/', trim($name));
    $words = array_values(array_filter($words, fn($w) => $w !== '' && !in_array(strtolower($w), $stopWords, true)));

    $initials = '';
    foreach ($words as $w) {
        $initials .= strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', $w), 0, 1));
    }
    if ($initials === '') {
        $initials = 'CRS';
    }
    $initials = substr($initials, 0, 4);

    // Find the next free sequence number for this prefix (101, 102, ... to
    // mirror the existing seed-data convention of a 3-digit course number).
    for ($seq = 101; $seq < 999; $seq++) {
        $candidate = $initials . $seq;
        $chk = $pdo->prepare("SELECT id FROM courses WHERE code = ?");
        $chk->execute([$candidate]);
        if (!$chk->fetch()) {
            return $candidate;
        }
    }
    // Extremely unlikely fallback: fully random suffix.
    return $initials . strtoupper(bin2hex(random_bytes(2)));
}

/* ---------------------------------------------------------------
 * File upload validation (never trust the extension or client MIME)
 * --------------------------------------------------------------- */
function validate_and_move_upload(array $file, string $destinationDir, array $allowedTypes, int $maxBytes): array
{
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['success' => false, 'message' => 'No file was uploaded.'];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'File upload failed. Please try again.'];
    }
    if ($file['size'] <= 0 || $file['size'] > $maxBytes) {
        return ['success' => false, 'message' => 'File exceeds the maximum allowed size.'];
    }
    if (!is_uploaded_file($file['tmp_name'])) {
        return ['success' => false, 'message' => 'Invalid upload.'];
    }

    // Verify the REAL mime type server-side using finfo (do not trust client-supplied type/extension)
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $realMime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!isset($allowedTypes[$ext]) || !in_array($realMime, $allowedTypes[$ext], true)) {
        return ['success' => false, 'message' => 'File type not supported.'];
    }

    if (!is_dir($destinationDir)) {
        mkdir($destinationDir, 0755, true);
    }

    // Randomised stored filename prevents path traversal / overwrite / guessing
    $storedName = bin2hex(random_bytes(16)) . '.' . $ext;
    $destination = rtrim($destinationDir, '/') . '/' . $storedName;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        return ['success' => false, 'message' => 'Could not save the uploaded file.'];
    }

    return [
        'success'      => true,
        'stored_name'  => $storedName,
        'original_name'=> basename($file['name']),
        'file_type'    => $ext,
        'file_size'    => $file['size'],
    ];
}

function human_filesize(int $bytes): string
{
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 1) . ' ' . $units[$i];
}

/* ---------------------------------------------------------------
 * Pagination
 * --------------------------------------------------------------- */
function paginate(int $totalRows, int $perPage, int $currentPage): array
{
    $totalPages = max(1, (int) ceil($totalRows / $perPage));
    $currentPage = max(1, min($currentPage, $totalPages));
    $offset = ($currentPage - 1) * $perPage;
    return compact('totalRows', 'perPage', 'currentPage', 'totalPages', 'offset');
}

/* ---------------------------------------------------------------
 * Audit logging
 * --------------------------------------------------------------- */
function audit_log(?int $userId, string $action, string $details = ''): void
{
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            "INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)"
        );
        $stmt->execute([$userId, $action, $details, $_SERVER['REMOTE_ADDR'] ?? null]);
    } catch (Throwable $e) {
        error_log('Audit log failed: ' . $e->getMessage());
    }
}

/* ---------------------------------------------------------------
 * Notifications
 * --------------------------------------------------------------- */
function notify(int $userId, string $type, string $title, string $message = '', ?string $link = null): void
{
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, type, title, message, link) VALUES (?,?,?,?,?)");
        $stmt->execute([$userId, $type, $title, $message, $link]);
    } catch (Throwable $e) {
        error_log('Notify failed: ' . $e->getMessage());
    }
}

/** Notify every admin user (e.g. on new student registration). */
function notify_admins(string $type, string $title, string $message = '', ?string $link = null): void
{
    try {
        $pdo = getDB();
        $admins = $pdo->query("SELECT id FROM users WHERE role = 'admin' AND status = 'active'")->fetchAll();
        foreach ($admins as $a) {
            notify((int) $a['id'], $type, $title, $message, $link);
        }
    } catch (Throwable $e) {
        error_log('Notify admins failed: ' . $e->getMessage());
    }
}

function get_unread_notification_count(int $userId): int
{
    try {
        $stmt = getDB()->prepare("SELECT COUNT(*) c FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$userId]);
        return (int) $stmt->fetch()['c'];
    } catch (Throwable $e) {
        return 0;
    }
}

function get_recent_notifications(int $userId, int $limit = 8): array
{
    try {
        $stmt = getDB()->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
        $stmt->bindValue(1, $userId, PDO::PARAM_INT);
        $stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
}

/* ---------------------------------------------------------------
 * Test Management: status, timing & grading helpers
 * --------------------------------------------------------------- */

/** Whether a live (published/scheduled) test is currently within its availability window. */
function test_is_open(array $test): bool
{
    if (!in_array($test['status'], ['published', 'scheduled'], true)) return false;
    $now = time();
    return $now >= strtotime($test['start_at']) && $now <= strtotime($test['end_at']);
}

/** Computed state for display: draft, upcoming, open, or closed. */
function test_effective_status(array $test): string
{
    if ($test['status'] === 'draft') return 'draft';
    if ($test['status'] === 'closed') return 'closed';
    // published or scheduled: resolve against the actual time window
    $now = time();
    if ($now < strtotime($test['start_at'])) return 'upcoming';
    if ($now > strtotime($test['end_at'])) return 'closed';
    return 'open';
}

function format_duration(int $minutes): string
{
    if ($minutes < 60) return $minutes . ' min';
    $h = intdiv($minutes, 60);
    $m = $minutes % 60;
    return $m > 0 ? "{$h}h {$m}m" : "{$h}h";
}

/**
 * Determine whether a specific student is assigned to a test.
 * If test_assignments has explicit rows for this test, only those students
 * qualify; otherwise every active student in the test's course qualifies.
 */
function student_is_assigned_to_test(PDO $pdo, int $testId, int $studentId, ?int $studentCourseId): bool
{
    $stmt = $pdo->prepare("SELECT COUNT(*) c FROM test_assignments WHERE test_id = ?");
    $stmt->execute([$testId]);
    $hasExplicit = (int) $stmt->fetch()['c'] > 0;

    if ($hasExplicit) {
        $stmt = $pdo->prepare("SELECT 1 FROM test_assignments WHERE test_id = ? AND student_id = ?");
        $stmt->execute([$testId, $studentId]);
        return (bool) $stmt->fetch();
    }

    $stmt = $pdo->prepare("SELECT course_id FROM tests WHERE id = ?");
    $stmt->execute([$testId]);
    $testCourse = $stmt->fetch()['course_id'] ?? null;

    return $testCourse !== null && $testCourse == $studentCourseId;
}

/**
 * Grade one answer server-side. Never trust a client-supplied "correct" flag.
 * Returns ['is_correct' => bool|null, 'marks_awarded' => float]
 */
function grade_answer(PDO $pdo, array $question, ?int $selectedOptionId, ?string $answerText): array
{
    $marks = (float) $question['marks'];

    if ($question['question_type'] === 'short_answer') {
        if ($answerText === null || trim($answerText) === '') {
            return ['is_correct' => false, 'marks_awarded' => 0];
        }
        $normalize = fn($s) => strtolower(trim(preg_replace('/\s+/', ' ', $s)));
        $correct = $normalize((string) $question['correct_answer_text']);
        $given = $normalize($answerText);
        $isCorrect = $correct !== '' && $given === $correct;
        return ['is_correct' => $isCorrect, 'marks_awarded' => $isCorrect ? $marks : 0];
    }

    // mcq / true_false
    if (!$selectedOptionId) {
        return ['is_correct' => false, 'marks_awarded' => 0];
    }
    $stmt = $pdo->prepare("SELECT is_correct FROM test_options WHERE id = ? AND question_id = ?");
    $stmt->execute([$selectedOptionId, $question['id']]);
    $opt = $stmt->fetch();
    $isCorrect = $opt && (bool) $opt['is_correct'];
    return ['is_correct' => $isCorrect, 'marks_awarded' => $isCorrect ? $marks : 0];
}

/**
 * Finalize an attempt: sum marks_awarded across all answers, compute
 * percentage/pass, and mark the attempt as submitted/auto_submitted/expired.
 * Wrapped in a transaction with a row lock to prevent duplicate submission.
 */
function finalize_attempt(PDO $pdo, int $attemptId, string $finalStatus, ?string $terminationReason = null): ?array
{
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM test_attempts WHERE id = ? FOR UPDATE");
        $stmt->execute([$attemptId]);
        $attempt = $stmt->fetch();

        if (!$attempt || $attempt['status'] !== 'in_progress') {
            $pdo->commit(); // already finalized elsewhere - not an error
            return null;
        }

        $testStmt = $pdo->prepare("SELECT * FROM tests WHERE id = ?");
        $testStmt->execute([$attempt['test_id']]);
        $test = $testStmt->fetch();

        $totalMarksStmt = $pdo->prepare("SELECT COALESCE(SUM(marks),0) t FROM test_questions WHERE test_id = ?");
        $totalMarksStmt->execute([$attempt['test_id']]);
        $totalMarks = (float) $totalMarksStmt->fetch()['t'];

        $scoreStmt = $pdo->prepare("SELECT COALESCE(SUM(marks_awarded),0) s FROM test_answers WHERE attempt_id = ?");
        $scoreStmt->execute([$attemptId]);
        $score = (float) $scoreStmt->fetch()['s'];

        $percentage = $totalMarks > 0 ? round(($score / $totalMarks) * 100, 2) : 0;
        $passed = $percentage >= (float) $test['passing_score'] ? 1 : 0;
        $submittedAt = date('Y-m-d H:i:s');
        $timeTaken = max(0, strtotime($submittedAt) - strtotime($attempt['started_at']));

        $upd = $pdo->prepare("UPDATE test_attempts SET status=?, termination_reason=?, submitted_at=?, score=?, total_marks=?,
                               percentage=?, passed=?, time_taken_seconds=? WHERE id=?");
        $upd->execute([$finalStatus, $terminationReason, $submittedAt, $score, $totalMarks, $percentage, $passed, $timeTaken, $attemptId]);

        $pdo->commit();

        return [
            'score' => $score, 'total_marks' => $totalMarks, 'percentage' => $percentage,
            'passed' => (bool) $passed, 'time_taken_seconds' => $timeTaken, 'test' => $test, 'attempt' => $attempt,
        ];
    } catch (Throwable $e) {
        $pdo->rollBack();
        error_log('finalize_attempt failed: ' . $e->getMessage());
        return null;
    }
}

/**
 * Whether a student's current lifecycle status entitles them to see
 * active/current training content at all (registered or active only -
 * graduated and withdrawn students are excluded from current content by
 * design, per the access-control requirement).
 */
function student_has_active_access(array $student): bool
{
    return in_array($student['status'] ?? 'active', ['registered', 'active'], true);
}

/**
 * Whether batch-scoped content is visible to a given student's batch.
 * NULL on the content means "visible to the whole course" (no batch
 * restriction); otherwise the student's batch must match exactly.
 */
function content_visible_to_batch(?int $contentBatchId, ?int $studentBatchId): bool
{
    return $contentBatchId === null || $contentBatchId === $studentBatchId;
}

/**
 * Full authorization check for a student opening/attempting a test:
 * lifecycle status, batch scope, and course/explicit assignment - all
 * enforced server-side so a graduated student or a mismatched batch can
 * never reach a test via a guessed URL.
 */
function student_can_access_test(PDO $pdo, array $test, array $student): bool
{
    if (!student_has_active_access($student)) {
        return false;
    }
    if (!content_visible_to_batch($test['batch_id'] ?? null, $student['batch_id'] ?? null)) {
        return false;
    }
    return student_is_assigned_to_test($pdo, (int) $test['id'], (int) $student['id'], $student['course_id'] ?? null);
}

/** Same idea as student_can_access_test(), for learning materials. */
function student_can_access_material(array $material, array $student): bool
{
    if (!student_has_active_access($student)) {
        return false;
    }
    if (!content_visible_to_batch($material['batch_id'] ?? null, $student['batch_id'] ?? null)) {
        return false;
    }
    // A material with no course set is "general" and visible to every active student.
    if ($material['course_id'] !== null && (int) $material['course_id'] !== (int) ($student['course_id'] ?? 0)) {
        return false;
    }
    return true;
}

/**
 * Batches genuinely open for new enrollment right now: not completed/
 * archived, their enrollment window has opened (if one is set), and their
 * training hasn't started yet (if a start date is set) - i.e. a "new
 * batch" a prospective student could still join. Used by both the public
 * homepage (to show/hide the "Enrol Now" promo) and the registration form
 * (to populate the batch dropdown), so the two never drift out of sync.
 */
function get_open_enrollment_batches(PDO $pdo): array
{
    $stmt = $pdo->query("SELECT b.*, c.name AS course_name FROM batches b
                          LEFT JOIN courses c ON c.id = b.course_id
                          WHERE b.status IN ('upcoming','active')
                          AND (b.enrollment_start_date IS NULL OR b.enrollment_start_date <= CURDATE())
                          AND (b.training_start_date IS NULL OR b.training_start_date >= CURDATE())
                          ORDER BY b.training_start_date ASC, b.name ASC");
    return $stmt->fetchAll();
}

/**
 * Transition a batch (and every registered/active student in it) to
 * "graduated"/"completed" once its expected completion date has passed.
 * There is no background scheduler in this environment, so this is called
 * opportunistically from admin/batches.php on page load; for production,
 * wire the same call into a daily cron job instead.
 * Returns the number of students transitioned.
 */
function maybe_graduate_batch(PDO $pdo, int $batchId): int
{
    $stmt = $pdo->prepare("SELECT * FROM batches WHERE id = ?");
    $stmt->execute([$batchId]);
    $batch = $stmt->fetch();

    if (!$batch || $batch['status'] !== 'active' || !$batch['expected_completion_date']) {
        return 0;
    }
    if (strtotime($batch['expected_completion_date']) > strtotime(date('Y-m-d'))) {
        return 0;
    }

    return graduate_batch_now($pdo, $batchId);
}

/** Immediately (administratively) graduate a batch, regardless of its dates. */
function graduate_batch_now(PDO $pdo, int $batchId): int
{
    $today = date('Y-m-d');
    $pdo->beginTransaction();
    try {
        $upd = $pdo->prepare("UPDATE students SET status = 'graduated', graduation_date = ?
                               WHERE batch_id = ? AND status IN ('registered','active')");
        $upd->execute([$today, $batchId]);
        $count = $upd->rowCount();

        $pdo->prepare("UPDATE batches SET status = 'completed', actual_completion_date = ? WHERE id = ?")
            ->execute([$today, $batchId]);

        $pdo->commit();
        return $count;
    } catch (Throwable $e) {
        $pdo->rollBack();
        error_log('graduate_batch_now failed: ' . $e->getMessage());
        return 0;
    }
}

/* ---------------------------------------------------------------
 * Leadership section (General Overseer / Parish Pastor, etc.)
 * --------------------------------------------------------------- */

/** Human-readable label for a leadership_profiles.category value. */
function leadership_category_label(string $category): string
{
    return match ($category) {
        'general_overseer' => 'General Overseer',
        'overseer_wife'    => "General Overseer's Wife",
        'parish_pastor'    => 'Parish Pastor',
        'pastor_wife'      => "Parish Pastor's Wife",
        default            => 'ROS Leadership',
    };
}

/**
 * All leadership profiles in a stable, sensible order: the four core
 * roles first (General Overseer, his wife, Parish Pastor, his wife), then
 * any additional "other" profiles the admin has added, each group sorted
 * by display_order. Pass $activeOnly = false to include hidden profiles
 * (used by the admin screen).
 */
function get_leadership_profiles(PDO $pdo, bool $activeOnly = true): array
{
    $sql = "SELECT * FROM leadership_profiles";
    if ($activeOnly) {
        $sql .= " WHERE is_active = 1";
    }
    $sql .= " ORDER BY FIELD(category, 'general_overseer','overseer_wife','parish_pastor','pastor_wife','other'), display_order ASC, id ASC";

    return $pdo->query($sql)->fetchAll();
}

/**
 * Faculty shown in the "Faculty Members" section of the public Leadership
 * page. Sourced from the existing `faculty` table (joined to `users` for
 * account status) - not a separate list, so a faculty member's photo/bio
 * updates or a status change is reflected immediately with nothing to
 * keep in sync. Only active accounts with show_on_leadership = 1 appear.
 */
function get_public_faculty(PDO $pdo): array
{
    $sql = "SELECT f.*, u.status AS user_status
            FROM faculty f
            JOIN users u ON u.id = f.user_id
            WHERE u.status = 'active' AND f.show_on_leadership = 1
            ORDER BY f.department ASC, f.title ASC, f.first_name ASC";
    return $pdo->query($sql)->fetchAll();
}



/**
 * Fetch graduated students for the Alumni section/admin screen, with
 * optional search/course/year filters and pagination. This never reads
 * from a separate "alumni" table - a student appears here purely because
 * students.status = 'graduated', so there is nothing to keep in sync and
 * nothing to duplicate. Pass $publicOnly = true to additionally require
 * show_in_alumni = 1, as the public-facing page does.
 *
 * Returns ['rows' => array, 'total' => int].
 */
function get_alumni(PDO $pdo, array $opts = []): array
{
    $search      = trim((string) ($opts['search'] ?? ''));
    $courseId    = (int) ($opts['course_id'] ?? 0);
    $year        = (int) ($opts['year'] ?? 0);
    $publicOnly  = (bool) ($opts['public_only'] ?? false);
    $perPage     = (int) ($opts['per_page'] ?? 12);
    $page        = max(1, (int) ($opts['page'] ?? 1));

    $where = ["s.status = 'graduated'"];
    $params = [];

    if ($publicOnly) {
        $where[] = "s.show_in_alumni = 1";
    }
    if ($search !== '') {
        $where[] = "(s.first_name LIKE ? OR s.last_name LIKE ? OR s.reg_number LIKE ?)";
        array_push($params, "%$search%", "%$search%", "%$search%");
    }
    if ($courseId) {
        $where[] = "s.course_id = ?";
        $params[] = $courseId;
    }
    if ($year) {
        $where[] = "YEAR(s.graduation_date) = ?";
        $params[] = $year;
    }
    $whereSql = implode(' AND ', $where);

    $countStmt = $pdo->prepare("SELECT COUNT(*) c FROM students s WHERE $whereSql");
    $countStmt->execute($params);
    $total = (int) $countStmt->fetch()['c'];

    $p = paginate($total, $perPage, $page);

    $sql = "SELECT s.id, s.first_name, s.middle_name, s.last_name, s.reg_number, s.passport_photo,
                   s.graduation_date, s.show_in_alumni, s.course_id, s.session_id, s.batch_id,
                   c.name AS course_name, se.name AS session_name, b.name AS batch_name
            FROM students s
            LEFT JOIN courses c ON c.id = s.course_id
            LEFT JOIN sessions se ON se.id = s.session_id
            LEFT JOIN batches b ON b.id = s.batch_id
            WHERE $whereSql
            ORDER BY s.graduation_date DESC, s.last_name ASC
            LIMIT {$p['perPage']} OFFSET {$p['offset']}";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    return ['rows' => $rows, 'total' => $total, 'pagination' => $p];
}

/** Distinct graduation years, most recent first, for the Alumni filter dropdown. */
function get_alumni_years(PDO $pdo, bool $publicOnly = false): array
{
    $sql = "SELECT DISTINCT YEAR(graduation_date) y FROM students WHERE status = 'graduated' AND graduation_date IS NOT NULL";
    if ($publicOnly) {
        $sql .= " AND show_in_alumni = 1";
    }
    $sql .= " ORDER BY y DESC";
    return array_column($pdo->query($sql)->fetchAll(), 'y');
}

/**
 * Attach each question's answer options in a single query instead of one
 * query per question (a real N+1 that matters most exactly where load is
 * highest: many students opening/reviewing a test at once). Returns the
 * same $questions array with an 'options' key added to each row.
 */
function load_options_for_questions(PDO $pdo, array $questions): array
{
    $ids = array_column($questions, 'id');
    if (!$ids) {
        return $questions;
    }
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT * FROM test_options WHERE question_id IN ($placeholders) ORDER BY question_id, order_index");
    $stmt->execute($ids);

    $byQuestion = [];
    foreach ($stmt->fetchAll() as $opt) {
        $byQuestion[$opt['question_id']][] = $opt;
    }
    foreach ($questions as &$q) {
        $q['options'] = $byQuestion[$q['id']] ?? [];
    }
    unset($q);

    return $questions;
}

/**
 * Same batch-loading idea as load_options_for_questions(), but deliberately
 * selects only id/option_text - never is_correct. Used on the student-facing
 * test-taking page, where the answer key must never reach the browser
 * regardless of how the test_options table might grow in the future.
 */
function load_public_options_for_questions(PDO $pdo, array $questions): array
{
    $ids = array_column($questions, 'id');
    if (!$ids) {
        return $questions;
    }
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT id, question_id, option_text FROM test_options WHERE question_id IN ($placeholders) ORDER BY question_id, order_index");
    $stmt->execute($ids);

    $byQuestion = [];
    foreach ($stmt->fetchAll() as $opt) {
        $byQuestion[$opt['question_id']][] = $opt;
    }
    foreach ($questions as &$q) {
        $q['options'] = ($q['question_type'] ?? null) === 'short_answer' ? [] : ($byQuestion[$q['id']] ?? []);
    }
    unset($q);

    return $questions;
}

/* ---------------------------------------------------------------
 * Misc
 * --------------------------------------------------------------- */
function redirect(string $path): void
{
    header('Location: ' . BASE_URL . $path);
    exit;
}

function time_ago(string $datetime): string
{
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff / 60) . 'm ago';
    if ($diff < 86400) return floor($diff / 3600) . 'h ago';
    if ($diff < 2592000) return floor($diff / 86400) . 'd ago';
    return date('M j, Y', strtotime($datetime));
}
