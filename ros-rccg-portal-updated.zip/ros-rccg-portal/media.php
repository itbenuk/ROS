<?php
/**
 * Public media controller.
 *
 * Serves ONLY the categories of image that are meant to be public:
 *   - Leadership profile pictures (admin-uploaded specifically for public display)
 *   - A graduated student's passport photo, and only when that graduate has
 *     been marked show_in_alumni = 1.
 *   - A faculty member's photo, and only when their account is active and
 *     show_on_leadership = 1.
 *   Every other student/faculty photo stays behind the role-gated
 *   admin/faculty/student download.php controllers.
 *
 * Deliberately requires no login - this is what makes the Leadership and
 * Alumni pages work for anonymous visitors.
 */
require_once __DIR__ . '/config/config.php';

$pdo = getDB();
$type = $_GET['type'] ?? '';
$path = null;

if ($type === 'leadership') {
    $file = basename($_GET['file'] ?? ''); // basename() strips path traversal attempts
    if ($file) {
        $stmt = $pdo->prepare("SELECT 1 FROM leadership_profiles WHERE photo = ? AND is_active = 1");
        $stmt->execute([$file]);
        if ($stmt->fetch()) {
            $path = UPLOAD_LEADERSHIP_PATH . $file;
        }
    }
} elseif ($type === 'alumni') {
    $id = (int) ($_GET['id'] ?? 0);
    if ($id) {
        $stmt = $pdo->prepare("SELECT passport_photo FROM students WHERE id = ? AND status = 'graduated' AND show_in_alumni = 1");
        $stmt->execute([$id]);
        if ($row = $stmt->fetch()) {
            if (!empty($row['passport_photo'])) {
                $path = UPLOAD_PASSPORTS_PATH . $row['passport_photo'];
            }
        }
    }
} elseif ($type === 'faculty') {
    $id = (int) ($_GET['id'] ?? 0);
    if ($id) {
        $stmt = $pdo->prepare("SELECT f.photo FROM faculty f JOIN users u ON u.id = f.user_id
                                WHERE f.id = ? AND u.status = 'active' AND f.show_on_leadership = 1");
        $stmt->execute([$id]);
        if ($row = $stmt->fetch()) {
            if (!empty($row['photo'])) {
                $path = UPLOAD_PASSPORTS_PATH . $row['photo'];
            }
        }
    }
}

if (!$path || !is_file($path)) {
    http_response_code(404);
    exit;
}

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $path);
finfo_close($finfo);

header('Content-Type: ' . $mime);
header('Content-Disposition: inline; filename="' . basename($path) . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=3600');
readfile($path);
exit;
