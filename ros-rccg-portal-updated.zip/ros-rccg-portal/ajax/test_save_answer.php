<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf()) {
    json_response(['success' => false, 'message' => 'Invalid request.'], 419);
}

$pdo = getDB();
$studentId = $_SESSION['ref_id'];
$attemptId = (int) ($_POST['attempt_id'] ?? 0);
$questionId = (int) ($_POST['question_id'] ?? 0);
$selectedOptionId = !empty($_POST['selected_option_id']) ? (int) $_POST['selected_option_id'] : null;
$answerText = isset($_POST['answer_text']) ? clean_str($_POST['answer_text']) : null;

$stmt = $pdo->prepare("SELECT * FROM test_attempts WHERE id = ? AND student_id = ?");
$stmt->execute([$attemptId, $studentId]);
$attempt = $stmt->fetch();

if (!$attempt) {
    json_response(['success' => false, 'message' => 'Attempt not found.'], 404);
}

// Timer check: reject the save and force a submit if time is already up.
if ($attempt['status'] !== 'in_progress') {
    json_response(['success' => false, 'message' => 'This test has already been submitted.', 'force_submit' => true], 409);
}
if (time() >= strtotime($attempt['expires_at'])) {
    finalize_attempt($pdo, $attemptId, 'auto_submitted');
    json_response(['success' => false, 'message' => 'Time is up.', 'force_submit' => true], 409);
}

$qStmt = $pdo->prepare("SELECT * FROM test_questions WHERE id = ? AND test_id = ?");
$qStmt->execute([$questionId, $attempt['test_id']]);
$question = $qStmt->fetch();

if (!$question) {
    json_response(['success' => false, 'message' => 'Invalid question.'], 422);
}

// If it's an option-based question, verify the option actually belongs to this question
// (defends against a tampered client sending an arbitrary option id).
if ($question['question_type'] !== 'short_answer' && $selectedOptionId) {
    $optCheck = $pdo->prepare("SELECT id FROM test_options WHERE id = ? AND question_id = ?");
    $optCheck->execute([$selectedOptionId, $questionId]);
    if (!$optCheck->fetch()) {
        json_response(['success' => false, 'message' => 'Invalid option.'], 422);
    }
}

$grade = grade_answer($pdo, $question, $selectedOptionId, $answerText);

$upsert = $pdo->prepare("INSERT INTO test_answers (attempt_id, question_id, selected_option_id, answer_text, is_correct, marks_awarded)
                          VALUES (?,?,?,?,?,?)
                          ON DUPLICATE KEY UPDATE selected_option_id = VALUES(selected_option_id),
                          answer_text = VALUES(answer_text), is_correct = VALUES(is_correct), marks_awarded = VALUES(marks_awarded)");
$upsert->execute([
    $attemptId, $questionId, $selectedOptionId, $answerText,
    $grade['is_correct'] === null ? null : (int) $grade['is_correct'], $grade['marks_awarded'],
]);

json_response(['success' => true, 'message' => 'Answer saved.']);
