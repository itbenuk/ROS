<?php
require_once __DIR__ . '/../config/config.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf()) {
    redirect('/index.php');
}

$pdo = getDB();
$userId = $_SESSION['user_id'];

if (($_POST['mark'] ?? '') === 'all') {
    $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$userId]);
} elseif (!empty($_POST['id'])) {
    $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?")
        ->execute([(int) $_POST['id'], $userId]);
}

$back = $_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/index.php');
header('Location: ' . $back);
exit;
