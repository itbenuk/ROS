<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
header('Content-Type: application/json');

$pdo = getDB();
$name = clean_str($_GET['name'] ?? '');

if ($name === '') {
    json_response(['success' => false, 'message' => 'Course name is required.'], 422);
}

$code = generate_course_code($pdo, $name);
json_response(['success' => true, 'code' => $code]);
