<?php
require_once __DIR__ . '/../config/config.php';
header('Content-Type: application/json');

$email = clean_str($_GET['email'] ?? '');

if (!is_valid_email($email)) {
    json_response(['success' => false, 'available' => false, 'message' => 'Invalid email format.']);
}

$pdo = getDB();
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);

$available = !$stmt->fetch();

json_response([
    'success'   => true,
    'available' => $available,
    'message'   => $available ? 'Email is available.' : 'This email is already registered.',
]);
