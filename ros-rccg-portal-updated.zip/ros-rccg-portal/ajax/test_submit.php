<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf()) {
    json_response(['success' => false, 'message' => 'Invalid request.'], 419);
}

$pdo = getDB();
$studentId = $_SESSION['ref_id'];
$attemptId = (int) ($_POST['attempt_id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM test_attempts WHERE id = ? AND student_id = ?");
$stmt->execute([$attemptId, $studentId]);
$attempt = $stmt->fetch();

if (!$attempt) {
    json_response(['success' => false, 'message' => 'Attempt not found.'], 404);
}

if ($attempt['status'] !== 'in_progress') {
    // Already finalized (e.g. by a concurrent heartbeat expiry) - not an error, just report it.
    json_response(['success' => true, 'message' => 'Already submitted.', 'already_submitted' => true]);
}

// finalize_attempt() locks the row (SELECT ... FOR UPDATE) so a simultaneous
// heartbeat-triggered auto-submit and this manual submit can never both apply.
$reason = clean_str($_POST['reason'] ?? '');
if ($reason === 'tab_switch') {
    $finalStatus = 'violation_submitted';
    $terminationReason = 'Test automatically submitted because tab navigation was detected.';
} else {
    $finalStatus = time() >= strtotime($attempt['expires_at']) ? 'auto_submitted' : 'submitted';
    $terminationReason = null;
}
$result = finalize_attempt($pdo, $attemptId, $finalStatus, $terminationReason);

if (!$result) {
    json_response(['success' => true, 'message' => 'Already submitted.', 'already_submitted' => true]);
}

audit_log($_SESSION['user_id'], $reason === 'tab_switch' ? 'test_violation_auto_submit' : 'test_submitted', "Attempt #$attemptId" . ($terminationReason ? " - $terminationReason" : ''));

// Notify the faculty owner.
$test = $result['test'];
$facultyUser = $pdo->prepare("SELECT u.id FROM faculty f JOIN users u ON u.id = f.user_id WHERE f.id = ?");
$facultyUser->execute([$test['faculty_id']]);
if ($fu = $facultyUser->fetch()) {
    $studentName = $pdo->prepare("SELECT first_name, last_name FROM students WHERE id = ?");
    $studentName->execute([$studentId]);
    $sn = $studentName->fetch();
    $studentLabel = $sn ? $sn['first_name'] . ' ' . $sn['last_name'] : 'A student';

    if ($reason === 'tab_switch') {
        notify((int) $fu['id'], 'test_violation', 'Possible Exam Violation: ' . $test['title'],
            $studentLabel . ' left the test tab and their attempt was auto-submitted.',
            '/faculty/test-attempt-view.php?id=' . $attemptId);
    } else {
        notify((int) $fu['id'], 'test_submitted', 'Test Submitted: ' . $test['title'],
            $studentLabel . ' scored ' . $result['percentage'] . '%.',
            '/faculty/test-results.php?id=' . $test['id']);
    }
}

json_response([
    'success'    => true,
    'message'    => 'Test submitted successfully.',
    'score'      => $result['score'],
    'total'      => $result['total_marks'],
    'percentage' => $result['percentage'],
    'passed'     => $result['passed'],
]);
