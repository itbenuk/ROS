<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['success' => false, 'message' => 'Invalid request method.'], 405);
}
if (!verify_csrf()) {
    json_response(['success' => false, 'message' => 'Invalid or expired security token. Please refresh and try again.'], 419);
}

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];

$title = clean_str($_POST['title'] ?? '');
$description = clean_str($_POST['description'] ?? '');
$courseId = !empty($_POST['course_id']) ? (int) $_POST['course_id'] : null;
$categoryId = !empty($_POST['category_id']) ? (int) $_POST['category_id'] : null;
$status = in_array($_POST['status'] ?? '', ['published', 'draft'], true) ? $_POST['status'] : 'published';

if ($title === '') {
    json_response(['success' => false, 'message' => 'Title is required.'], 422);
}

$upload = validate_and_move_upload($_FILES['material_file'] ?? [], UPLOAD_MATERIALS_PATH, ALLOWED_MATERIAL_TYPES, MAX_UPLOAD_BYTES);
if (!$upload['success']) {
    json_response(['success' => false, 'message' => $upload['message']], 422);
}

try {
    $stmt = $pdo->prepare("INSERT INTO materials
        (title, description, course_id, category_id, faculty_id, file_name, stored_name, file_type, file_size, status)
        VALUES (?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([
        $title, $description, $courseId, $categoryId, $facultyId,
        $upload['original_name'], $upload['stored_name'], $upload['file_type'], $upload['file_size'], $status,
    ]);
    audit_log($_SESSION['user_id'], 'material_uploaded', $title);

    json_response([
        'success'  => true,
        'message'  => 'Material uploaded successfully.',
        'redirect' => BASE_URL . '/faculty/materials.php',
    ]);
} catch (Throwable $e) {
    error_log('Upload error: ' . $e->getMessage());
    // Clean up orphaned file
    @unlink(UPLOAD_MATERIALS_PATH . $upload['stored_name']);
    json_response(['success' => false, 'message' => 'A system error occurred while saving the material.'], 500);
}
