<?php
require_once __DIR__ . '/../config/config.php';
require_role(['admin', 'student', 'faculty']);
header('Content-Type: application/json');

$pdo = getDB();
$q = clean_str($_GET['q'] ?? '');

$sql = "SELECT m.id, m.title, m.file_type, m.download_count, c.name AS course_name
        FROM materials m LEFT JOIN courses c ON c.id = m.course_id
        WHERE m.status = 'published'";
$params = [];
if ($q !== '') {
    $sql .= " AND m.title LIKE ?";
    $params[] = "%$q%";
}
$sql .= " ORDER BY m.created_at DESC LIMIT 20";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

json_response(['success' => true, 'materials' => $stmt->fetchAll()]);
