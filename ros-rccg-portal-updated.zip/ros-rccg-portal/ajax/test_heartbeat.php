<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf()) {
    json_response(['success' => false, 'message' => 'Invalid request.'], 419);
}

$pdo = getDB();
$studentId = $_SESSION['ref_id'];
$attemptId = (int) ($_POST['attempt_id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM test_attempts WHERE id = ? AND student_id = ?");
$stmt->execute([$attemptId, $studentId]);
$attempt = $stmt->fetch();

if (!$attempt) {
    json_response(['success' => false, 'message' => 'Attempt not found.'], 404);
}

$now = time();

if ($attempt['status'] === 'in_progress' && $now >= strtotime($attempt['expires_at'])) {
    $result = finalize_attempt($pdo, $attemptId, 'auto_submitted');
    if ($result) {
        // Notify the faculty owner that time expired and the test was auto-submitted.
        $test = $result['test'];
        $facultyUser = $pdo->prepare("SELECT u.id FROM faculty f JOIN users u ON u.id = f.user_id WHERE f.id = ?");
        $facultyUser->execute([$test['faculty_id']]);
        if ($fu = $facultyUser->fetch()) {
            notify((int) $fu['id'], 'test_auto_submitted', 'Test Auto-Submitted (Time Expired)',
                $test['title'] . ' was auto-submitted for a student when time ran out.',
                '/faculty/test-results.php?id=' . $test['id']);
        }
    }
    json_response(['success' => true, 'status' => 'auto_submitted', 'expires_at' => strtotime($attempt['expires_at']), 'server_now' => $now]);
}

json_response([
    'success'    => true,
    'status'     => $attempt['status'],
    'expires_at' => strtotime($attempt['expires_at']),
    'server_now' => $now,
]);
