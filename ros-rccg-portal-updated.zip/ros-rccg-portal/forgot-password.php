<?php
require_once __DIR__ . '/config/config.php';
$pageTitle = 'Forgot Password';
$role = in_array($_GET['role'] ?? '', ['student', 'faculty', 'admin'], true) ? $_GET['role'] : 'student';
$done = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $email = clean_str($_POST['email'] ?? '');
    $role = in_array($_POST['role'] ?? '', ['student', 'faculty', 'admin'], true) ? $_POST['role'] : 'student';

    if (is_valid_email($email)) {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND role = ?");
        $stmt->execute([$email, $role]);
        if ($user = $stmt->fetch()) {
            $token = bin2hex(random_bytes(32));
            $tokenHash = hash('sha256', $token);
            $expires = date('Y-m-d H:i:s', time() + 3600);

            $pdo->prepare("INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?,?,?)")
                ->execute([$user['id'], $tokenHash, $expires]);

            // In production: email the reset link containing $token to the user.
            // e.g. mail($email, 'Password Reset', BASE_URL . "/reset-password.php?token=$token");
            audit_log($user['id'], 'password_reset_requested');
        }
    }
    // Always show the same confirmation message (do not reveal whether the email exists)
    $done = true;
}

include __DIR__ . '/includes/header.php';
?>
<div class="auth-wrapper">
  <div class="auth-card" style="max-width:520px;">
    <div class="auth-form w-100">
      <h4 class="mb-3"><i class="fa-solid fa-key text-gold me-2"></i>Reset Your Password</h4>
      <?php if ($done): ?>
        <div class="alert alert-success">If an account exists with that email, a password reset link has been sent.</div>
        <a href="<?= BASE_URL ?>/student-login.php" class="btn btn-outline-secondary w-100">Back to Login</a>
      <?php else: ?>
        <p class="text-muted">Enter your account email and select your portal. We'll send you a secure reset link.</p>
        <form method="post" novalidate>
          <?= csrf_field() ?>
          <div class="mb-3">
            <label class="form-label">Portal</label>
            <select name="role" class="form-select">
              <option value="student" <?= $role === 'student' ? 'selected' : '' ?>>Student</option>
              <option value="faculty" <?= $role === 'faculty' ? 'selected' : '' ?>>Faculty</option>
              <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Administrator</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" class="form-control" required>
          </div>
          <button type="submit" class="btn btn-gold w-100">Send Reset Link</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
