-- =====================================================================
-- Migration 006: Faculty bio + "ROS Leadership" visibility flag
-- Run against an EXISTING database:
--   mysql -u root -p ros_rccg_portal < database/migration_006_faculty_leadership.sql
-- (Fresh installs already get this from database.sql.)
--
-- Adds two columns to the existing `faculty` table so the public
-- Leadership page can show a "ROS Leadership" section built from real
-- faculty records - no separate table, no duplicate data:
--   - bio:                short biography, editable by the faculty member
--                          on their own profile page (or by an admin).
--   - show_on_leadership: lets an admin hide an individual staff member
--                          from the public page without touching their
--                          account status or permissions.
-- =====================================================================

USE ros_rccg_portal;
SET FOREIGN_KEY_CHECKS = 0;

SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'faculty' AND COLUMN_NAME = 'bio'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE faculty ADD COLUMN bio TEXT NULL AFTER title',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'faculty' AND COLUMN_NAME = 'show_on_leadership'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE faculty ADD COLUMN show_on_leadership TINYINT(1) NOT NULL DEFAULT 1 AFTER photo',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET FOREIGN_KEY_CHECKS = 1;
