-- =====================================================================
-- Migration 005: Leadership Profiles + Alumni (Graduated Students)
-- Run against an EXISTING database:
--   mysql -u root -p ros_rccg_portal < database/migration_005_leadership_alumni.sql
-- (Fresh installs already get this from database.sql.)
--
-- Notes:
--  - The Alumni section is NOT a new table. It is generated dynamically
--    from the existing `students` table wherever status = 'graduated',
--    so no duplicate records are ever created. This migration only adds
--    one small visibility flag to `students`.
--  - Leadership is a small, admin-managed table since General Overseer /
--    Parish Pastor and their wives are not necessarily portal users.
-- =====================================================================

USE ros_rccg_portal;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- Leadership section
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS leadership_profiles (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category        ENUM('general_overseer','overseer_wife','parish_pastor','pastor_wife','other') NOT NULL DEFAULT 'other',
    full_name       VARCHAR(150) NOT NULL,
    title           VARCHAR(150) NOT NULL,
    bio             TEXT NULL,
    photo           VARCHAR(255) NULL,
    display_order   INT UNSIGNED NOT NULL DEFAULT 0,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_leadership_category (category),
    KEY idx_leadership_active (is_active),
    KEY idx_leadership_order (display_order)
) ENGINE=InnoDB;

-- Seed the four core slots only if the table is currently empty, so this
-- migration is safe to re-run and won't duplicate rows for sites that
-- already populated their own leadership entries.
INSERT INTO leadership_profiles (category, full_name, title, bio, display_order, is_active)
SELECT * FROM (
    SELECT 'general_overseer' AS category, 'General Overseer' AS full_name, 'General Overseer, RCCG' AS title, 'Profile details coming soon.' AS bio, 1 AS display_order, 1 AS is_active
    UNION ALL SELECT 'overseer_wife', "General Overseer's Wife", "General Overseer's Wife", 'Profile details coming soon.', 2, 1
    UNION ALL SELECT 'parish_pastor', 'Parish Pastor', 'Parish Pastor', 'Profile details coming soon.', 3, 1
    UNION ALL SELECT 'pastor_wife', "Parish Pastor's Wife", "Parish Pastor's Wife", 'Profile details coming soon.', 4, 1
) AS seed
WHERE NOT EXISTS (SELECT 1 FROM leadership_profiles);

-- ---------------------------------------------------------------------
-- Alumni visibility flag on the existing students table
-- ---------------------------------------------------------------------
SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'students' AND COLUMN_NAME = 'show_in_alumni'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE students ADD COLUMN show_in_alumni TINYINT(1) NOT NULL DEFAULT 1 AFTER graduation_date',
    'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @idx_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'students' AND INDEX_NAME = 'idx_students_alumni'
);
SET @sql := IF(@idx_exists = 0,
    'ALTER TABLE students ADD KEY idx_students_alumni (status, show_in_alumni)',
    'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET FOREIGN_KEY_CHECKS = 1;
