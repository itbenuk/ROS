<?php
/**
 * Demo data seeder.
 *
 * Populates the database with a realistic spread of ~300 records across
 * every module (courses, batches, faculty, students, materials, tests +
 * questions, timetable entries, announcements, test attempts) for demoing
 * or load-testing the application against non-trivial data volumes.
 *
 * Run from the command line, from the project root:
 *   php database/seed_demo_data.php
 *
 * Safe to run more than once - it does not touch existing rows (admin,
 * seed faculty, seed courses/batches from database.sql) and always adds a
 * fresh, clearly-labelled batch of demo data with randomised unique emails/
 * reg numbers/staff IDs, so re-running just adds another wave rather than
 * erroring on duplicates.
 *
 * All demo accounts (students and faculty) share the password: Demo@12345
 * so they're easy to log into for testing. This is seed/demo data only -
 * never run this against a production database with real user data.
 */

require_once __DIR__ . '/../config/config.php';

$pdo = getDB();
$DEMO_PASSWORD_HASH = password_hash('Demo@12345', PASSWORD_DEFAULT);

// ---------------------------------------------------------------------
// Name pools for realistic-looking generated data
// ---------------------------------------------------------------------
$firstNames = ['Adaeze','Adebayo','Adewale','Amara','Blessing','Chidinma','Chioma','Chinedu','Damilola',
    'Ebuka','Emeka','Esther','Ezinne','Folake','Gabriel','Grace','Ifeoma','Ikenna','Jumoke','Kelechi',
    'Kunle','Mercy','Ngozi','Nkem','Obinna','Oluwaseun','Patience','Precious','Rita','Samuel','Sarah',
    'Segun','Stephanie','Temitope','Tobi','Tolu','Uche','Victor','Yemi','Zainab','Abiodun','Adaobi',
    'Bimpe','Chukwuemeka','Comfort','Daniel','Deborah','Emmanuel','Faith','Funmilayo','Gloria'];
$lastNames = ['Adeyemi','Afolabi','Agbaje','Akintola','Alabi','Alli','Amadi','Ani','Anyanwu','Balogun',
    'Bello','Chukwu','Dada','Danladi','Eze','Fashola','Fatunde','Ibrahim','Igwe','Jaiyeola','Johnson',
    'Kalu','Lawal','Musa','Nwachukwu','Nwosu','Obi','Ogunleye','Ojo','Okafor','Okeke','Okonkwo',
    'Olawale','Oluwole','Omotayo','Onwuka','Oyelaran','Salami','Sanni','Suleiman','Udo','Umeh'];
$states = ['Lagos','Ogun','Oyo','Rivers','Kano','Kaduna','Enugu','Abuja','Delta','Edo','Anambra','Ondo'];
$courseNames = ['Diploma in Christian Counselling','Certificate in Church Administration',
    'Diploma in Biblical Studies','Certificate in Youth Ministry','Advanced Diploma in Theology',
    'Certificate in Music Ministry'];
$materialTitles = ['Foundations of Faith','Prayer and Fasting Principles','Church Leadership Essentials',
    'Understanding the Covenant','The Believer\'s Authority','Effective Bible Study Methods',
    'Marriage and Family Life','Financial Stewardship','Evangelism Strategies','Spiritual Warfare Basics',
    'The Holy Spirit and You','Christian Ethics','Discipleship Pathways','Worship and Praise',
    'Servant Leadership','Building Godly Character','The Power of Testimony','Intercessory Prayer',
    'Church History Overview','Practical Pastoral Care'];
$testTitles = ['Mid-Course Assessment','Foundations Quiz','Leadership Evaluation','Doctrine Test',
    'Ministry Readiness Exam','Bible Knowledge Check','End of Module Test','Practical Assessment'];
$topics = ['Understanding Grace','The Fruit of the Spirit','Effective Prayer Life','Church Governance',
    'Biblical Counselling Basics','The Great Commission','Worship in Spirit and Truth',
    'Financial Wisdom','Family Devotion','Spiritual Disciplines','Leadership Under Pressure',
    'The Armor of God','Faith and Works','Living a Sanctified Life'];

function pick(array $arr) { return $arr[array_rand($arr)]; }
function randDateBetween(string $start, string $end): string {
    $s = strtotime($start); $e = strtotime($end);
    return date('Y-m-d', mt_rand($s, $e));
}

echo "=== ROS RCCG Portal — Demo Data Seeder ===\n";

$writtenFiles = []; // track so we can clean up on failure - file writes aren't covered by the SQL rollback below

$pdo->beginTransaction();
try {
    // -------------------------------------------------------------
    // 1. Extra courses (on top of whatever already exists)
    // -------------------------------------------------------------
    $courseIds = $pdo->query("SELECT id FROM courses")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($courseNames as $name) {
        $code = generate_course_code($pdo, $name);
        $pdo->prepare("INSERT INTO courses (name, code, description, is_active) VALUES (?,?,?,1)")
            ->execute([$name, $code, "Demo programme: $name."]);
        $courseIds[] = (int) $pdo->lastInsertId();
    }
    echo "Courses: +" . count($courseNames) . " (total now " . count($courseIds) . ")\n";

    // -------------------------------------------------------------
    // 2. Extra batches spread across courses, mixed statuses
    // -------------------------------------------------------------
    $batchIds = [];
    $batchDefs = [
        ['Batch 2024-A', '2024-01-15', '2024-02-01', '2024-07-30', 'completed'],
        ['Batch 2024-B', '2024-06-01', '2024-06-15', '2024-12-15', 'completed'],
        ['Batch 2025-B', '2025-01-10', '2025-01-20', '2025-07-20', 'active'],
        ['Batch 2025-C', '2025-06-01', '2025-06-10', '2025-12-10', 'active'],
        ['Batch 2026-A', '2026-08-01', '2026-08-15', '2027-02-15', 'upcoming'],
    ];
    foreach ($batchDefs as $i => [$name, $enroll, $start, $expected, $status]) {
        $courseId = $courseIds[$i % count($courseIds)];
        $code = 'B' . preg_replace('/[^0-9A-Z]/', '', strtoupper($name));
        $actual = $status === 'completed' ? $expected : null;
        $pdo->prepare("INSERT INTO batches (name, batch_code, course_id, enrollment_start_date, training_start_date, expected_completion_date, actual_completion_date, status)
                        VALUES (?,?,?,?,?,?,?,?)")
            ->execute([$name, $code, $courseId, $enroll, $start, $expected, $actual, $status]);
        $batchIds[] = (int) $pdo->lastInsertId();
    }
    // Include the pre-existing seed batch too, if present
    $existingBatch = $pdo->query("SELECT id FROM batches WHERE batch_code = 'B2025A'")->fetchColumn();
    if ($existingBatch) { $batchIds[] = (int) $existingBatch; }
    echo "Batches: +" . count($batchDefs) . " (total pool " . count($batchIds) . ")\n";

    // -------------------------------------------------------------
    // 3. Faculty (10 new)
    // -------------------------------------------------------------
    $facultyIds = $pdo->query("SELECT id FROM faculty")->fetchAll(PDO::FETCH_COLUMN);
    $departments = ['Theology Department', 'Christian Education', 'Church Administration', 'Music Ministry', 'Pastoral Care'];
    $titles = ['Pastor', 'Rev.', 'Dr.', 'Deacon', 'Deaconess', 'Elder'];
    for ($i = 0; $i < 10; $i++) {
        $first = pick($firstNames); $last = pick($lastNames);
        $email = strtolower($first . '.' . $last . $i . '@demo.rosrccg.org');
        $pdo->prepare("INSERT INTO users (role, email, password_hash, status) VALUES ('faculty', ?, ?, 'active')")
            ->execute([$email, $DEMO_PASSWORD_HASH]);
        $userId = (int) $pdo->lastInsertId();
        $staffId = generate_staff_id($pdo);
        $pdo->prepare("INSERT INTO faculty (user_id, staff_id, first_name, last_name, phone, department, title, can_view_students, can_post_announcements)
                        VALUES (?,?,?,?,?,?,?,1,1)")
            ->execute([$userId, $staffId, $first, $last, '080' . mt_rand(10000000, 99999999), pick($departments), pick($titles)]);
        $newFacultyId = (int) $pdo->lastInsertId();
        $facultyIds[] = $newFacultyId;

        // Assign each new faculty member to 1-2 random courses
        $assigned = (array) array_rand(array_flip($courseIds), min(2, count($courseIds)));
        foreach ((array) $assigned as $cid) {
            $pdo->prepare("INSERT IGNORE INTO faculty_courses (faculty_id, course_id) VALUES (?,?)")->execute([$newFacultyId, $cid]);
        }
    }
    echo "Faculty: +10 (total pool " . count($facultyIds) . ")\n";

    // -------------------------------------------------------------
    // 4. Students (150), spread across batches/courses with mixed
    //    lifecycle statuses
    // -------------------------------------------------------------
    $statusWeights = array_merge(
        array_fill(0, 65, 'active'),
        array_fill(0, 15, 'graduated'),
        array_fill(0, 15, 'registered'),
        array_fill(0, 5, 'withdrawn')
    );
    $studentIds = [];
    $sessionIds = $pdo->query("SELECT id FROM sessions")->fetchAll(PDO::FETCH_COLUMN);

    for ($i = 1; $i <= 150; $i++) {
        $first = pick($firstNames); $last = pick($lastNames);
        $email = strtolower($first . '.' . $last . '.' . $i . '@demo.student.org');
        $pdo->prepare("INSERT INTO users (role, email, password_hash, status) VALUES ('student', ?, ?, 'active')")
            ->execute([$email, $DEMO_PASSWORD_HASH]);
        $userId = (int) $pdo->lastInsertId();
        $regNumber = generate_reg_number($pdo);

        $status = pick($statusWeights);
        $courseId = pick($courseIds);
        $batchId = pick($batchIds);
        $enrollDate = randDateBetween('2024-01-01', '2026-08-01');
        $graduationDate = $status === 'graduated' ? randDateBetween($enrollDate, '2026-09-01') : null;
        $dob = randDateBetween('1985-01-01', '2005-01-01');

        $pdo->prepare("INSERT INTO students
            (user_id, reg_number, first_name, last_name, gender, date_of_birth, phone, address, state, country,
             church_parish, course_id, session_id, batch_id, status, enrollment_date, graduation_date)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
            ->execute([
                $userId, $regNumber, $first, $last, mt_rand(0, 1) ? 'Male' : 'Female', $dob,
                '070' . mt_rand(10000000, 99999999), mt_rand(1, 200) . ' Faith Street', pick($states), 'Nigeria',
                'RCCG ' . pick($lastNames) . ' Parish', $courseId, $sessionIds ? pick($sessionIds) : null, $batchId,
                $status, $enrollDate, $graduationDate,
            ]);
        $studentIds[] = ['id' => (int) $pdo->lastInsertId(), 'course_id' => $courseId, 'batch_id' => $batchId, 'status' => $status];
    }
    echo "Students: +150 (reg numbers + accounts created)\n";

    // -------------------------------------------------------------
    // 5. Materials (40) with real tiny placeholder PDF files on disk
    //    so downloads actually work end-to-end, not just DB rows
    // -------------------------------------------------------------
    $categoryIds = $pdo->query("SELECT id FROM categories")->fetchAll(PDO::FETCH_COLUMN);
    if (!is_dir(UPLOAD_MATERIALS_PATH)) { mkdir(UPLOAD_MATERIALS_PATH, 0755, true); }

    for ($i = 0; $i < 40; $i++) {
        $title = pick($materialTitles) . ' — Part ' . (($i % 5) + 1);
        $facultyId = pick($facultyIds);
        $courseId = mt_rand(0, 4) ? pick($courseIds) : null; // occasionally general (no course)
        $batchId = mt_rand(0, 3) ? null : pick($batchIds);   // mostly course-wide, sometimes batch-locked
        $categoryId = $categoryIds ? pick($categoryIds) : null;
        $storedName = bin2hex(random_bytes(16)) . '.pdf';

        // A minimal but genuinely valid single-page PDF, so finfo/browsers open it fine.
        $pdfBody = "%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n"
            . "2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n"
            . "3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\n"
            . "4 0 obj<</Length 80>>stream\nBT /F1 18 Tf 50 700 Td (" . addslashes($title) . ") Tj ET\nendstream endobj\n"
            . "5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n"
            . "trailer<</Root 1 0 R>>";
        file_put_contents(UPLOAD_MATERIALS_PATH . $storedName, $pdfBody);
        $writtenFiles[] = UPLOAD_MATERIALS_PATH . $storedName;
        $fileSize = filesize(UPLOAD_MATERIALS_PATH . $storedName);

        $pdo->prepare("INSERT INTO materials
            (title, description, course_id, batch_id, category_id, faculty_id, file_name, stored_name, file_type, file_size, status, download_count)
            VALUES (?,?,?,?,?,?,?,?, 'pdf', ?, 'published', ?)")
            ->execute([$title, "Demo learning material covering: $title.", $courseId, $batchId, $categoryId, $facultyId,
                str_replace(' ', '_', $title) . '.pdf', $storedName, $fileSize, mt_rand(0, 60)]);
    }
    echo "Materials: +40 (with real placeholder PDF files written to " . UPLOAD_MATERIALS_PATH . ")\n";

    // -------------------------------------------------------------
    // 6. Tests + questions + options (15 tests, ~5 questions each)
    // -------------------------------------------------------------
    $testIds = [];
    for ($i = 0; $i < 15; $i++) {
        $facultyId = pick($facultyIds);
        $courseId = pick($courseIds);
        $batchId = mt_rand(0, 2) ? null : pick($batchIds);
        $title = pick($testTitles) . ' #' . ($i + 1);
        $duration = pick([20, 30, 45, 60]);
        $passing = pick([40, 50, 60, 70]);

        // Mix of timing: some past/closed, some currently open, some upcoming
        $timingRoll = mt_rand(1, 3);
        if ($timingRoll === 1) { // closed
            $start = date('Y-m-d H:i:s', strtotime('-30 days'));
            $end = date('Y-m-d H:i:s', strtotime('-20 days'));
            $status = 'closed';
        } elseif ($timingRoll === 2) { // open now
            $start = date('Y-m-d H:i:s', strtotime('-2 days'));
            $end = date('Y-m-d H:i:s', strtotime('+5 days'));
            $status = 'published';
        } else { // upcoming
            $start = date('Y-m-d H:i:s', strtotime('+3 days'));
            $end = date('Y-m-d H:i:s', strtotime('+10 days'));
            $status = 'scheduled';
        }

        $pdo->prepare("INSERT INTO tests (title, description, course_id, batch_id, faculty_id, duration_minutes, passing_score, start_at, end_at, status, show_result_immediately)
                        VALUES (?,?,?,?,?,?,?,?,?,?,1)")
            ->execute([$title, "Demo test: $title.", $courseId, $batchId, $facultyId, $duration, $passing, $start, $end, $status]);
        $testId = (int) $pdo->lastInsertId();
        $testIds[] = ['id' => $testId, 'course_id' => $courseId, 'batch_id' => $batchId, 'status' => $status, 'passing' => $passing];

        // 5 questions per test: mix of mcq / true_false / short_answer
        $questionTypes = ['mcq', 'mcq', 'true_false', 'mcq', 'short_answer'];
        foreach ($questionTypes as $qi => $type) {
            $marks = pick([1, 2, 2, 3]);
            $correctText = $type === 'short_answer' ? pick(['Grace', 'Faith', 'Love', 'Jesus', 'Prayer']) : null;
            $pdo->prepare("INSERT INTO test_questions (test_id, question_text, question_type, marks, order_index, correct_answer_text)
                            VALUES (?,?,?,?,?,?)")
                ->execute([$testId, 'Sample question ' . ($qi + 1) . ' on ' . pick($topics) . '?', $type, $marks, $qi, $correctText]);
            $qId = (int) $pdo->lastInsertId();

            if ($type === 'mcq') {
                $options = ['Option A', 'Option B', 'Option C', 'Option D'];
                $correct = array_rand($options);
                foreach ($options as $oi => $opt) {
                    $pdo->prepare("INSERT INTO test_options (question_id, option_text, is_correct, order_index) VALUES (?,?,?,?)")
                        ->execute([$qId, $opt, $oi === $correct ? 1 : 0, $oi]);
                }
            } elseif ($type === 'true_false') {
                $correctBool = mt_rand(0, 1);
                $pdo->prepare("INSERT INTO test_options (question_id, option_text, is_correct, order_index) VALUES (?, 'True', ?, 0)")->execute([$qId, $correctBool]);
                $pdo->prepare("INSERT INTO test_options (question_id, option_text, is_correct, order_index) VALUES (?, 'False', ?, 1)")->execute([$qId, $correctBool ? 0 : 1]);
            }
        }
    }
    echo "Tests: +15 (with 5 questions + options each = 75 questions)\n";

    // -------------------------------------------------------------
    // 7. Test attempts: a plausible subset of students attempting
    //    closed/open tests they're eligible for
    // -------------------------------------------------------------
    $attemptCount = 0;
    foreach ($testIds as $test) {
        if ($test['status'] === 'scheduled') continue; // hasn't opened yet, nobody has attempted it

        $eligible = array_values(array_filter($studentIds, fn($s) =>
            $s['course_id'] === $test['course_id'] && in_array($s['status'], ['registered', 'active', 'graduated'], true)
        ));
        if (!$eligible) continue;

        shuffle($eligible);
        $numAttempts = min(count($eligible), mt_rand(3, 8));
        for ($a = 0; $a < $numAttempts; $a++) {
            $student = $eligible[$a];
            $totalMarks = (float) $pdo->query("SELECT COALESCE(SUM(marks),0) FROM test_questions WHERE test_id = {$test['id']}")->fetchColumn();
            $score = round($totalMarks * (mt_rand(30, 100) / 100), 2);
            $percentage = $totalMarks > 0 ? round(($score / $totalMarks) * 100, 2) : 0;
            $passed = $percentage >= $test['passing'] ? 1 : 0;
            $startedAt = date('Y-m-d H:i:s', strtotime('-' . mt_rand(1, 25) . ' days'));
            $submittedAt = date('Y-m-d H:i:s', strtotime($startedAt) + mt_rand(300, 2400));

            try {
                $pdo->prepare("INSERT INTO test_attempts (test_id, student_id, status, started_at, expires_at, submitted_at, score, total_marks, percentage, passed, time_taken_seconds)
                                VALUES (?,?, 'submitted', ?, ?, ?, ?, ?, ?, ?, ?)")
                    ->execute([$test['id'], $student['id'], $startedAt, $submittedAt, $submittedAt, $score, $totalMarks, $percentage, $passed, mt_rand(300, 2400)]);
                $attemptCount++;
            } catch (Throwable $e) {
                // UNIQUE(test_id, student_id) collision if a student was picked twice - skip silently
            }
        }
    }
    echo "Test attempts: +$attemptCount\n";

    // -------------------------------------------------------------
    // 8. Timetable entries (30)
    // -------------------------------------------------------------
    for ($i = 0; $i < 30; $i++) {
        $facultyRow = $pdo->prepare("SELECT faculty_id FROM faculty_courses ORDER BY RAND() LIMIT 1");
        $facultyRow->execute();
        $fc = $facultyRow->fetch();
        $facultyId = $fc ? $fc['faculty_id'] : pick($facultyIds);

        $courseId = mt_rand(0, 4) ? pick($courseIds) : null;
        $batchId = mt_rand(0, 2) ? null : pick($batchIds);
        $date = randDateBetween('2026-08-01', '2026-11-30');
        $startHour = pick([8, 9, 10, 11, 13, 14, 15]);

        $pdo->prepare("INSERT INTO timetable_entries (topic, faculty_id, course_id, batch_id, entry_date, start_time, end_time, created_by)
                        VALUES (?,?,?,?,?,?,?,1)")
            ->execute([pick($topics), $facultyId, $courseId, $batchId, $date,
                sprintf('%02d:00:00', $startHour), sprintf('%02d:00:00', $startHour + 1)]);
    }
    echo "Timetable entries: +30\n";

    // -------------------------------------------------------------
    // 9. Announcements (15)
    // -------------------------------------------------------------
    $announcementTitles = ['Upcoming Convention', 'New Semester Registration Open', 'Holiday Notice',
        'Library Hours Update', 'Special Prayer Meeting', 'Graduation Ceremony Date', 'Fee Payment Reminder',
        'New Course Available', 'Guest Speaker Session', 'Exam Timetable Released', 'Campus Maintenance Notice',
        'Volunteer Opportunities', 'Alumni Reunion', 'Scholarship Applications Open', 'System Maintenance Window'];
    $adminUserId = $pdo->query("SELECT id FROM users WHERE role = 'admin' LIMIT 1")->fetchColumn();
    foreach ($announcementTitles as $title) {
        $audience = pick(['all', 'students', 'faculty']);
        $pdo->prepare("INSERT INTO announcements (title, body, audience, posted_by_user_id, is_published, created_at)
                        VALUES (?,?,?,?,1,?)")
            ->execute([$title, "This is a demo announcement regarding: $title.", $audience, $adminUserId,
                date('Y-m-d H:i:s', strtotime('-' . mt_rand(0, 60) . ' days'))]);
    }
    echo "Announcements: +15\n";

    $pdo->commit();

    $totalNewRecords = count($courseNames) + count($batchDefs) + 10 + 150 + 40 + 15 + (15 * 5) + $attemptCount + 30 + 15;
    echo "\n=== Done. Approximately $totalNewRecords new records created across all modules. ===\n";
    echo "Demo login password for every generated student/faculty account: Demo@12345\n";

} catch (Throwable $e) {
    $pdo->rollBack();
    foreach ($writtenFiles as $f) {
        if (is_file($f)) { @unlink($f); }
    }
    echo "SEEDING FAILED - transaction rolled back and any placeholder files already written were cleaned up. No partial data left behind.\n";
    echo 'Error: ' . $e->getMessage() . "\n";
    exit(1);
}
