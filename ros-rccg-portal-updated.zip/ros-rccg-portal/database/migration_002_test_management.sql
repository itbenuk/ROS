-- =====================================================================
-- Migration 002: Faculty/Student Management + Test Management System
-- Run this against an EXISTING ros_rccg_portal database:
--   mysql -u root -p ros_rccg_portal < database/migration_002_test_management.sql
-- (For brand-new installs, these tables are already included at the
--  bottom of database/database.sql — you do not need to run this file too.)
-- =====================================================================

USE ros_rccg_portal;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- Faculty <-> Course assignment (which faculty teach which programmes).
-- This is what "students assigned to a faculty" resolves through:
-- a faculty member's students = students enrolled in courses they teach.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS faculty_courses (
    faculty_id      INT UNSIGNED NOT NULL,
    course_id       INT UNSIGNED NOT NULL,
    assigned_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (faculty_id, course_id),
    CONSTRAINT fk_fc_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
    CONSTRAINT fk_fc_course  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Generic per-user notifications (registration, test publish, submit, etc.)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notifications (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED NOT NULL,
    type            VARCHAR(50) NOT NULL,
    title           VARCHAR(200) NOT NULL,
    message         VARCHAR(500) NULL,
    link            VARCHAR(255) NULL,
    is_read         TINYINT(1) NOT NULL DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_notif_user (user_id, is_read),
    CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Tests
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tests (
    id                      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title                   VARCHAR(200) NOT NULL,
    description             TEXT NULL,
    course_id               INT UNSIGNED NULL,
    faculty_id              INT UNSIGNED NOT NULL,
    duration_minutes        SMALLINT UNSIGNED NOT NULL DEFAULT 30,
    passing_score           DECIMAL(6,2) NOT NULL DEFAULT 50,
    start_at                DATETIME NOT NULL,
    end_at                  DATETIME NOT NULL,
    status                  ENUM('draft','scheduled','published','closed') NOT NULL DEFAULT 'draft',
    shuffle_questions       TINYINT(1) NOT NULL DEFAULT 0,
    show_result_immediately TINYINT(1) NOT NULL DEFAULT 1,
    created_at              TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_tests_course (course_id),
    KEY idx_tests_faculty (faculty_id),
    KEY idx_tests_status (status),
    CONSTRAINT fk_tests_course  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE SET NULL,
    CONSTRAINT fk_tests_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Test questions
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS test_questions (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    test_id             INT UNSIGNED NOT NULL,
    question_text       TEXT NOT NULL,
    question_type       ENUM('mcq','true_false','short_answer') NOT NULL DEFAULT 'mcq',
    marks               DECIMAL(6,2) NOT NULL DEFAULT 1,
    order_index         SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    correct_answer_text VARCHAR(255) NULL, -- used only for short_answer (exact/normalized match grading)
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_tq_test (test_id),
    CONSTRAINT fk_tq_test FOREIGN KEY (test_id) REFERENCES tests(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Options for mcq / true_false questions
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS test_options (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    question_id     INT UNSIGNED NOT NULL,
    option_text     VARCHAR(255) NOT NULL,
    is_correct      TINYINT(1) NOT NULL DEFAULT 0,
    order_index     SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    KEY idx_topt_question (question_id),
    CONSTRAINT fk_topt_question FOREIGN KEY (question_id) REFERENCES test_questions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Explicit per-student test assignment (optional override).
-- If a test has NO rows here, it is implicitly assigned to every active
-- student in tests.course_id. If rows exist, only those students see it.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS test_assignments (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    test_id         INT UNSIGNED NOT NULL,
    student_id      INT UNSIGNED NOT NULL,
    assigned_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_test_student (test_id, student_id),
    CONSTRAINT fk_ta_test    FOREIGN KEY (test_id)    REFERENCES tests(id)    ON DELETE CASCADE,
    CONSTRAINT fk_ta_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Test attempts (one per student per test) - server-authoritative timer
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS test_attempts (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    test_id             INT UNSIGNED NOT NULL,
    student_id          INT UNSIGNED NOT NULL,
    status              ENUM('in_progress','submitted','auto_submitted','expired') NOT NULL DEFAULT 'in_progress',
    started_at          DATETIME NOT NULL,
    expires_at          DATETIME NOT NULL,   -- server-computed = started_at + duration, capped by test.end_at
    submitted_at        DATETIME NULL,
    score               DECIMAL(7,2) NULL,
    total_marks         DECIMAL(7,2) NULL,
    percentage          DECIMAL(5,2) NULL,
    passed              TINYINT(1) NULL,
    time_taken_seconds  INT UNSIGNED NULL,
    ip_address          VARCHAR(45) NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_attempt_test_student (test_id, student_id),
    KEY idx_attempts_status (status),
    CONSTRAINT fk_attempt_test    FOREIGN KEY (test_id)    REFERENCES tests(id)    ON DELETE CASCADE,
    CONSTRAINT fk_attempt_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Individual answers within an attempt
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS test_answers (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    attempt_id          BIGINT UNSIGNED NOT NULL,
    question_id         INT UNSIGNED NOT NULL,
    selected_option_id  INT UNSIGNED NULL,
    answer_text         VARCHAR(500) NULL,
    is_correct          TINYINT(1) NULL,
    marks_awarded       DECIMAL(6,2) NOT NULL DEFAULT 0,
    answered_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_answer_attempt_question (attempt_id, question_id),
    KEY idx_answers_question (question_id),
    CONSTRAINT fk_answer_attempt  FOREIGN KEY (attempt_id)  REFERENCES test_attempts(id)  ON DELETE CASCADE,
    CONSTRAINT fk_answer_question FOREIGN KEY (question_id) REFERENCES test_questions(id) ON DELETE CASCADE,
    CONSTRAINT fk_answer_option   FOREIGN KEY (selected_option_id) REFERENCES test_options(id) ON DELETE SET NULL
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- Seed: assign the sample faculty member to the sample courses so the
-- demo account has students/tests to manage immediately.
-- ---------------------------------------------------------------------
INSERT IGNORE INTO faculty_courses (faculty_id, course_id) VALUES (1, 1), (1, 2);
