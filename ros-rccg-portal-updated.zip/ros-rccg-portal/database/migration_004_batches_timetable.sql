-- =====================================================================
-- Migration 004: Student Batches, Lifecycle Status, Batch-Scoped Content,
-- and Timetable
-- Run against an EXISTING database:
--   mysql -u root -p ros_rccg_portal < database/migration_004_batches_timetable.sql
-- (Fresh installs already get this from database.sql.)
-- =====================================================================

USE ros_rccg_portal;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- Batches / cohorts. Each batch runs a training cycle (~6 months) and can
-- optionally be tied to a specific programme.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS batches (
    id                          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                        VARCHAR(120) NOT NULL,
    batch_code                  VARCHAR(30) NOT NULL,
    course_id                   INT UNSIGNED NULL,
    enrollment_start_date       DATE NULL,
    training_start_date         DATE NULL,
    expected_completion_date    DATE NULL,
    actual_completion_date      DATE NULL,
    status                      ENUM('upcoming','active','completed','archived') NOT NULL DEFAULT 'upcoming',
    created_at                  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at                  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_batches_code (batch_code),
    KEY idx_batches_course (course_id),
    KEY idx_batches_status (status),
    CONSTRAINT fk_batches_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Students: batch assignment + lifecycle status + individual dates
-- ---------------------------------------------------------------------
ALTER TABLE students
    ADD COLUMN batch_id INT UNSIGNED NULL AFTER session_id,
    ADD COLUMN status ENUM('registered','active','graduated','withdrawn') NOT NULL DEFAULT 'registered' AFTER batch_id,
    ADD COLUMN enrollment_date DATE NULL AFTER status,
    ADD COLUMN graduation_date DATE NULL AFTER enrollment_date,
    ADD KEY idx_students_batch (batch_id),
    ADD KEY idx_students_status (status),
    ADD CONSTRAINT fk_students_batch FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE SET NULL;

-- Backfill: existing students default to 'active' with their registration date as enrollment_date
UPDATE students SET status = 'active', enrollment_date = DATE(created_at) WHERE enrollment_date IS NULL;

-- ---------------------------------------------------------------------
-- Batch-scoped content: materials and tests can optionally be restricted
-- to a specific batch (in addition to their course). NULL = visible to
-- every batch enrolled in that course, preserving existing behaviour.
-- ---------------------------------------------------------------------
ALTER TABLE materials
    ADD COLUMN batch_id INT UNSIGNED NULL AFTER course_id,
    ADD KEY idx_materials_batch (batch_id),
    ADD CONSTRAINT fk_materials_batch FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE SET NULL;

ALTER TABLE tests
    ADD COLUMN batch_id INT UNSIGNED NULL AFTER course_id,
    ADD KEY idx_tests_batch (batch_id),
    ADD CONSTRAINT fk_tests_batch FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------
-- Timetable
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS timetable_entries (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    topic           VARCHAR(200) NOT NULL,
    faculty_id      INT UNSIGNED NOT NULL,
    course_id       INT UNSIGNED NULL,
    batch_id        INT UNSIGNED NULL,
    entry_date      DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    created_by      INT UNSIGNED NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_timetable_date (entry_date),
    KEY idx_timetable_faculty (faculty_id),
    KEY idx_timetable_course (course_id),
    KEY idx_timetable_batch (batch_id),
    CONSTRAINT fk_timetable_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
    CONSTRAINT fk_timetable_course  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE SET NULL,
    CONSTRAINT fk_timetable_batch   FOREIGN KEY (batch_id)   REFERENCES batches(id)  ON DELETE SET NULL,
    CONSTRAINT fk_timetable_creator FOREIGN KEY (created_by) REFERENCES users(id)    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Scalability: additional indexes for hot query paths identified in the
-- architecture review (see README section on scalability).
-- ---------------------------------------------------------------------
ALTER TABLE test_attempts ADD INDEX idx_attempts_student_status (student_id, status);
ALTER TABLE materials     ADD INDEX idx_materials_status_course (status, course_id);
ALTER TABLE audit_logs    ADD INDEX idx_audit_created (created_at);

SET FOREIGN_KEY_CHECKS = 1;

-- Seed a first batch so existing/new students have something to attach to.
INSERT INTO batches (name, batch_code, course_id, enrollment_start_date, training_start_date, expected_completion_date, status)
VALUES ('Batch 2025-A', 'B2025A', NULL, '2025-09-01', '2025-09-15', '2026-03-15', 'active');
