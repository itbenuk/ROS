-- =====================================================================
-- ROS RCCG Student Registration & Faculty Learning Management Portal
-- Database Schema (MySQL 8+)
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS ros_rccg_portal
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ros_rccg_portal;

-- ---------------------------------------------------------------------
-- 1. users  (single auth table for all roles: admin, faculty, student)
-- ---------------------------------------------------------------------
CREATE TABLE users (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role                ENUM('admin','faculty','student') NOT NULL,
    email               VARCHAR(150) NOT NULL,
    password_hash       VARCHAR(255) NOT NULL,
    status              ENUM('active','inactive','suspended') NOT NULL DEFAULT 'active',
    last_login_at       DATETIME NULL,
    failed_logins       TINYINT UNSIGNED NOT NULL DEFAULT 0,
    locked_until        DATETIME NULL,
    remember_token      VARCHAR(100) NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_role (role),
    KEY idx_users_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. courses / programmes
-- ---------------------------------------------------------------------
CREATE TABLE courses (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(150) NOT NULL,
    code            VARCHAR(30) NOT NULL,
    description     TEXT NULL,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_courses_code (code)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 3. academic / training sessions (e.g. 2025/2026 First Semester)
-- ---------------------------------------------------------------------
CREATE TABLE sessions (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    start_date      DATE NULL,
    end_date        DATE NULL,
    is_current      TINYINT(1) NOT NULL DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_sessions_name (name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4. categories (material categories)
-- ---------------------------------------------------------------------
CREATE TABLE categories (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    slug            VARCHAR(120) NOT NULL,
    description     VARCHAR(255) NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_categories_slug (slug)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 5. batches (student cohorts; each runs a ~6 month training cycle)
-- ---------------------------------------------------------------------
CREATE TABLE batches (
    id                          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                        VARCHAR(120) NOT NULL,
    batch_code                  VARCHAR(30) NOT NULL,
    course_id                   INT UNSIGNED NULL,
    enrollment_start_date       DATE NULL,
    training_start_date         DATE NULL,
    expected_completion_date    DATE NULL,
    actual_completion_date      DATE NULL,
    status                      ENUM('upcoming','active','completed','archived') NOT NULL DEFAULT 'upcoming',
    created_at                  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at                  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_batches_code (batch_code),
    KEY idx_batches_course (course_id),
    KEY idx_batches_status (status),
    CONSTRAINT fk_batches_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 6. students  (extends users)
-- ---------------------------------------------------------------------
CREATE TABLE students (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id             INT UNSIGNED NOT NULL,
    reg_number          VARCHAR(30) NOT NULL,
    first_name          VARCHAR(80) NOT NULL,
    middle_name         VARCHAR(80) NULL,
    last_name           VARCHAR(80) NOT NULL,
    gender              ENUM('Male','Female') NOT NULL,
    date_of_birth       DATE NOT NULL,
    phone               VARCHAR(25) NOT NULL,
    whatsapp            VARCHAR(25) NULL,
    address             VARCHAR(255) NULL,
    state               VARCHAR(80) NULL,
    country             VARCHAR(80) NULL,
    church_parish       VARCHAR(150) NULL,
    rccg_region         VARCHAR(100) NULL,
    rccg_province       VARCHAR(100) NULL,
    rccg_area           VARCHAR(100) NULL,
    rccg_parish         VARCHAR(100) NULL,
    course_id           INT UNSIGNED NULL,
    session_id          INT UNSIGNED NULL,
    batch_id            INT UNSIGNED NULL,
    status              ENUM('registered','active','graduated','withdrawn') NOT NULL DEFAULT 'registered',
    enrollment_date     DATE NULL,
    graduation_date     DATE NULL,
    -- Whether this student (once graduated) is allowed to appear on the
    -- public Alumni page. Has no effect while status <> 'graduated'.
    -- Alumni are NEVER a separate table/record - this column just lets an
    -- admin opt a graduate out of public display while keeping their
    -- academic record intact.
    show_in_alumni      TINYINT(1) NOT NULL DEFAULT 1,
    passport_photo      VARCHAR(255) NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_students_reg (reg_number),
    UNIQUE KEY uq_students_user (user_id),
    KEY idx_students_course (course_id),
    KEY idx_students_session (session_id),
    KEY idx_students_batch (batch_id),
    KEY idx_students_status (status),
    KEY idx_students_alumni (status, show_in_alumni),
    CONSTRAINT fk_students_user   FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
    CONSTRAINT fk_students_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL,
    CONSTRAINT fk_students_session FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE SET NULL,
    CONSTRAINT fk_students_batch  FOREIGN KEY (batch_id)  REFERENCES batches(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 6b. leadership_profiles
-- Public "General Overseer / Parish Pastor" leadership section. Fully
-- admin-managed (add/edit/replace/remove) - not tied to the users table
-- since leadership figures do not necessarily have a portal login.
-- ---------------------------------------------------------------------
CREATE TABLE leadership_profiles (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category        ENUM('general_overseer','overseer_wife','parish_pastor','pastor_wife','other') NOT NULL DEFAULT 'other',
    full_name       VARCHAR(150) NOT NULL,
    title           VARCHAR(150) NOT NULL,
    bio             TEXT NULL,
    photo           VARCHAR(255) NULL,
    display_order   INT UNSIGNED NOT NULL DEFAULT 0,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_leadership_category (category),
    KEY idx_leadership_active (is_active),
    KEY idx_leadership_order (display_order)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 7. faculty  (extends users)
-- ---------------------------------------------------------------------
CREATE TABLE faculty (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id             INT UNSIGNED NOT NULL,
    staff_id            VARCHAR(30) NOT NULL,
    first_name          VARCHAR(80) NOT NULL,
    last_name           VARCHAR(80) NOT NULL,
    phone               VARCHAR(25) NULL,
    department          VARCHAR(120) NULL,
    title               VARCHAR(80) NULL,
    bio                 TEXT NULL,
    photo               VARCHAR(255) NULL,
    -- Whether this faculty member appears in the "ROS Leadership" section
    -- of the public Leadership page. Defaults to shown; an admin can hide
    -- an individual staff member without touching their account/status.
    show_on_leadership  TINYINT(1) NOT NULL DEFAULT 1,
    can_view_students   TINYINT(1) NOT NULL DEFAULT 1,
    can_post_announcements TINYINT(1) NOT NULL DEFAULT 1,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_faculty_staff (staff_id),
    UNIQUE KEY uq_faculty_user (user_id),
    CONSTRAINT fk_faculty_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 8. materials
-- ---------------------------------------------------------------------
CREATE TABLE materials (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(200) NOT NULL,
    description     TEXT NULL,
    course_id       INT UNSIGNED NULL,
    batch_id        INT UNSIGNED NULL,
    category_id     INT UNSIGNED NULL,
    faculty_id      INT UNSIGNED NOT NULL,
    file_name       VARCHAR(255) NOT NULL,
    stored_name     VARCHAR(255) NOT NULL,
    file_type       VARCHAR(20) NOT NULL,
    file_size       INT UNSIGNED NOT NULL,
    status          ENUM('published','draft','archived') NOT NULL DEFAULT 'published',
    download_count  INT UNSIGNED NOT NULL DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_materials_course (course_id),
    KEY idx_materials_batch (batch_id),
    KEY idx_materials_category (category_id),
    KEY idx_materials_faculty (faculty_id),
    KEY idx_materials_status (status),
    KEY idx_materials_status_course (status, course_id),
    KEY idx_materials_title (title),
    CONSTRAINT fk_materials_course   FOREIGN KEY (course_id)   REFERENCES courses(id)    ON DELETE SET NULL,
    CONSTRAINT fk_materials_batch    FOREIGN KEY (batch_id)    REFERENCES batches(id)    ON DELETE SET NULL,
    CONSTRAINT fk_materials_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    CONSTRAINT fk_materials_faculty  FOREIGN KEY (faculty_id)  REFERENCES faculty(id)    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 9. material_downloads (log every download for stats)
-- ---------------------------------------------------------------------
CREATE TABLE material_downloads (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    material_id     INT UNSIGNED NOT NULL,
    student_id      INT UNSIGNED NOT NULL,
    ip_address      VARCHAR(45) NULL,
    downloaded_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_downloads_material (material_id),
    KEY idx_downloads_student (student_id),
    CONSTRAINT fk_downloads_material FOREIGN KEY (material_id) REFERENCES materials(id) ON DELETE CASCADE,
    CONSTRAINT fk_downloads_student  FOREIGN KEY (student_id)  REFERENCES students(id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 10. announcements
-- ---------------------------------------------------------------------
CREATE TABLE announcements (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(200) NOT NULL,
    body            TEXT NOT NULL,
    audience        ENUM('all','students','faculty') NOT NULL DEFAULT 'all',
    posted_by_user_id INT UNSIGNED NOT NULL,
    is_published    TINYINT(1) NOT NULL DEFAULT 1,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_announcements_audience (audience),
    CONSTRAINT fk_announcements_user FOREIGN KEY (posted_by_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE announcement_reads (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    announcement_id INT UNSIGNED NOT NULL,
    user_id         INT UNSIGNED NOT NULL,
    read_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_read (announcement_id, user_id),
    CONSTRAINT fk_reads_announcement FOREIGN KEY (announcement_id) REFERENCES announcements(id) ON DELETE CASCADE,
    CONSTRAINT fk_reads_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 11. password_resets
-- ---------------------------------------------------------------------
CREATE TABLE password_resets (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED NOT NULL,
    token_hash      VARCHAR(255) NOT NULL,
    expires_at      DATETIME NOT NULL,
    used            TINYINT(1) NOT NULL DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_reset_user (user_id),
    CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 12. audit_logs
-- ---------------------------------------------------------------------
CREATE TABLE audit_logs (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED NULL,
    action          VARCHAR(150) NOT NULL,
    details         TEXT NULL,
    ip_address      VARCHAR(45) NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_audit_user (user_id),
    KEY idx_audit_action (action),
    KEY idx_audit_created (created_at),
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 13. system_settings
-- ---------------------------------------------------------------------
CREATE TABLE system_settings (
    setting_key     VARCHAR(100) PRIMARY KEY,
    setting_value   TEXT NULL,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 14. faculty_courses (which faculty teach which programmes; a faculty's
--     "students" resolve as everyone enrolled in a course they teach)
-- ---------------------------------------------------------------------
CREATE TABLE faculty_courses (
    faculty_id      INT UNSIGNED NOT NULL,
    course_id       INT UNSIGNED NOT NULL,
    assigned_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (faculty_id, course_id),
    CONSTRAINT fk_fc_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
    CONSTRAINT fk_fc_course  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 15. notifications
-- ---------------------------------------------------------------------
CREATE TABLE notifications (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED NOT NULL,
    type            VARCHAR(50) NOT NULL,
    title           VARCHAR(200) NOT NULL,
    message         VARCHAR(500) NULL,
    link            VARCHAR(255) NULL,
    is_read         TINYINT(1) NOT NULL DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_notif_user (user_id, is_read),
    CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 16. tests
-- ---------------------------------------------------------------------
CREATE TABLE tests (
    id                      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title                   VARCHAR(200) NOT NULL,
    description             TEXT NULL,
    course_id               INT UNSIGNED NULL,
    batch_id                INT UNSIGNED NULL,
    faculty_id              INT UNSIGNED NOT NULL,
    duration_minutes        SMALLINT UNSIGNED NOT NULL DEFAULT 30,
    passing_score           DECIMAL(6,2) NOT NULL DEFAULT 50,
    start_at                DATETIME NOT NULL,
    end_at                  DATETIME NOT NULL,
    status                  ENUM('draft','scheduled','published','closed') NOT NULL DEFAULT 'draft',
    shuffle_questions       TINYINT(1) NOT NULL DEFAULT 0,
    show_result_immediately TINYINT(1) NOT NULL DEFAULT 1,
    created_at              TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_tests_course (course_id),
    KEY idx_tests_batch (batch_id),
    KEY idx_tests_faculty (faculty_id),
    KEY idx_tests_status (status),
    CONSTRAINT fk_tests_course  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE SET NULL,
    CONSTRAINT fk_tests_batch   FOREIGN KEY (batch_id)   REFERENCES batches(id)  ON DELETE SET NULL,
    CONSTRAINT fk_tests_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 17. test_questions
-- ---------------------------------------------------------------------
CREATE TABLE test_questions (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    test_id             INT UNSIGNED NOT NULL,
    question_text       TEXT NOT NULL,
    question_type       ENUM('mcq','true_false','short_answer') NOT NULL DEFAULT 'mcq',
    marks               DECIMAL(6,2) NOT NULL DEFAULT 1,
    order_index         SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    correct_answer_text VARCHAR(255) NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_tq_test (test_id),
    CONSTRAINT fk_tq_test FOREIGN KEY (test_id) REFERENCES tests(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 18. test_options
-- ---------------------------------------------------------------------
CREATE TABLE test_options (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    question_id     INT UNSIGNED NOT NULL,
    option_text     VARCHAR(255) NOT NULL,
    is_correct      TINYINT(1) NOT NULL DEFAULT 0,
    order_index     SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    KEY idx_topt_question (question_id),
    CONSTRAINT fk_topt_question FOREIGN KEY (question_id) REFERENCES test_questions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 19. test_assignments (optional explicit per-student override)
-- ---------------------------------------------------------------------
CREATE TABLE test_assignments (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    test_id         INT UNSIGNED NOT NULL,
    student_id      INT UNSIGNED NOT NULL,
    assigned_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_test_student (test_id, student_id),
    CONSTRAINT fk_ta_test    FOREIGN KEY (test_id)    REFERENCES tests(id)    ON DELETE CASCADE,
    CONSTRAINT fk_ta_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 20. test_attempts (server-authoritative timer state)
-- ---------------------------------------------------------------------
CREATE TABLE test_attempts (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    test_id             INT UNSIGNED NOT NULL,
    student_id          INT UNSIGNED NOT NULL,
    status              ENUM('in_progress','submitted','auto_submitted','expired','violation_submitted') NOT NULL DEFAULT 'in_progress',
    termination_reason  VARCHAR(255) NULL,
    started_at          DATETIME NOT NULL,
    expires_at          DATETIME NOT NULL,
    submitted_at        DATETIME NULL,
    score               DECIMAL(7,2) NULL,
    total_marks         DECIMAL(7,2) NULL,
    percentage          DECIMAL(5,2) NULL,
    passed              TINYINT(1) NULL,
    time_taken_seconds  INT UNSIGNED NULL,
    ip_address          VARCHAR(45) NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_attempt_test_student (test_id, student_id),
    KEY idx_attempts_status (status),
    KEY idx_attempts_student_status (student_id, status),
    CONSTRAINT fk_attempt_test    FOREIGN KEY (test_id)    REFERENCES tests(id)    ON DELETE CASCADE,
    CONSTRAINT fk_attempt_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 21. test_answers
-- ---------------------------------------------------------------------
CREATE TABLE test_answers (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    attempt_id          BIGINT UNSIGNED NOT NULL,
    question_id         INT UNSIGNED NOT NULL,
    selected_option_id  INT UNSIGNED NULL,
    answer_text         VARCHAR(500) NULL,
    is_correct          TINYINT(1) NULL,
    marks_awarded       DECIMAL(6,2) NOT NULL DEFAULT 0,
    answered_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_answer_attempt_question (attempt_id, question_id),
    KEY idx_answers_question (question_id),
    CONSTRAINT fk_answer_attempt  FOREIGN KEY (attempt_id)  REFERENCES test_attempts(id)  ON DELETE CASCADE,
    CONSTRAINT fk_answer_question FOREIGN KEY (question_id) REFERENCES test_questions(id) ON DELETE CASCADE,
    CONSTRAINT fk_answer_option   FOREIGN KEY (selected_option_id) REFERENCES test_options(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 22. timetable_entries
-- ---------------------------------------------------------------------
CREATE TABLE timetable_entries (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    topic           VARCHAR(200) NOT NULL,
    faculty_id      INT UNSIGNED NOT NULL,
    course_id       INT UNSIGNED NULL,
    batch_id        INT UNSIGNED NULL,
    entry_date      DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    created_by      INT UNSIGNED NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_timetable_date (entry_date),
    KEY idx_timetable_faculty (faculty_id),
    KEY idx_timetable_course (course_id),
    KEY idx_timetable_batch (batch_id),
    CONSTRAINT fk_timetable_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
    CONSTRAINT fk_timetable_course  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE SET NULL,
    CONSTRAINT fk_timetable_batch   FOREIGN KEY (batch_id)   REFERENCES batches(id)  ON DELETE SET NULL,
    CONSTRAINT fk_timetable_creator FOREIGN KEY (created_by) REFERENCES users(id)    ON DELETE CASCADE
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- SEED DATA
-- =====================================================================

INSERT INTO system_settings (setting_key, setting_value) VALUES
('site_name', 'ROS RCCG Student & Faculty Portal'),
('site_email', 'info@rosrccg.org'),
('max_upload_mb', '25'),
('allow_registration', '1'),
('maintenance_mode', '0');

INSERT INTO sessions (name, start_date, end_date, is_current) VALUES
('2025/2026 Session', '2025-09-01', '2026-07-31', 1),
('2024/2025 Session', '2024-09-01', '2025-07-31', 0);

INSERT INTO courses (name, code, description, is_active) VALUES
('Certificate in Christian Ministry', 'CCM101', 'Foundational ministry training programme.', 1),
('Diploma in Theology', 'DTH201', 'In-depth theological studies.', 1),
('Leadership & Church Administration', 'LCA301', 'Church leadership and administration skills.', 1),
('Choir & Worship Ministration', 'CWM110', 'Music and worship ministration training.', 1);

-- Placeholder slots for the four core leadership profiles - ready for the
-- administrator to fill in from Admin > Leadership without touching code.
INSERT INTO leadership_profiles (category, full_name, title, bio, display_order, is_active) VALUES
('general_overseer', 'General Overseer', 'General Overseer, RCCG', 'Profile details coming soon.', 1, 1),
('overseer_wife', "General Overseer's Wife", "General Overseer's Wife", 'Profile details coming soon.', 2, 1),
('parish_pastor', 'Parish Pastor', 'Parish Pastor', 'Profile details coming soon.', 3, 1),
('pastor_wife', "Parish Pastor's Wife", "Parish Pastor's Wife", 'Profile details coming soon.', 4, 1);

INSERT INTO categories (name, slug, description) VALUES
('Lecture Notes', 'lecture-notes', 'Class notes and slides'),
('Video Lessons', 'video-lessons', 'Recorded teaching sessions'),
('Audio Sermons', 'audio-sermons', 'Sermon and teaching audio'),
('Assignments', 'assignments', 'Take-home assignments'),
('E-Books', 'e-books', 'Reading materials and books');

-- Default administrator: email admin@rosrccg.org / password: Admin@12345
-- NOTE: change this password immediately after first login.
INSERT INTO users (role, email, password_hash, status) VALUES
('admin', 'admin@rosrccg.org', '$2b$10$6OUImtYg1zJu5iH1yN42n.euwmGXIRFrZHEjhiHDDdwtmno3ot94K', 'active');

-- Sample faculty user: faculty@rosrccg.org / password: Faculty@12345
INSERT INTO users (role, email, password_hash, status) VALUES
('faculty', 'faculty@rosrccg.org', '$2b$10$I6.hR/kWB5zeunvA5UlsmOozve0clXDCXymxBaxNy0zSP3uuqGjeq', 'active');

INSERT INTO faculty (user_id, staff_id, first_name, last_name, phone, department, title)
VALUES (2, 'FAC-0001', 'Samuel', 'Adeyemi', '08030000000', 'Theology Department', 'Rev.');

-- Give the sample faculty member ownership of the first two courses so the
-- demo account has students/tests to manage immediately.
INSERT INTO faculty_courses (faculty_id, course_id) VALUES (1, 1), (1, 2);

-- Seed a first batch (cohort) tied to the first course, ~6 months of training.
INSERT INTO batches (name, batch_code, course_id, enrollment_start_date, training_start_date, expected_completion_date, status)
VALUES ('Batch 2025-A', 'B2025A', 1, '2025-09-01', '2025-09-15', '2026-03-15', 'active');
