-- =====================================================================
-- Migration 003: Exam monitoring (tab-switch detection)
-- Run this against an EXISTING ros_rccg_portal database:
--   mysql -u root -p ros_rccg_portal < database/migration_003_exam_monitoring.sql
-- (Fresh installs already get this from database.sql.)
-- =====================================================================

USE ros_rccg_portal;

ALTER TABLE test_attempts
    MODIFY COLUMN status ENUM('in_progress','submitted','auto_submitted','expired','violation_submitted') NOT NULL DEFAULT 'in_progress',
    ADD COLUMN termination_reason VARCHAR(255) NULL AFTER status;
