<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
$pageTitle = 'Manage Materials';

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];

// Handle delete (faculty can only delete their own materials)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    require_csrf_or_die();
    $id = (int) $_POST['delete_id'];
    $stmt = $pdo->prepare("SELECT * FROM materials WHERE id = ? AND faculty_id = ?");
    $stmt->execute([$id, $facultyId]);
    if ($material = $stmt->fetch()) {
        $path = UPLOAD_MATERIALS_PATH . $material['stored_name'];
        if (is_file($path)) unlink($path);
        $pdo->prepare("DELETE FROM materials WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'material_deleted', "Material ID: $id");
        flash('success', 'Material deleted successfully.');
    } else {
        flash('error', 'Unauthorized or material not found.');
    }
    redirect('/faculty/materials.php');
}

$search = clean_str($_GET['q'] ?? '');
$where = ["faculty_id = ?"];
$params = [$facultyId];
if ($search !== '') {
    $where[] = "title LIKE ?";
    $params[] = "%$search%";
}
$whereSql = implode(' AND ', $where);

$stmt = $pdo->prepare("SELECT m.*, c.name AS course_name, cat.name AS category_name
                        FROM materials m
                        LEFT JOIN courses c ON c.id = m.course_id
                        LEFT JOIN categories cat ON cat.id = m.category_id
                        WHERE $whereSql ORDER BY m.created_at DESC");
$stmt->execute($params);
$materials = $stmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="section-title mb-0">Manage Materials</h3>
      <a href="<?= BASE_URL ?>/faculty/upload-material.php" class="btn btn-gold"><i class="fa-solid fa-plus me-2"></i>Upload New</a>
    </div>

    <div class="card p-3 mb-3">
      <form class="row g-2" method="get">
        <div class="col-md-6"><input type="text" name="q" class="form-control" placeholder="Search by title..." value="<?= e($search) ?>"></div>
        <div class="col-md-2"><button class="btn btn-outline-secondary w-100" type="submit">Search</button></div>
      </form>
    </div>

    <div class="card p-4">
      <?php if (!$materials): ?>
        <div class="empty-state"><i class="fa-solid fa-folder-open"></i><p>No materials uploaded yet.</p></div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table align-middle">
            <thead><tr><th>Title</th><th>Course</th><th>Category</th><th>Type</th><th>Status</th><th>Downloads</th><th>Uploaded</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($materials as $m): ?>
              <tr>
                <td class="fw-semibold"><?= e($m['title']) ?></td>
                <td><?= e($m['course_name'] ?? '-') ?></td>
                <td><?= e($m['category_name'] ?? '-') ?></td>
                <td><span class="badge text-bg-light text-uppercase"><?= e($m['file_type']) ?></span></td>
                <td><span class="badge badge-status-<?= e($m['status']) ?> px-2 py-1"><?= e(ucfirst($m['status'])) ?></span></td>
                <td><?= (int)$m['download_count'] ?></td>
                <td class="text-muted small"><?= time_ago($m['created_at']) ?></td>
                <td class="text-end">
                  <a href="<?= BASE_URL ?>/faculty/edit-material.php?id=<?= (int)$m['id'] ?>" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-pen"></i></a>
                  <form method="post" class="d-inline" data-confirm-delete="Delete this material permanently?">
                    <?= csrf_field() ?>
                    <input type="hidden" name="delete_id" value="<?= (int)$m['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
