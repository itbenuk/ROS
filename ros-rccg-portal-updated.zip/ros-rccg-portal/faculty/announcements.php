<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
$pageTitle = 'Announcements';

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];

$fstmt = $pdo->prepare("SELECT can_post_announcements FROM faculty WHERE id = ?");
$fstmt->execute([$facultyId]);
$canPost = (bool) $fstmt->fetch()['can_post_announcements'];

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    if (!$canPost) {
        flash('error', 'You are not authorized to post announcements.');
        redirect('/faculty/announcements.php');
    }
    $title = clean_str($_POST['title'] ?? '');
    $body = clean_str($_POST['body'] ?? '');
    if ($title === '' || $body === '') {
        $errors[] = 'Title and message are required.';
    } else {
        $pdo->prepare("INSERT INTO announcements (title, body, audience, posted_by_user_id) VALUES (?,?,'students',?)")
            ->execute([$title, $body, $_SESSION['user_id']]);
        audit_log($_SESSION['user_id'], 'announcement_posted', $title);
        flash('success', 'Announcement published.');
        redirect('/faculty/announcements.php');
    }
}

$mine = $pdo->prepare("SELECT * FROM announcements WHERE posted_by_user_id = ? ORDER BY created_at DESC");
$mine->execute([$_SESSION['user_id']]);
$mine = $mine->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Announcements</h3>

    <?php if ($canPost): ?>
    <div class="card p-4 mb-4">
      <h6 class="fw-bold mb-3">Post New Announcement</h6>
      <?php if ($errors): ?><div class="alert alert-danger"><?= e($errors[0]) ?></div><?php endif; ?>
      <form method="post">
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label">Title</label>
          <input type="text" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Message</label>
          <textarea name="body" rows="3" class="form-control" required></textarea>
        </div>
        <button type="submit" class="btn btn-gold"><i class="fa-solid fa-paper-plane me-2"></i>Publish to Students</button>
      </form>
    </div>
    <?php else: ?>
      <div class="alert alert-info">You do not currently have permission to post announcements. Contact the administrator.</div>
    <?php endif; ?>

    <div class="card p-4">
      <h6 class="fw-bold mb-3">My Announcements</h6>
      <?php if (!$mine): ?>
        <div class="empty-state"><i class="fa-solid fa-bullhorn"></i><p>You haven't posted any announcements.</p></div>
      <?php else: foreach ($mine as $a): ?>
        <div class="border-bottom pb-2 mb-2">
          <div class="fw-semibold"><?= e($a['title']) ?></div>
          <p class="mb-1 small"><?= nl2br(e($a['body'])) ?></p>
          <div class="text-muted small"><?= time_ago($a['created_at']) ?></div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
