<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
$pageTitle = 'Students';

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];

$permStmt = $pdo->prepare("SELECT can_view_students FROM faculty WHERE id = ?");
$permStmt->execute([$facultyId]);
$canView = (bool) $permStmt->fetch()['can_view_students'];

if ($canView) {
    // A faculty member's students = students enrolled in any course this faculty teaches.
    $myCourseIds = $pdo->prepare("SELECT course_id FROM faculty_courses WHERE faculty_id = ?");
    $myCourseIds->execute([$facultyId]);
    $myCourseIds = array_map('intval', array_column($myCourseIds->fetchAll(), 'course_id'));

    $search = clean_str($_GET['q'] ?? '');
    $courseId = (int) ($_GET['course_id'] ?? 0);
    $sort = in_array($_GET['sort'] ?? '', ['name','reg_number','course'], true) ? $_GET['sort'] : 'name';
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $perPage = 15;

    if (!$myCourseIds) {
        $students = [];
        $total = 0;
        $p = paginate(0, $perPage, 1);
    } else {
        $placeholders = implode(',', array_fill(0, count($myCourseIds), '?'));
        $where = ["s.course_id IN ($placeholders)"];
        $params = $myCourseIds;

        if ($search !== '') {
            $where[] = "(s.first_name LIKE ? OR s.last_name LIKE ? OR s.reg_number LIKE ? OR u.email LIKE ?)";
            array_push($params, "%$search%", "%$search%", "%$search%", "%$search%");
        }
        if ($courseId && in_array($courseId, $myCourseIds, true)) { $where[] = "s.course_id = ?"; $params[] = $courseId; }
        $whereSql = implode(' AND ', $where);

        $countStmt = $pdo->prepare("SELECT COUNT(*) c FROM students s JOIN users u ON u.id = s.user_id WHERE $whereSql");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetch()['c'];
        $p = paginate($total, $perPage, $page);

        $orderSql = match ($sort) {
            'reg_number' => 's.reg_number ASC',
            'course'     => 'c.name ASC',
            default      => 's.first_name ASC, s.last_name ASC',
        };

        $sql = "SELECT s.id, s.reg_number, s.first_name, s.last_name, s.phone, s.status AS lifecycle_status,
                       u.email, u.status AS account_status, c.name AS course_name, se.name AS session_name, b.name AS batch_name,
                       (SELECT COUNT(*) FROM test_attempts ta JOIN tests t ON t.id = ta.test_id WHERE ta.student_id = s.id AND t.faculty_id = ?) AS test_attempts
                FROM students s JOIN users u ON u.id = s.user_id
                LEFT JOIN courses c ON c.id = s.course_id
                LEFT JOIN sessions se ON se.id = s.session_id
                LEFT JOIN batches b ON b.id = s.batch_id
                WHERE $whereSql ORDER BY $orderSql LIMIT {$p['perPage']} OFFSET {$p['offset']}";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_merge([$facultyId], $params));
        $students = $stmt->fetchAll();
    }

    $courses = $myCourseIds
        ? (function () use ($pdo, $myCourseIds) {
            $ph = implode(',', array_fill(0, count($myCourseIds), '?'));
            $s = $pdo->prepare("SELECT id, name FROM courses WHERE id IN ($ph) ORDER BY name");
            $s->execute($myCourseIds);
            return $s->fetchAll();
        })()
        : [];
}

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Registered Students</h3>

    <?php if (!$canView): ?>
      <div class="alert alert-info">
        <i class="fa-solid fa-lock me-2"></i>You do not currently have permission to view the student list.
        Please contact the administrator if you believe this is a mistake.
      </div>
    <?php else: ?>

    <div class="card p-3 mb-3">
      <form class="row g-2" method="get">
        <div class="col-md-5"><input type="text" name="q" class="form-control" placeholder="Search by name, reg. no. or email..." value="<?= e($search) ?>"></div>
        <div class="col-md-3">
          <select name="course_id" class="form-select">
            <option value="">All My Programmes</option>
            <?php foreach ($courses as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= $courseId == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-2">
          <select name="sort" class="form-select">
            <option value="name" <?= $sort==='name'?'selected':'' ?>>Sort: Name</option>
            <option value="reg_number" <?= $sort==='reg_number'?'selected':'' ?>>Sort: Reg. No.</option>
            <option value="course" <?= $sort==='course'?'selected':'' ?>>Sort: Programme</option>
          </select>
        </div>
        <div class="col-md-2"><button class="btn btn-gold w-100" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button></div>
      </form>
    </div>

    <div class="card p-4">
      <?php if (!$myCourseIds): ?>
        <div class="empty-state"><i class="fa-solid fa-user-graduate"></i><p>You are not yet assigned to any course, so no students are visible. Contact the administrator.</p></div>
      <?php elseif (!$students): ?>
        <div class="empty-state"><i class="fa-solid fa-user-graduate"></i><p>No students found.</p></div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Reg. No.</th><th>Name</th><th>Email</th><th>Programme</th><th>Batch</th><th>Status</th><th>Test Attempts</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($students as $s): ?>
            <tr>
              <td><?= e($s['reg_number']) ?></td>
              <td><?= e($s['first_name'] . ' ' . $s['last_name']) ?></td>
              <td><?= e($s['email']) ?></td>
              <td><?= e($s['course_name'] ?? '-') ?></td>
              <td><?= e($s['batch_name'] ?? '-') ?></td>
              <td><span class="badge badge-<?= match($s['lifecycle_status']) { 'active'=>'active','graduated'=>'graduated','withdrawn'=>'suspended', default=>'inactive' } ?> px-2 py-1"><?= e(ucfirst($s['lifecycle_status'])) ?></span></td>
              <td><?= (int)$s['test_attempts'] ?></td>
              <td class="text-end"><a href="<?= BASE_URL ?>/faculty/student-view.php?id=<?= (int)$s['id'] ?>" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-eye"></i></a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php if ($p['totalPages'] > 1): ?>
        <nav class="mt-3"><ul class="pagination justify-content-center">
          <?php for ($i=1;$i<=$p['totalPages'];$i++): $qs=$_GET; $qs['page']=$i; ?>
            <li class="page-item <?= $i===$p['currentPage']?'active':'' ?>"><a class="page-link" href="?<?= http_build_query($qs) ?>"><?= $i ?></a></li>
          <?php endfor; ?>
        </ul></nav>
      <?php endif; ?>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
