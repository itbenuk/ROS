<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];
$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$test = null;

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM tests WHERE id = ? AND faculty_id = ?");
    $stmt->execute([$id, $facultyId]);
    $test = $stmt->fetch();
    if (!$test) {
        flash('error', 'Test not found or you do not own it.');
        redirect('/faculty/tests.php');
    }
    if ($test['status'] !== 'draft') {
        flash('warning', 'This test is live. Unpublish it first if you need to change its schedule or scoring.');
    }
}
$pageTitle = $test ? 'Edit Test' : 'Create Test';
$errors = [];

$myCourses = $pdo->prepare("SELECT c.id, c.name FROM faculty_courses fc JOIN courses c ON c.id = fc.course_id WHERE fc.faculty_id = ? ORDER BY c.name");
$myCourses->execute([$facultyId]);
$myCourses = $myCourses->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();

    $title = clean_str($_POST['title'] ?? '');
    $description = clean_str($_POST['description'] ?? '');
    $courseId = (int) ($_POST['course_id'] ?? 0);
    $duration = max(1, (int) ($_POST['duration_minutes'] ?? 30));
    $passingScore = max(0, min(100, (float) ($_POST['passing_score'] ?? 50)));
    $startAt = $_POST['start_at'] ?? '';
    $endAt = $_POST['end_at'] ?? '';
    $shuffle = isset($_POST['shuffle_questions']) ? 1 : 0;
    $showResult = isset($_POST['show_result_immediately']) ? 1 : 0;

    if ($title === '') $errors[] = 'Title is required.';
    if (!$courseId || !in_array($courseId, array_column($myCourses, 'id'), true)) $errors[] = 'Please select one of your assigned courses.';
    if (!$startAt || !$endAt) {
        $errors[] = 'Start and end date/time are required.';
    } elseif (strtotime($endAt) <= strtotime($startAt)) {
        $errors[] = 'End date/time must be after the start date/time.';
    }

    if (!$errors) {
        $startAtSql = date('Y-m-d H:i:s', strtotime($startAt));
        $endAtSql = date('Y-m-d H:i:s', strtotime($endAt));

        if ($test) {
            $pdo->prepare("UPDATE tests SET title=?, description=?, course_id=?, duration_minutes=?, passing_score=?,
                            start_at=?, end_at=?, shuffle_questions=?, show_result_immediately=? WHERE id=?")
                ->execute([$title, $description, $courseId, $duration, $passingScore, $startAtSql, $endAtSql, $shuffle, $showResult, $id]);
            audit_log($_SESSION['user_id'], 'test_updated', "Test #$id");
            flash('success', 'Test updated. Next, manage its questions.');
            redirect('/faculty/test-questions.php?id=' . $id);
        } else {
            $pdo->prepare("INSERT INTO tests (title, description, course_id, faculty_id, duration_minutes, passing_score,
                            start_at, end_at, status, shuffle_questions, show_result_immediately)
                            VALUES (?,?,?,?,?,?,?,?, 'draft', ?, ?)")
                ->execute([$title, $description, $courseId, $facultyId, $duration, $passingScore, $startAtSql, $endAtSql, $shuffle, $showResult]);
            $newId = (int) $pdo->lastInsertId();
            audit_log($_SESSION['user_id'], 'test_created', "Test #$newId");
            flash('success', 'Test created as a draft. Now add your questions.');
            redirect('/faculty/test-questions.php?id=' . $newId);
        }
    }
}

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title"><?= $test ? 'Edit Test' : 'Create New Test' ?></h3>

    <?php if ($errors): ?>
      <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>

    <div class="card p-4" style="max-width:760px;">
      <?php if (!$myCourses): ?>
        <div class="alert alert-info mb-0">You are not assigned to any course yet, so you cannot create a test. Contact the administrator.</div>
      <?php else: ?>
      <form method="post">
        <?= csrf_field() ?>
        <?php if ($id): ?><input type="hidden" name="id" value="<?= (int)$id ?>"><?php endif; ?>

        <div class="mb-3">
          <label class="form-label">Test Title *</label>
          <input type="text" name="title" class="form-control" value="<?= e($test['title'] ?? '') ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Description / Instructions</label>
          <textarea name="description" rows="3" class="form-control"><?= e($test['description'] ?? '') ?></textarea>
        </div>
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Course / Class *</label>
            <select name="course_id" class="form-select" required>
              <option value="">Select</option>
              <?php foreach ($myCourses as $c): ?>
                <option value="<?= (int)$c['id'] ?>" <?= ($test['course_id'] ?? 0) == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Duration (minutes) *</label>
            <input type="number" name="duration_minutes" class="form-control" min="1" max="600" value="<?= e($test['duration_minutes'] ?? 30) ?>" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">Passing Score (%) *</label>
            <input type="number" name="passing_score" class="form-control" min="0" max="100" step="0.5" value="<?= e($test['passing_score'] ?? 50) ?>" required>
          </div>
          <div class="col-md-6"></div>
          <div class="col-md-6">
            <label class="form-label">Start Date &amp; Time *</label>
            <input type="datetime-local" name="start_at" class="form-control" value="<?= $test ? date('Y-m-d\TH:i', strtotime($test['start_at'])) : '' ?>" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">End Date &amp; Time *</label>
            <input type="datetime-local" name="end_at" class="form-control" value="<?= $test ? date('Y-m-d\TH:i', strtotime($test['end_at'])) : '' ?>" required>
          </div>
        </div>
        <div class="form-check mt-3">
          <input type="checkbox" name="shuffle_questions" class="form-check-input" <?= !empty($test['shuffle_questions']) ? 'checked' : '' ?>>
          <label class="form-check-label">Shuffle question order per student</label>
        </div>
        <div class="form-check mb-3">
          <input type="checkbox" name="show_result_immediately" class="form-check-input" <?= ($test === null || !empty($test['show_result_immediately'])) ? 'checked' : '' ?>>
          <label class="form-check-label">Show result to student immediately after submission</label>
        </div>

        <button type="submit" class="btn btn-gold"><i class="fa-solid fa-floppy-disk me-2"></i><?= $test ? 'Save & Continue to Questions' : 'Create & Add Questions' ?></button>
        <a href="<?= BASE_URL ?>/faculty/tests.php" class="btn btn-outline-secondary">Cancel</a>
      </form>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
