<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
$pageTitle = 'My Profile';

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $phone = clean_str($_POST['phone'] ?? '');
    $department = clean_str($_POST['department'] ?? '');
    $title = clean_str($_POST['title'] ?? '');
    $bio = clean_str($_POST['bio'] ?? '');

    $photoName = null;
    if (!empty($_FILES['photo']['name'])) {
        $res = validate_and_move_upload($_FILES['photo'], UPLOAD_PASSPORTS_PATH, ALLOWED_PASSPORT_TYPES, MAX_PASSPORT_BYTES);
        if (!$res['success']) {
            $errors[] = $res['message'];
        } else {
            $photoName = $res['stored_name'];
        }
    }

    if (!$errors) {
        if ($photoName) {
            $pdo->prepare("UPDATE faculty SET phone=?, department=?, title=?, bio=?, photo=? WHERE id=?")
                ->execute([$phone, $department, $title, $bio, $photoName, $facultyId]);
        } else {
            $pdo->prepare("UPDATE faculty SET phone=?, department=?, title=?, bio=? WHERE id=?")
                ->execute([$phone, $department, $title, $bio, $facultyId]);
        }
        flash('success', 'Profile updated successfully.');
        redirect('/faculty/profile.php');
    }
}

$stmt = $pdo->prepare("SELECT * FROM faculty WHERE id = ?");
$stmt->execute([$facultyId]);
$faculty = $stmt->fetch();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">My Profile</h3>
    <?php if ($errors): ?>
      <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>
    <div class="row g-4">
      <div class="col-lg-4">
        <div class="card p-4 text-center">
          <?php if ($faculty['photo']): ?>
            <img src="<?= BASE_URL ?>/faculty/download.php?type=photo&file=<?= e($faculty['photo']) ?>" class="rounded-circle mx-auto mb-3" style="width:120px;height:120px;object-fit:cover;">
          <?php else: ?>
            <i class="fa-solid fa-circle-user fa-6x text-secondary mb-3"></i>
          <?php endif; ?>
          <h5 class="mb-0"><?= e($faculty['title'] . ' ' . $faculty['first_name'] . ' ' . $faculty['last_name']) ?></h5>
          <p class="text-muted small mb-0"><?= e($faculty['staff_id']) ?></p>
          <p class="text-muted small"><?= e($_SESSION['user_email']) ?></p>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">Update Details</h6>
          <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="row g-3">
              <div class="col-md-4">
                <label class="form-label">Title</label>
                <input type="text" name="title" class="form-control" value="<?= e($faculty['title']) ?>" placeholder="e.g. Rev., Pastor, Dr.">
              </div>
              <div class="col-md-4">
                <label class="form-label">Phone Number</label>
                <input type="text" name="phone" class="form-control" value="<?= e($faculty['phone']) ?>">
              </div>
              <div class="col-md-4">
                <label class="form-label">Department</label>
                <input type="text" name="department" class="form-control" value="<?= e($faculty['department']) ?>">
              </div>
              <div class="col-md-6">
                <label class="form-label">Profile Photo</label>
                <input type="file" name="photo" class="form-control" accept=".jpg,.jpeg,.png">
              </div>
              <div class="col-12">
                <label class="form-label">Short Biography</label>
                <textarea name="bio" class="form-control" rows="4" placeholder="A short bio shown on the public Leadership page..."><?= e($faculty['bio']) ?></textarea>
                <div class="form-text">This appears in the "Faculty Members" section on the public Leadership page. Leave blank to hide the bio.</div>
              </div>
            </div>
            <button type="submit" class="btn btn-gold mt-4"><i class="fa-solid fa-floppy-disk me-2"></i>Save Changes</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
