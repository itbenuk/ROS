<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
$pageTitle = 'Manage Tests';

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    // Always verify ownership before mutating.
    $own = $pdo->prepare("SELECT * FROM tests WHERE id = ? AND faculty_id = ?");
    $own->execute([$id, $facultyId]);
    $test = $own->fetch();

    if (!$test) {
        flash('error', 'Test not found or you do not own it.');
        redirect('/faculty/tests.php');
    }

    if ($action === 'publish') {
        $newStatus = strtotime($test['start_at']) > time() ? 'scheduled' : 'published';
        $qCount = $pdo->prepare("SELECT COUNT(*) c FROM test_questions WHERE test_id = ?");
        $qCount->execute([$id]);
        if ((int) $qCount->fetch()['c'] === 0) {
            flash('error', 'Add at least one question before publishing this test.');
            redirect('/faculty/test-questions.php?id=' . $id);
        }
        $pdo->prepare("UPDATE tests SET status = ? WHERE id = ?")->execute([$newStatus, $id]);
        audit_log($_SESSION['user_id'], 'test_published', "Test #$id");

        // Notify all assigned students who can actually access this test
        // (active/registered status, matching batch scope, course/assignment match).
        $students = $pdo->prepare("SELECT s.*, u.id AS user_id FROM students s JOIN users u ON u.id = s.user_id WHERE s.course_id = ?");
        $students->execute([$test['course_id']]);
        foreach ($students->fetchAll() as $st) {
            if (student_can_access_test($pdo, $test, $st)) {
                notify((int) $st['user_id'], 'test_published', 'New Test Available: ' . $test['title'],
                    'Opens ' . date('M j, Y g:ia', strtotime($test['start_at'])),
                    '/student/tests.php');
            }
        }
        flash('success', 'Test published' . ($newStatus === 'scheduled' ? ' and scheduled to open at its start time.' : '.'));
    } elseif ($action === 'unpublish') {
        $pdo->prepare("UPDATE tests SET status = 'draft' WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'test_unpublished', "Test #$id");
        flash('success', 'Test moved back to draft.');
    } elseif ($action === 'close') {
        $pdo->prepare("UPDATE tests SET status = 'closed' WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'test_closed', "Test #$id");
        flash('success', 'Test closed. Students can no longer attempt it.');
    } elseif ($action === 'duplicate') {
        $pdo->beginTransaction();
        $ins = $pdo->prepare("INSERT INTO tests (title, description, course_id, faculty_id, duration_minutes, passing_score, start_at, end_at, status, shuffle_questions, show_result_immediately)
                               VALUES (?,?,?,?,?,?,?,?,'draft',?,?)");
        $ins->execute([
            $test['title'] . ' (Copy)', $test['description'], $test['course_id'], $facultyId,
            $test['duration_minutes'], $test['passing_score'], $test['start_at'], $test['end_at'],
            $test['shuffle_questions'], $test['show_result_immediately'],
        ]);
        $newTestId = (int) $pdo->lastInsertId();

        $questions = $pdo->prepare("SELECT * FROM test_questions WHERE test_id = ? ORDER BY order_index");
        $questions->execute([$id]);
        foreach ($questions->fetchAll() as $q) {
            $qIns = $pdo->prepare("INSERT INTO test_questions (test_id, question_text, question_type, marks, order_index, correct_answer_text) VALUES (?,?,?,?,?,?)");
            $qIns->execute([$newTestId, $q['question_text'], $q['question_type'], $q['marks'], $q['order_index'], $q['correct_answer_text']]);
            $newQId = (int) $pdo->lastInsertId();

            $opts = $pdo->prepare("SELECT * FROM test_options WHERE question_id = ? ORDER BY order_index");
            $opts->execute([$q['id']]);
            foreach ($opts->fetchAll() as $o) {
                $pdo->prepare("INSERT INTO test_options (question_id, option_text, is_correct, order_index) VALUES (?,?,?,?)")
                    ->execute([$newQId, $o['option_text'], $o['is_correct'], $o['order_index']]);
            }
        }
        $pdo->commit();
        audit_log($_SESSION['user_id'], 'test_duplicated', "Test #$id => #$newTestId");
        flash('success', 'Test duplicated as a new draft.');
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM tests WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'test_deleted', "Test #$id");
        flash('success', 'Test deleted.');
    }
    redirect('/faculty/tests.php');
}

$courseId = (int) ($_GET['course_id'] ?? 0);
$where = ["t.faculty_id = ?"];
$params = [$facultyId];
if ($courseId) { $where[] = "t.course_id = ?"; $params[] = $courseId; }
$whereSql = implode(' AND ', $where);

$stmt = $pdo->prepare("SELECT t.*, c.name AS course_name,
                        (SELECT COUNT(*) FROM test_questions q WHERE q.test_id = t.id) AS question_count,
                        (SELECT COUNT(*) FROM test_attempts a WHERE a.test_id = t.id) AS attempt_count
                        FROM tests t LEFT JOIN courses c ON c.id = t.course_id
                        WHERE $whereSql ORDER BY t.created_at DESC");
$stmt->execute($params);
$tests = $stmt->fetchAll();

$myCourses = $pdo->prepare("SELECT c.id, c.name FROM faculty_courses fc JOIN courses c ON c.id = fc.course_id WHERE fc.faculty_id = ? ORDER BY c.name");
$myCourses->execute([$facultyId]);
$myCourses = $myCourses->fetchAll();

$statusBadge = fn($t) => match (test_effective_status($t)) {
    'draft'    => ['secondary', 'Draft'],
    'upcoming' => ['info', 'Scheduled'],
    'open'     => ['success', 'Open Now'],
    'closed'   => ['danger', 'Closed'],
};

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
      <h3 class="section-title mb-0">Manage Tests</h3>
      <a href="<?= BASE_URL ?>/faculty/test-form.php" class="btn btn-gold"><i class="fa-solid fa-plus me-2"></i>Create Test</a>
    </div>

    <div class="card p-3 mb-3">
      <form class="row g-2" method="get">
        <div class="col-md-8">
          <select name="course_id" class="form-select">
            <option value="">All My Courses</option>
            <?php foreach ($myCourses as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= $courseId==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-4"><button class="btn btn-outline-secondary w-100" type="submit">Filter</button></div>
      </form>
    </div>

    <?php if (!$tests): ?>
      <div class="empty-state"><i class="fa-solid fa-file-pen"></i><p>No tests created yet.</p></div>
    <?php else: ?>
    <div class="row g-3">
      <?php foreach ($tests as $t): [$badgeColor, $badgeLabel] = $statusBadge($t); ?>
        <div class="col-12">
          <div class="card p-3">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-2">
              <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                  <h6 class="mb-0"><?= e($t['title']) ?></h6>
                  <span class="badge text-bg-<?= $badgeColor ?>"><?= $badgeLabel ?></span>
                </div>
                <div class="small text-muted">
                  <?= e($t['course_name'] ?? 'General') ?> &middot; <?= (int)$t['question_count'] ?> questions &middot;
                  <?= format_duration((int)$t['duration_minutes']) ?> &middot; <?= (int)$t['attempt_count'] ?> attempt(s)
                </div>
                <div class="small text-muted">
                  <?= date('M j, Y g:ia', strtotime($t['start_at'])) ?> &rarr; <?= date('M j, Y g:ia', strtotime($t['end_at'])) ?>
                </div>
              </div>
              <div class="d-flex flex-wrap gap-1">
                <a href="<?= BASE_URL ?>/faculty/test-questions.php?id=<?= (int)$t['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Questions"><i class="fa-solid fa-list-ol"></i></a>
                <a href="<?= BASE_URL ?>/faculty/test-form.php?id=<?= (int)$t['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa-solid fa-pen"></i></a>
                <a href="<?= BASE_URL ?>/faculty/test-preview.php?id=<?= (int)$t['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Preview"><i class="fa-solid fa-eye"></i></a>
                <a href="<?= BASE_URL ?>/faculty/test-results.php?id=<?= (int)$t['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Results"><i class="fa-solid fa-chart-simple"></i></a>

                <?php if ($t['status'] === 'draft'): ?>
                  <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="publish"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                    <button class="btn btn-sm btn-gold" type="submit"><i class="fa-solid fa-paper-plane me-1"></i>Publish</button>
                  </form>
                <?php elseif (in_array($t['status'], ['published','scheduled'], true)): ?>
                  <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="unpublish"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                    <button class="btn btn-sm btn-outline-warning" type="submit" title="Unpublish"><i class="fa-solid fa-arrow-rotate-left"></i></button>
                  </form>
                  <form method="post" class="d-inline" data-confirm-delete="Close this test now? Students will no longer be able to attempt it.">
                    <?= csrf_field() ?><input type="hidden" name="action" value="close"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                    <button class="btn btn-sm btn-outline-danger" type="submit" title="Close Now"><i class="fa-solid fa-lock"></i></button>
                  </form>
                <?php endif; ?>

                <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="duplicate"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                  <button class="btn btn-sm btn-outline-secondary" type="submit" title="Duplicate"><i class="fa-solid fa-copy"></i></button>
                </form>
                <?php if ($t['status'] === 'draft'): ?>
                <form method="post" class="d-inline" data-confirm-delete="Permanently delete this test and all its questions?">
                  <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                  <button class="btn btn-sm btn-outline-danger" type="submit" title="Delete"><i class="fa-solid fa-trash"></i></button>
                </form>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
