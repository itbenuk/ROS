<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/xlsx_reader.php';
require_role('faculty');

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];
$testId = (int) ($_POST['test_id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM tests WHERE id = ? AND faculty_id = ?");
$stmt->execute([$testId, $facultyId]);
$test = $stmt->fetch();

if (!$test) {
    flash('error', 'Test not found or you do not own it.');
    redirect('/faculty/tests.php');
}
if ($test['status'] !== 'draft') {
    flash('error', 'Unpublish this test before importing more questions.');
    redirect('/faculty/test-questions.php?id=' . $testId);
}

$EXPECTED_HEADERS = ['question text', 'type', 'marks', 'option a', 'option b', 'option c', 'option d', 'correct answer'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf()) {
    redirect('/faculty/test-questions.php?id=' . $testId);
}

$file = $_FILES['import_file'] ?? null;

if (!$file || $file['error'] === UPLOAD_ERR_NO_FILE) {
    flash('error', 'Please choose a file to import.');
    redirect('/faculty/test-questions.php?id=' . $testId);
}
if ($file['error'] !== UPLOAD_ERR_OK) {
    flash('error', 'File upload failed. Please try again.');
    redirect('/faculty/test-questions.php?id=' . $testId);
}

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if ($ext === 'xls') {
    flash('error', 'Legacy .xls files are not supported. Please open the file in Excel and use "Save As" to convert it to .xlsx, then upload again.');
    redirect('/faculty/test-questions.php?id=' . $testId);
}
if ($ext !== 'xlsx') {
    flash('error', 'Please upload an .xlsx file.');
    redirect('/faculty/test-questions.php?id=' . $testId);
}
if ($file['size'] > 5 * 1024 * 1024) {
    flash('error', 'The file is too large (max 5MB).');
    redirect('/faculty/test-questions.php?id=' . $testId);
}
if (!is_uploaded_file($file['tmp_name'])) {
    flash('error', 'Invalid upload.');
    redirect('/faculty/test-questions.php?id=' . $testId);
}

try {
    $rows = read_xlsx_rows($file['tmp_name']);
} catch (Throwable $e) {
    flash('error', 'Could not read the file: ' . $e->getMessage());
    redirect('/faculty/test-questions.php?id=' . $testId);
}

// Drop fully blank trailing rows
while ($rows && implode('', $rows[count($rows) - 1]) === '') {
    array_pop($rows);
}

if (count($rows) < 2) {
    flash('error', 'The file has no data rows below the header.');
    redirect('/faculty/test-questions.php?id=' . $testId);
}

// Validate header row against the expected template (case-insensitive, order-independent).
$headerRow = array_map(fn($h) => strtolower(trim($h)), $rows[0]);
$colIndex = [];
foreach ($EXPECTED_HEADERS as $expected) {
    $pos = array_search($expected, $headerRow, true);
    if ($pos === false) {
        flash('error', 'The file does not match the expected template. Missing column: "' . ucwords($expected) . '". Please download the template and try again.');
        redirect('/faculty/test-questions.php?id=' . $testId);
    }
    $colIndex[$expected] = $pos;
}

$get = fn(array $row, string $key) => trim($row[$colIndex[$key]] ?? '');

$imported = 0;
$rowErrors = [];
$orderStmt = $pdo->prepare("SELECT COALESCE(MAX(order_index),-1)+1 n FROM test_questions WHERE test_id = ?");
$orderStmt->execute([$testId]);
$nextOrder = (int) $orderStmt->fetch()['n'];

$pdo->beginTransaction();
try {
    for ($r = 1; $r < count($rows); $r++) {
        $row = $rows[$r];
        $excelRowNum = $r + 1; // human-facing row number, including the header row

        $questionText = $get($row, 'question text');
        $type = strtolower($get($row, 'type'));
        $marksRaw = $get($row, 'marks');
        $optionA = $get($row, 'option a');
        $optionB = $get($row, 'option b');
        $optionC = $get($row, 'option c');
        $optionD = $get($row, 'option d');
        $correctRaw = $get($row, 'correct answer');

        if ($questionText === '' && $type === '' && $marksRaw === '' && $correctRaw === '') {
            continue; // fully blank row - skip silently, not an error
        }

        $rowIssues = [];
        if ($questionText === '') $rowIssues[] = 'question text is empty';

        $type = in_array($type, ['mcq', 'true_false', 'short_answer'], true) ? $type : null;
        if ($type === null) $rowIssues[] = 'type must be mcq, true_false, or short_answer';

        $marks = is_numeric($marksRaw) ? (float) $marksRaw : null;
        if ($marks === null || $marks <= 0) $rowIssues[] = 'marks must be a positive number';

        $options = array_values(array_filter([$optionA, $optionB, $optionC, $optionD], fn($v) => $v !== ''));

        if ($type === 'mcq') {
            if (count($options) < 2) {
                $rowIssues[] = 'mcq questions need at least 2 options (Option A-D)';
            }
            if ($correctRaw === '') {
                $rowIssues[] = 'correct answer is required';
            }
        } elseif ($type === 'true_false') {
            if (!in_array(strtolower($correctRaw), ['true', 'false'], true)) {
                $rowIssues[] = 'correct answer must be True or False';
            }
        } elseif ($type === 'short_answer') {
            if ($correctRaw === '') {
                $rowIssues[] = 'correct answer (expected text) is required';
            }
        }

        if ($rowIssues) {
            $rowErrors[] = "Row $excelRowNum: " . implode('; ', $rowIssues) . '.';
            continue;
        }

        // Resolve which option is correct for mcq (accept a letter A-D or exact option text)
        $correctIndex = null;
        if ($type === 'mcq') {
            $letterMap = ['A' => 0, 'B' => 1, 'C' => 2, 'D' => 3];
            $letter = strtoupper(trim($correctRaw));
            if (isset($letterMap[$letter]) && $letterMap[$letter] < count($options)) {
                $correctIndex = $letterMap[$letter];
            } else {
                foreach ($options as $i => $optText) {
                    if (mb_strtolower($optText) === mb_strtolower(trim($correctRaw))) {
                        $correctIndex = $i;
                        break;
                    }
                }
            }
            if ($correctIndex === null) {
                $rowErrors[] = "Row $excelRowNum: correct answer \"$correctRaw\" does not match any option (use A/B/C/D or the exact option text).";
                continue;
            }
        }

        // Insert the question
        $ins = $pdo->prepare("INSERT INTO test_questions (test_id, question_text, question_type, marks, order_index, correct_answer_text) VALUES (?,?,?,?,?,?)");
        $ins->execute([
            $testId, $questionText, $type, $marks, $nextOrder,
            $type === 'short_answer' ? $correctRaw : null,
        ]);
        $qId = (int) $pdo->lastInsertId();
        $nextOrder++;

        if ($type === 'mcq') {
            foreach ($options as $i => $optText) {
                $pdo->prepare("INSERT INTO test_options (question_id, option_text, is_correct, order_index) VALUES (?,?,?,?)")
                    ->execute([$qId, $optText, $i === $correctIndex ? 1 : 0, $i]);
            }
        } elseif ($type === 'true_false') {
            $correctBool = strtolower($correctRaw) === 'true';
            $pdo->prepare("INSERT INTO test_options (question_id, option_text, is_correct, order_index) VALUES (?,?,?,0)")
                ->execute([$qId, 'True', $correctBool ? 1 : 0]);
            $pdo->prepare("INSERT INTO test_options (question_id, option_text, is_correct, order_index) VALUES (?,?,?,1)")
                ->execute([$qId, 'False', $correctBool ? 0 : 1]);
        }

        $imported++;
    }

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('Question import failed: ' . $e->getMessage());
    flash('error', 'A system error occurred during import. No questions were added.');
    redirect('/faculty/test-questions.php?id=' . $testId);
}

audit_log($_SESSION['user_id'], 'test_questions_imported', "Test #$testId: $imported imported, " . count($rowErrors) . ' errors');

if ($imported > 0) {
    flash('success', "$imported question(s) imported successfully." . ($rowErrors ? ' Some rows had errors - see below.' : ''));
}
if ($rowErrors) {
    $_SESSION['import_errors'] = $rowErrors;
    if ($imported === 0) {
        flash('error', 'No questions were imported. Please fix the errors below and re-upload.');
    }
}

redirect('/faculty/test-questions.php?id=' . $testId);
