<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
$pageTitle = 'Preview Test';

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT t.*, c.name AS course_name FROM tests t LEFT JOIN courses c ON c.id = t.course_id WHERE t.id = ? AND t.faculty_id = ?");
$stmt->execute([$id, $facultyId]);
$test = $stmt->fetch();

if (!$test) {
    flash('error', 'Test not found or you do not own it.');
    redirect('/faculty/tests.php');
}

$questions = $pdo->prepare("SELECT * FROM test_questions WHERE test_id = ? ORDER BY order_index");
$questions->execute([$id]);
$questions = $questions->fetchAll();
$questions = load_options_for_questions($pdo, $questions);

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <a href="<?= BASE_URL ?>/faculty/tests.php" class="small mb-2 d-inline-block"><i class="fa-solid fa-arrow-left me-1"></i>Back to Tests</a>
    <div class="alert alert-info small"><i class="fa-solid fa-eye me-2"></i>Preview mode &mdash; correct answers are shown to you only; students never see this.</div>

    <div class="card p-4 mb-3">
      <h4 class="mb-1"><?= e($test['title']) ?></h4>
      <p class="text-muted small mb-2"><?= e($test['course_name'] ?? 'General') ?> &middot; <?= format_duration((int)$test['duration_minutes']) ?> &middot; <?= count($questions) ?> questions &middot; Pass mark <?= e($test['passing_score']) ?>%</p>
      <p class="mb-0"><?= nl2br(e($test['description'] ?: 'No instructions provided.')) ?></p>
    </div>

    <?php foreach ($questions as $i => $q): ?>
      <div class="card p-4 mb-3">
        <div class="d-flex justify-content-between mb-2">
          <span class="fw-semibold">Question <?= $i + 1 ?> of <?= count($questions) ?></span>
          <span class="badge text-bg-light"><?= e($q['marks']) ?> mark(s)</span>
        </div>
        <p><?= nl2br(e($q['question_text'])) ?></p>
        <?php if ($q['question_type'] === 'short_answer'): ?>
          <input type="text" class="form-control" placeholder="Student types their answer here" disabled>
          <p class="small text-success mt-2 mb-0"><i class="fa-solid fa-circle-check me-1"></i>Correct answer: <?= e($q['correct_answer_text']) ?></p>
        <?php else: ?>
          <?php foreach ($q['options'] as $o): ?>
            <div class="form-check mb-1">
              <input class="form-check-input" type="radio" disabled <?= $o['is_correct'] ? 'checked' : '' ?>>
              <label class="form-check-label <?= $o['is_correct'] ? 'text-success fw-semibold' : '' ?>">
                <?= e($o['option_text']) ?> <?php if ($o['is_correct']): ?><i class="fa-solid fa-circle-check ms-1"></i><?php endif; ?>
              </label>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    <?php if (!$questions): ?>
      <div class="empty-state"><i class="fa-solid fa-list-ol"></i><p>No questions added yet.</p></div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
