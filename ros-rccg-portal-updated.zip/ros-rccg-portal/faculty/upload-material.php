<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
$pageTitle = 'Upload Material';

$pdo = getDB();
$courses = $pdo->query("SELECT id, name FROM courses WHERE is_active = 1 ORDER BY name")->fetchAll();
$categories = $pdo->query("SELECT id, name FROM categories ORDER BY name")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Upload Learning Material</h3>
    <div class="card p-4" style="max-width:720px;">
      <form id="uploadForm" data-ajax-upload action="<?= BASE_URL ?>/ajax/upload_material.php" method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label">Title *</label>
          <input type="text" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Description</label>
          <textarea name="description" rows="4" class="form-control"></textarea>
        </div>
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Course</label>
            <select name="course_id" class="form-select">
              <option value="">General</option>
              <?php foreach ($courses as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Category</label>
            <select name="category_id" class="form-select">
              <option value="">Uncategorized</option>
              <?php foreach ($categories as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="mb-3 mt-3">
          <label class="form-label">Visibility</label>
          <select name="status" class="form-select">
            <option value="published">Published (visible to students)</option>
            <option value="draft">Draft (hidden from students)</option>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">File * <span class="text-muted small">(PDF, DOCX, PPTX, ZIP, video, audio, image &mdash; max 25MB)</span></label>
          <input type="file" name="material_file" class="form-control" required>
        </div>

        <div class="upload-progress d-none mb-3">
          <div class="progress" style="height:22px;">
            <div class="progress-bar bg-success" role="progressbar" style="width:0%">0%</div>
          </div>
        </div>

        <button type="submit" class="btn btn-gold"><i class="fa-solid fa-cloud-arrow-up me-2"></i>Upload Material</button>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
