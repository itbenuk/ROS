<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');

if (in_array($_GET['type'] ?? '', ['photo', 'passport'], true)) {
    $file = basename($_GET['file'] ?? '');
    $path = UPLOAD_PASSPORTS_PATH . $file;
    if (!$file || !is_file($path)) {
        http_response_code(404);
        exit('Not found.');
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    header('Content-Type: ' . finfo_file($finfo, $path));
    finfo_close($finfo);
    header('Content-Disposition: inline; filename="' . $file . '"');
    readfile($path);
    exit;
}

http_response_code(400);
exit('Invalid request.');
