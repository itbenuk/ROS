<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
$pageTitle = 'My Courses';

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];

$stmt = $pdo->prepare("SELECT c.*,
        (SELECT COUNT(*) FROM students s WHERE s.course_id = c.id) AS student_count,
        (SELECT COUNT(*) FROM tests t WHERE t.course_id = c.id AND t.faculty_id = ?) AS test_count
        FROM faculty_courses fc
        JOIN courses c ON c.id = fc.course_id
        WHERE fc.faculty_id = ?
        ORDER BY c.name");
$stmt->execute([$facultyId, $facultyId]);
$courses = $stmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">My Courses / Classes</h3>

    <?php if (!$courses): ?>
      <div class="empty-state"><i class="fa-solid fa-book"></i><p>You have not been assigned to any course yet. Contact the administrator.</p></div>
    <?php else: ?>
    <div class="row g-4">
      <?php foreach ($courses as $c): ?>
        <div class="col-md-6 col-lg-4">
          <div class="card p-4 h-100">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <h5 class="mb-0"><?= e($c['name']) ?></h5>
              <span class="badge badge-<?= $c['is_active'] ? 'active' : 'inactive' ?> px-2 py-1"><?= $c['is_active'] ? 'Active' : 'Inactive' ?></span>
            </div>
            <p class="text-muted small mb-3"><?= e($c['code']) ?></p>
            <p class="small mb-3"><?= e($c['description'] ?: 'No description provided.') ?></p>
            <div class="d-flex justify-content-between border-top pt-3 mt-auto">
              <a href="<?= BASE_URL ?>/faculty/students.php?course_id=<?= (int)$c['id'] ?>" class="small"><i class="fa-solid fa-user-graduate me-1"></i><?= (int)$c['student_count'] ?> Students</a>
              <a href="<?= BASE_URL ?>/faculty/tests.php?course_id=<?= (int)$c['id'] ?>" class="small"><i class="fa-solid fa-file-pen me-1"></i><?= (int)$c['test_count'] ?> Tests</a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
