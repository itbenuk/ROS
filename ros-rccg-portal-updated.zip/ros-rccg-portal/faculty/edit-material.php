<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
$pageTitle = 'Edit Material';

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];
$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM materials WHERE id = ? AND faculty_id = ?");
$stmt->execute([$id, $facultyId]);
$material = $stmt->fetch();

if (!$material) {
    flash('error', 'Material not found or you do not have permission to edit it.');
    redirect('/faculty/materials.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $title = clean_str($_POST['title'] ?? '');
    $description = clean_str($_POST['description'] ?? '');
    $courseId = $_POST['course_id'] ? (int) $_POST['course_id'] : null;
    $categoryId = $_POST['category_id'] ? (int) $_POST['category_id'] : null;
    $status = in_array($_POST['status'] ?? '', ['published', 'draft', 'archived'], true) ? $_POST['status'] : 'published';

    if ($title === '') $errors[] = 'Title is required.';

    // Optional file replacement
    $newFile = null;
    if (!empty($_FILES['material_file']['name'])) {
        $newFile = validate_and_move_upload($_FILES['material_file'], UPLOAD_MATERIALS_PATH, ALLOWED_MATERIAL_TYPES, MAX_UPLOAD_BYTES);
        if (!$newFile['success']) {
            $errors[] = $newFile['message'];
            $newFile = null;
        }
    }

    if (!$errors) {
        if ($newFile) {
            // remove old file
            $oldPath = UPLOAD_MATERIALS_PATH . $material['stored_name'];
            if (is_file($oldPath)) unlink($oldPath);

            $stmt = $pdo->prepare("UPDATE materials SET title=?, description=?, course_id=?, category_id=?, status=?,
                                    file_name=?, stored_name=?, file_type=?, file_size=? WHERE id=?");
            $stmt->execute([
                $title, $description, $courseId, $categoryId, $status,
                $newFile['original_name'], $newFile['stored_name'], $newFile['file_type'], $newFile['file_size'],
                $id,
            ]);
        } else {
            $stmt = $pdo->prepare("UPDATE materials SET title=?, description=?, course_id=?, category_id=?, status=? WHERE id=?");
            $stmt->execute([$title, $description, $courseId, $categoryId, $status, $id]);
        }
        audit_log($_SESSION['user_id'], 'material_updated', "Material ID: $id");
        flash('success', 'Material updated successfully.');
        redirect('/faculty/materials.php');
    }
}

$courses = $pdo->query("SELECT id, name FROM courses WHERE is_active = 1 ORDER BY name")->fetchAll();
$categories = $pdo->query("SELECT id, name FROM categories ORDER BY name")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Edit Material</h3>
    <?php if ($errors): ?>
      <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>
    <div class="card p-4" style="max-width:720px;">
      <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= (int)$material['id'] ?>">
        <div class="mb-3">
          <label class="form-label">Title *</label>
          <input type="text" name="title" class="form-control" value="<?= e($material['title']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Description</label>
          <textarea name="description" rows="4" class="form-control"><?= e($material['description']) ?></textarea>
        </div>
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Course</label>
            <select name="course_id" class="form-select">
              <option value="">General</option>
              <?php foreach ($courses as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $material['course_id'] == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Category</label>
            <select name="category_id" class="form-select">
              <option value="">Uncategorized</option>
              <?php foreach ($categories as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $material['category_id'] == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="mb-3 mt-3">
          <label class="form-label">Visibility</label>
          <select name="status" class="form-select">
            <option value="published" <?= $material['status']==='published'?'selected':'' ?>>Published</option>
            <option value="draft" <?= $material['status']==='draft'?'selected':'' ?>>Draft</option>
            <option value="archived" <?= $material['status']==='archived'?'selected':'' ?>>Archived</option>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">Replace File <span class="text-muted small">(optional &mdash; current: <?= e($material['file_name']) ?>)</span></label>
          <input type="file" name="material_file" class="form-control">
        </div>
        <button type="submit" class="btn btn-gold"><i class="fa-solid fa-floppy-disk me-2"></i>Save Changes</button>
        <a href="<?= BASE_URL ?>/faculty/materials.php" class="btn btn-outline-secondary">Cancel</a>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
