<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
$pageTitle = 'Faculty Dashboard';

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];

$stmt = $pdo->prepare("SELECT * FROM faculty WHERE id = ?");
$stmt->execute([$facultyId]);
$faculty = $stmt->fetch();

$totalMaterials = $pdo->prepare("SELECT COUNT(*) c FROM materials WHERE faculty_id = ?");
$totalMaterials->execute([$facultyId]);
$totalMaterials = $totalMaterials->fetch()['c'];

$totalDownloads = $pdo->prepare("SELECT COALESCE(SUM(download_count),0) c FROM materials WHERE faculty_id = ?");
$totalDownloads->execute([$facultyId]);
$totalDownloads = $totalDownloads->fetch()['c'];

$recentUploads = $pdo->prepare("SELECT * FROM materials WHERE faculty_id = ? ORDER BY created_at DESC LIMIT 5");
$recentUploads->execute([$facultyId]);
$recentUploads = $recentUploads->fetchAll();

$totalStudents = $pdo->query("SELECT COUNT(*) c FROM students")->fetch()['c'];

$totalTests = $pdo->prepare("SELECT COUNT(*) c FROM tests WHERE faculty_id = ?");
$totalTests->execute([$facultyId]);
$totalTests = $totalTests->fetch()['c'];

$pendingResults = $pdo->prepare("SELECT COUNT(*) c FROM test_attempts ta JOIN tests t ON t.id = ta.test_id
                                  WHERE t.faculty_id = ? AND ta.status IN ('submitted','auto_submitted','violation_submitted')");
$pendingResults->execute([$facultyId]);
$pendingResults = $pendingResults->fetch()['c'];

$recentTests = $pdo->prepare("SELECT t.*, c.name AS course_name,
                               (SELECT COUNT(*) FROM test_attempts a WHERE a.test_id = t.id) AS attempt_count
                               FROM tests t LEFT JOIN courses c ON c.id = t.course_id
                               WHERE t.faculty_id = ? ORDER BY t.created_at DESC LIMIT 5");
$recentTests->execute([$facultyId]);
$recentTests = $recentTests->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="mb-1">Welcome, <?= e($faculty['title'] . ' ' . $faculty['first_name'] . ' ' . $faculty['last_name']) ?></h3>
    <p class="text-muted mb-4"><?= e($faculty['department'] ?? '') ?></p>

    <div class="row g-3 mb-4">
      <div class="col-6 col-lg-3">
        <div class="stat-card">
          <div class="stat-icon mb-2" style="background:#6b1530;"><i class="fa-solid fa-folder-open"></i></div>
          <div class="stat-value"><?= (int)$totalMaterials ?></div>
          <div class="stat-label">My Materials</div>
        </div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card">
          <div class="stat-icon mb-2" style="background:#c9a24b;"><i class="fa-solid fa-download"></i></div>
          <div class="stat-value"><?= (int)$totalDownloads ?></div>
          <div class="stat-label">Total Downloads</div>
        </div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card">
          <div class="stat-icon mb-2" style="background:#1e7e34;"><i class="fa-solid fa-user-graduate"></i></div>
          <div class="stat-value"><?= (int)$totalStudents ?></div>
          <div class="stat-label">Registered Students</div>
        </div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card">
          <div class="stat-icon mb-2" style="background:#4a0e21;"><i class="fa-solid fa-file-pen"></i></div>
          <div class="stat-value"><?= (int)$totalTests ?></div>
          <div class="stat-label">Tests Created</div>
        </div>
      </div>
      <div class="col-6 col-lg-3">
        <a href="<?= BASE_URL ?>/faculty/upload-material.php" class="text-decoration-none">
        <div class="stat-card h-100 d-flex flex-column align-items-center justify-content-center text-center" style="background:var(--deep-green);color:#fff;">
          <i class="fa-solid fa-cloud-arrow-up fa-2x mb-2 text-gold"></i>
          <div class="fw-semibold">Upload Material</div>
        </div>
        </a>
      </div>
    </div>

    <div class="row g-4 mb-4">
      <div class="col-lg-6">
        <div class="card p-4 h-100">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="mb-0 fw-bold">Recent Tests</h6>
            <a href="<?= BASE_URL ?>/faculty/tests.php" class="small">Manage all</a>
          </div>
          <?php if (!$recentTests): ?>
            <div class="empty-state py-3"><i class="fa-solid fa-file-pen"></i><p>No tests created yet.</p><a href="<?= BASE_URL ?>/faculty/test-form.php" class="btn btn-gold btn-sm">Create Your First Test</a></div>
          <?php else: foreach ($recentTests as $t): [$badgeColor, $badgeLabel] = [
              match(test_effective_status($t)) { 'draft'=>'secondary','upcoming'=>'info','open'=>'success','closed'=>'danger' },
              match(test_effective_status($t)) { 'draft'=>'Draft','upcoming'=>'Scheduled','open'=>'Open','closed'=>'Closed' },
            ]; ?>
            <div class="d-flex justify-content-between border-bottom pb-2 mb-2 small">
              <div><strong><?= e($t['title']) ?></strong><br><span class="text-muted"><?= e($t['course_name'] ?? '-') ?> &middot; <?= (int)$t['attempt_count'] ?> attempt(s)</span></div>
              <span class="badge text-bg-<?= $badgeColor ?> align-self-start"><?= $badgeLabel ?></span>
            </div>
          <?php endforeach; endif; ?>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="card p-4 h-100 text-center d-flex flex-column justify-content-center">
          <i class="fa-solid fa-square-poll-vertical fa-2x text-gold mb-2"></i>
          <div class="stat-value"><?= (int)$pendingResults ?></div>
          <div class="stat-label mb-3">Submissions Awaiting Your Review</div>
          <a href="<?= BASE_URL ?>/faculty/tests.php" class="btn btn-outline-secondary btn-sm mx-auto">View Results</a>
        </div>
      </div>
    </div>

    <div class="card p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="mb-0 fw-bold">Recent Uploads</h6>
        <a href="<?= BASE_URL ?>/faculty/materials.php" class="small">Manage all materials</a>
      </div>
      <?php if (!$recentUploads): ?>
        <div class="empty-state"><i class="fa-solid fa-folder-open"></i><p>You haven't uploaded any materials yet.</p></div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table align-middle">
            <thead><tr><th>Title</th><th>Type</th><th>Status</th><th>Downloads</th><th>Uploaded</th></tr></thead>
            <tbody>
            <?php foreach ($recentUploads as $m): ?>
              <tr>
                <td class="fw-semibold"><?= e($m['title']) ?></td>
                <td><span class="badge text-bg-light text-uppercase"><?= e($m['file_type']) ?></span></td>
                <td><span class="badge badge-status-<?= e($m['status']) ?> px-2 py-1"><?= e(ucfirst($m['status'])) ?></span></td>
                <td><?= (int)$m['download_count'] ?></td>
                <td class="text-muted small"><?= time_ago($m['created_at']) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
