<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];
$testId = (int) ($_GET['id'] ?? $_POST['test_id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM tests WHERE id = ? AND faculty_id = ?");
$stmt->execute([$testId, $facultyId]);
$test = $stmt->fetch();

if (!$test) {
    flash('error', 'Test not found or you do not own it.');
    redirect('/faculty/tests.php');
}
$pageTitle = 'Questions — ' . $test['title'];
$errors = [];
$locked = $test['status'] !== 'draft';

function save_question_options(PDO $pdo, int $questionId, string $type, array $optionTexts, $correctIndex, ?string $correctText): void
{
    $pdo->prepare("DELETE FROM test_options WHERE question_id = ?")->execute([$questionId]);

    if ($type === 'mcq') {
        foreach ($optionTexts as $i => $text) {
            $text = trim($text);
            if ($text === '') continue;
            $pdo->prepare("INSERT INTO test_options (question_id, option_text, is_correct, order_index) VALUES (?,?,?,?)")
                ->execute([$questionId, $text, ((string)$i === (string)$correctIndex) ? 1 : 0, $i]);
        }
    } elseif ($type === 'true_false') {
        $pdo->prepare("INSERT INTO test_options (question_id, option_text, is_correct, order_index) VALUES (?,?,?,0)")
            ->execute([$questionId, 'True', $correctIndex === 'true' ? 1 : 0]);
        $pdo->prepare("INSERT INTO test_options (question_id, option_text, is_correct, order_index) VALUES (?,?,?,1)")
            ->execute([$questionId, 'False', $correctIndex === 'false' ? 1 : 0]);
    }
    // short_answer: correct_answer_text is stored directly on test_questions, no options needed.
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    if ($locked) {
        flash('error', 'Unpublish this test before editing its questions.');
        redirect('/faculty/test-questions.php?id=' . $testId);
    }
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $questionText = clean_str($_POST['question_text'] ?? '');
        $type = in_array($_POST['question_type'] ?? '', ['mcq','true_false','short_answer'], true) ? $_POST['question_type'] : 'mcq';
        $marks = max(0.5, (float) ($_POST['marks'] ?? 1));
        $optionTexts = array_filter(array_map('trim', $_POST['option_text'] ?? []), fn($v) => $v !== '');
        $correctIndex = $_POST['correct_option'] ?? null;
        $correctText = clean_str($_POST['correct_answer_text'] ?? '');

        if ($questionText === '') $errors[] = 'Question text is required.';
        if ($type === 'mcq' && count($optionTexts) < 2) $errors[] = 'Provide at least 2 answer options for a multiple-choice question.';
        if ($type === 'mcq' && $correctIndex === null) $errors[] = 'Select which option is correct.';
        if ($type === 'true_false' && !in_array($correctIndex, ['true','false'], true)) $errors[] = 'Select whether True or False is correct.';
        if ($type === 'short_answer' && $correctText === '') $errors[] = 'Provide the expected correct answer.';

        if (!$errors) {
            if ($action === 'add') {
                $orderStmt = $pdo->prepare("SELECT COALESCE(MAX(order_index),-1)+1 n FROM test_questions WHERE test_id = ?");
                $orderStmt->execute([$testId]);
                $order = (int) $orderStmt->fetch()['n'];

                $ins = $pdo->prepare("INSERT INTO test_questions (test_id, question_text, question_type, marks, order_index, correct_answer_text) VALUES (?,?,?,?,?,?)");
                $ins->execute([$testId, $questionText, $type, $marks, $order, $type === 'short_answer' ? $correctText : null]);
                $qId = (int) $pdo->lastInsertId();
                save_question_options($pdo, $qId, $type, $optionTexts, $correctIndex, $correctText);
                flash('success', 'Question added.');
            } else {
                $qId = (int) $_POST['question_id'];
                $chk = $pdo->prepare("SELECT id FROM test_questions WHERE id = ? AND test_id = ?");
                $chk->execute([$qId, $testId]);
                if ($chk->fetch()) {
                    $pdo->prepare("UPDATE test_questions SET question_text=?, question_type=?, marks=?, correct_answer_text=? WHERE id=?")
                        ->execute([$questionText, $type, $marks, $type === 'short_answer' ? $correctText : null, $qId]);
                    save_question_options($pdo, $qId, $type, $optionTexts, $correctIndex, $correctText);
                    flash('success', 'Question updated.');
                }
            }
            redirect('/faculty/test-questions.php?id=' . $testId);
        }
    } elseif ($action === 'delete') {
        $qId = (int) $_POST['question_id'];
        $pdo->prepare("DELETE FROM test_questions WHERE id = ? AND test_id = ?")->execute([$qId, $testId]);
        flash('success', 'Question deleted.');
        redirect('/faculty/test-questions.php?id=' . $testId);
    }
}

$questions = $pdo->prepare("SELECT * FROM test_questions WHERE test_id = ? ORDER BY order_index");
$questions->execute([$testId]);
$questions = $questions->fetchAll();
$questions = load_options_for_questions($pdo, $questions);

$totalMarks = array_sum(array_column($questions, 'marks'));
$importErrors = get_import_errors();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <a href="<?= BASE_URL ?>/faculty/tests.php" class="small mb-2 d-inline-block"><i class="fa-solid fa-arrow-left me-1"></i>Back to Tests</a>
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
      <div>
        <h3 class="section-title mb-0"><?= e($test['title']) ?></h3>
        <p class="text-muted small mb-0"><?= count($questions) ?> question(s) &middot; <?= $totalMarks ?> total marks</p>
      </div>
      <?php if (!$locked): ?>
        <div class="d-flex gap-2">
          <button class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#importModal"><i class="fa-solid fa-file-import me-2"></i>Import Session</button>
          <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#questionModal" onclick="resetQuestionForm()"><i class="fa-solid fa-plus me-2"></i>Add Question</button>
        </div>
      <?php else: ?>
        <span class="badge text-bg-warning">This test is live &mdash; unpublish to edit questions</span>
      <?php endif; ?>
    </div>

    <?php if ($importErrors): ?>
      <div class="alert alert-warning">
        <strong><i class="fa-solid fa-triangle-exclamation me-1"></i>Some rows in your import file had errors and were skipped:</strong>
        <ul class="mb-0 mt-2 small">
          <?php foreach ($importErrors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php if ($errors): ?>
      <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>

    <?php if (!$questions): ?>
      <div class="empty-state"><i class="fa-solid fa-list-ol"></i><p>No questions yet. Add your first question above.</p></div>
    <?php else: foreach ($questions as $i => $q): ?>
      <div class="card p-3 mb-3">
        <div class="d-flex justify-content-between align-items-start gap-2">
          <div class="flex-grow-1">
            <div class="d-flex align-items-center gap-2 mb-1">
              <span class="badge text-bg-light">Q<?= $i + 1 ?></span>
              <span class="badge text-bg-light text-capitalize"><?= str_replace('_',' ',$q['question_type']) ?></span>
              <span class="badge text-bg-light"><?= e($q['marks']) ?> mark(s)</span>
            </div>
            <p class="mb-2"><?= nl2br(e($q['question_text'])) ?></p>
            <?php if ($q['question_type'] === 'short_answer'): ?>
              <p class="small text-muted mb-0">Correct answer: <strong><?= e($q['correct_answer_text']) ?></strong></p>
            <?php else: ?>
              <ul class="list-unstyled mb-0 small">
                <?php foreach ($q['options'] as $o): ?>
                  <li><?= $o['is_correct'] ? '<i class="fa-solid fa-circle-check text-success me-1"></i>' : '<i class="fa-regular fa-circle text-muted me-1"></i>' ?><?= e($o['option_text']) ?></li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
          </div>
          <?php if (!$locked): ?>
          <div class="d-flex gap-1">
            <button class="btn btn-sm btn-outline-secondary" onclick='editQuestion(<?= json_encode($q, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'><i class="fa-solid fa-pen"></i></button>
            <form method="post" data-confirm-delete="Delete this question?">
              <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="question_id" value="<?= (int)$q['id'] ?>">
              <button class="btn btn-sm btn-outline-danger" type="submit"><i class="fa-solid fa-trash"></i></button>
            </form>
          </div>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; endif; ?>

    <?php if ($questions && !$locked): ?>
      <a href="<?= BASE_URL ?>/faculty/tests.php" class="btn btn-gold mt-2"><i class="fa-solid fa-check me-2"></i>Done — Back to Tests to Publish</a>
    <?php endif; ?>
  </div>
</div>

<!-- Import Session Modal -->
<div class="modal fade" id="importModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post" action="<?= BASE_URL ?>/faculty/import-questions.php" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="test_id" value="<?= (int)$testId ?>">
        <div class="modal-header">
          <h5 class="modal-title">Import Session from Excel</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <p class="small text-muted">Upload an <strong>.xlsx</strong> file of questions to add them to this test in bulk. Questions are validated row by row — valid rows are imported and any problem rows are reported so you can fix and re-upload just those.</p>
          <a href="<?= BASE_URL ?>/assets/templates/question_import_template.xlsx" class="small d-inline-block mb-3"><i class="fa-solid fa-download me-1"></i>Download the import template</a>
          <div class="mb-3">
            <label class="form-label">Excel File (.xlsx) *</label>
            <input type="file" name="import_file" class="form-control" accept=".xlsx" required>
          </div>
          <div class="alert alert-secondary small mb-0">
            Expected columns: <strong>Question Text, Type, Marks, Option A, Option B, Option C, Option D, Correct Answer</strong>.
            Type must be <code>mcq</code>, <code>true_false</code>, or <code>short_answer</code>.
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-gold"><i class="fa-solid fa-file-import me-2"></i>Import Questions</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Question Modal -->
<div class="modal fade" id="questionModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form method="post" id="questionForm">
        <?= csrf_field() ?>
        <input type="hidden" name="test_id" value="<?= (int)$testId ?>">
        <input type="hidden" name="action" id="formAction" value="add">
        <input type="hidden" name="question_id" id="formQuestionId" value="">
        <div class="modal-header">
          <h5 class="modal-title" id="questionModalTitle">Add Question</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Question Text *</label>
            <textarea name="question_text" id="qText" class="form-control" rows="2" required></textarea>
          </div>
          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label">Question Type *</label>
              <select name="question_type" id="qType" class="form-select" onchange="toggleQuestionType()">
                <option value="mcq">Multiple Choice</option>
                <option value="true_false">True / False</option>
                <option value="short_answer">Short Answer</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Marks *</label>
              <input type="number" name="marks" id="qMarks" class="form-control" min="0.5" step="0.5" value="1" required>
            </div>
          </div>

          <div id="mcqSection">
            <label class="form-label">Answer Options (select the correct one) *</label>
            <div id="optionRows"></div>
            <button type="button" class="btn btn-sm btn-outline-secondary mt-1" onclick="addOptionRow()"><i class="fa-solid fa-plus me-1"></i>Add Option</button>
          </div>

          <div id="tfSection" class="d-none">
            <label class="form-label">Correct Answer *</label>
            <div class="form-check"><input class="form-check-input" type="radio" name="correct_option" value="true" id="tfTrue"><label class="form-check-label" for="tfTrue">True</label></div>
            <div class="form-check"><input class="form-check-input" type="radio" name="correct_option" value="false" id="tfFalse"><label class="form-check-label" for="tfFalse">False</label></div>
          </div>

          <div id="shortSection" class="d-none">
            <label class="form-label">Correct Answer (exact match, case-insensitive) *</label>
            <input type="text" name="correct_answer_text" id="qCorrectText" class="form-control">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-gold">Save Question</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
let optionCounter = 0;

function addOptionRow(text = '', checked = false) {
  const idx = optionCounter++;
  const wrap = document.getElementById('optionRows');
  const row = document.createElement('div');
  row.className = 'input-group mb-2';
  row.innerHTML = `
    <div class="input-group-text"><input type="radio" name="correct_option" value="${idx}" ${checked ? 'checked' : ''} aria-label="Correct answer"></div>
    <input type="text" name="option_text[]" class="form-control" placeholder="Option text" value="${text.replace(/"/g,'&quot;')}">
    <button type="button" class="btn btn-outline-danger" onclick="this.closest('.input-group').remove()"><i class="fa-solid fa-xmark"></i></button>
  `;
  wrap.appendChild(row);
}

function toggleQuestionType() {
  const type = document.getElementById('qType').value;
  document.getElementById('mcqSection').classList.toggle('d-none', type !== 'mcq');
  document.getElementById('tfSection').classList.toggle('d-none', type !== 'true_false');
  document.getElementById('shortSection').classList.toggle('d-none', type !== 'short_answer');
}

function resetQuestionForm() {
  document.getElementById('questionModalTitle').textContent = 'Add Question';
  document.getElementById('formAction').value = 'add';
  document.getElementById('formQuestionId').value = '';
  document.getElementById('qText').value = '';
  document.getElementById('qType').value = 'mcq';
  document.getElementById('qMarks').value = 1;
  document.getElementById('qCorrectText').value = '';
  document.getElementById('optionRows').innerHTML = '';
  optionCounter = 0;
  addOptionRow(); addOptionRow();
  toggleQuestionType();
}

function editQuestion(q) {
  document.getElementById('questionModalTitle').textContent = 'Edit Question';
  document.getElementById('formAction').value = 'edit';
  document.getElementById('formQuestionId').value = q.id;
  document.getElementById('qText').value = q.question_text;
  document.getElementById('qType').value = q.question_type;
  document.getElementById('qMarks').value = q.marks;
  document.getElementById('qCorrectText').value = q.question_type === 'short_answer' ? q.correct_answer_text : '';
  document.getElementById('optionRows').innerHTML = '';
  optionCounter = 0;

  if (q.question_type === 'mcq') {
    (q.options || []).forEach(o => addOptionRow(o.option_text, !!parseInt(o.is_correct)));
  } else if (q.question_type === 'true_false') {
    const trueOpt = (q.options || []).find(o => o.option_text === 'True');
    const falseOpt = (q.options || []).find(o => o.option_text === 'False');
    document.getElementById('tfTrue').checked = trueOpt && parseInt(trueOpt.is_correct) === 1;
    document.getElementById('tfFalse').checked = falseOpt && parseInt(falseOpt.is_correct) === 1;
  }
  toggleQuestionType();
  new bootstrap.Modal(document.getElementById('questionModal')).show();
}

document.addEventListener('DOMContentLoaded', resetQuestionForm);

// Keep each MCQ option's radio "value" aligned with its DOM position so that,
// even after rows are added/removed, the posted correct_option index always
// matches the corresponding option_text[] array position server-side.
document.getElementById('questionForm').addEventListener('submit', function () {
  document.querySelectorAll('#optionRows .input-group').forEach((row, idx) => {
    const radio = row.querySelector('input[type=radio]');
    if (radio) radio.value = idx;
  });
});
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
