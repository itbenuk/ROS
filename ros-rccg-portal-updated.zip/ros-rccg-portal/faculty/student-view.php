<?php
require_once __DIR__ . '/../config/config.php';
require_role('faculty');
$pageTitle = 'Student Profile';

$pdo = getDB();
$facultyId = $_SESSION['ref_id'];

$permStmt = $pdo->prepare("SELECT can_view_students FROM faculty WHERE id = ?");
$permStmt->execute([$facultyId]);
if (!(bool) $permStmt->fetch()['can_view_students']) {
    flash('error', 'You do not have permission to view student profiles.');
    redirect('/faculty/students.php');
}

$id = (int) ($_GET['id'] ?? 0);

// Only allow viewing a student who is enrolled in a course this faculty teaches.
$stmt = $pdo->prepare("SELECT s.*, u.email, u.status AS account_status, c.name AS course_name, se.name AS session_name
                        FROM students s
                        JOIN users u ON u.id = s.user_id
                        JOIN faculty_courses fc ON fc.course_id = s.course_id AND fc.faculty_id = ?
                        LEFT JOIN courses c ON c.id = s.course_id
                        LEFT JOIN sessions se ON se.id = s.session_id
                        WHERE s.id = ?");
$stmt->execute([$facultyId, $id]);
$student = $stmt->fetch();

if (!$student) {
    flash('error', 'Student not found or not in your assigned courses.');
    redirect('/faculty/students.php');
}

// This faculty's tests taken by this student
$attempts = $pdo->prepare("SELECT ta.*, t.title, t.passing_score
                            FROM test_attempts ta
                            JOIN tests t ON t.id = ta.test_id
                            WHERE ta.student_id = ? AND t.faculty_id = ?
                            ORDER BY ta.created_at DESC");
$attempts->execute([$id, $facultyId]);
$attempts = $attempts->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
  <div class="dash-content">
    <a href="<?= BASE_URL ?>/faculty/students.php" class="small mb-3 d-inline-block"><i class="fa-solid fa-arrow-left me-1"></i>Back to Students</a>

    <div class="row g-4">
      <div class="col-lg-4">
        <div class="card p-4 text-center">
          <?php if ($student['passport_photo']): ?>
            <img src="<?= BASE_URL ?>/faculty/download.php?type=passport&file=<?= e($student['passport_photo']) ?>" class="rounded-circle mx-auto mb-3" style="width:110px;height:110px;object-fit:cover;">
          <?php else: ?>
            <i class="fa-solid fa-circle-user fa-6x text-secondary mb-3"></i>
          <?php endif; ?>
          <h5 class="mb-0"><?= e($student['first_name'].' '.$student['last_name']) ?></h5>
          <p class="text-muted small mb-2"><?= e($student['reg_number']) ?></p>
          <span class="badge badge-<?= match($student['status']) { 'active'=>'active','graduated'=>'graduated','withdrawn'=>'suspended', default=>'inactive' } ?> px-3 py-2 rounded-pill"><?= e(ucfirst($student['status'])) ?></span>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="card p-4 mb-4">
          <h6 class="fw-bold mb-3">Registration Information</h6>
          <div class="row small">
            <div class="col-md-6 mb-2"><strong>Email:</strong> <?= e($student['email']) ?></div>
            <div class="col-md-6 mb-2"><strong>Phone:</strong> <?= e($student['phone']) ?></div>
            <div class="col-md-6 mb-2"><strong>Gender:</strong> <?= e($student['gender']) ?></div>
            <div class="col-md-6 mb-2"><strong>Programme:</strong> <?= e($student['course_name'] ?? '-') ?></div>
            <div class="col-md-6 mb-2"><strong>Session:</strong> <?= e($student['session_name'] ?? '-') ?></div>
            <div class="col-md-6 mb-2"><strong>Church/Parish:</strong> <?= e($student['church_parish'] ?: '-') ?></div>
          </div>
        </div>

        <div class="card p-4">
          <h6 class="fw-bold mb-3">Test Participation (My Courses)</h6>
          <?php if (!$attempts): ?>
            <div class="empty-state py-3"><i class="fa-solid fa-file-pen"></i><p>This student has not attempted any of your tests yet.</p></div>
          <?php else: ?>
          <div class="table-responsive">
            <table class="table table-sm align-middle">
              <thead><tr><th>Test</th><th>Status</th><th>Score</th><th>Result</th><th></th></tr></thead>
              <tbody>
              <?php foreach ($attempts as $a): ?>
                <tr>
                  <td><?= e($a['title']) ?></td>
                  <td>
                    <span class="badge <?= $a['status']==='violation_submitted' ? 'text-bg-danger' : 'text-bg-light' ?> text-capitalize"
                          <?= $a['termination_reason'] ? 'title="' . e($a['termination_reason']) . '"' : '' ?>>
                      <?= $a['status']==='violation_submitted' ? '<i class="fa-solid fa-triangle-exclamation me-1"></i>Violation' : e(str_replace('_',' ',$a['status'])) ?>
                    </span>
                  </td>
                  <td><?= $a['score'] !== null ? e($a['score']).' / '.e($a['total_marks']).' ('.e($a['percentage']).'%)' : '-' ?></td>
                  <td>
                    <?php if ($a['passed'] !== null): ?>
                      <span class="badge badge-<?= $a['passed'] ? 'active' : 'suspended' ?> px-2 py-1"><?= $a['passed'] ? 'Passed' : 'Failed' ?></span>
                    <?php else: ?>-<?php endif; ?>
                  </td>
                  <td class="text-end">
                    <?php if (in_array($a['status'], ['submitted','auto_submitted','violation_submitted'], true)): ?>
                      <a href="<?= BASE_URL ?>/faculty/test-attempt-view.php?id=<?= (int)$a['id'] ?>" class="small">View Answers</a>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
