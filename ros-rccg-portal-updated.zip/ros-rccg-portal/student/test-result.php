<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
$pageTitle = 'Test Result';

$pdo = getDB();
$studentId = $_SESSION['ref_id'];
$attemptId = (int) ($_GET['attempt_id'] ?? 0);

// Strict ownership check: a student may only ever view their own attempt.
$stmt = $pdo->prepare("SELECT ta.*, t.title, t.description, t.show_result_immediately, t.status AS test_status, c.name AS course_name
                        FROM test_attempts ta
                        JOIN tests t ON t.id = ta.test_id
                        LEFT JOIN courses c ON c.id = t.course_id
                        WHERE ta.id = ? AND ta.student_id = ?");
$stmt->execute([$attemptId, $studentId]);
$attempt = $stmt->fetch();

if (!$attempt) {
    flash('error', 'Result not found.');
    redirect('/student/tests.php');
}

if ($attempt['status'] === 'in_progress') {
    redirect('/student/test-attempt.php?id=' . $attempt['test_id']);
}

$canReview = (bool) $attempt['show_result_immediately'] || $attempt['test_status'] === 'closed';

$questions = [];
if ($canReview) {
    $qStmt = $pdo->prepare("SELECT q.*, a.selected_option_id, a.answer_text, a.is_correct, a.marks_awarded
                             FROM test_questions q
                             LEFT JOIN test_answers a ON a.question_id = q.id AND a.attempt_id = ?
                             WHERE q.test_id = ? ORDER BY q.order_index");
    $qStmt->execute([$attemptId, $attempt['test_id']]);
    $questions = $qStmt->fetchAll();
    $questions = load_options_for_questions($pdo, $questions);
    foreach ($questions as &$q) {
        if ($q['question_type'] === 'short_answer') {
            $q['options'] = [];
        }
    }
    unset($q);
}

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/student-sidebar.php'; ?>
  <div class="dash-content">
    <a href="<?= BASE_URL ?>/student/tests.php?tab=completed" class="small mb-2 d-inline-block"><i class="fa-solid fa-arrow-left me-1"></i>Back to My Tests</a>

    <?php if ($attempt['status'] === 'violation_submitted'): ?>
      <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i><?= e($attempt['termination_reason']) ?></div>
    <?php endif; ?>

    <div class="card p-4 mb-4 text-center">
      <h4 class="mb-1"><?= e($attempt['title']) ?></h4>
      <p class="text-muted mb-3"><?= e($attempt['course_name'] ?? 'General') ?></p>

      <?php if ($attempt['percentage'] !== null): ?>
        <div class="display-4 fw-bold mb-1" style="color: var(--deep-green);"><?= e($attempt['percentage']) ?>%</div>
        <p class="mb-2"><?= e($attempt['score']) ?> out of <?= e($attempt['total_marks']) ?> marks</p>
        <span class="badge badge-<?= $attempt['passed'] ? 'active' : 'suspended' ?> px-4 py-2 fs-6 rounded-pill">
          <?= $attempt['passed'] ? 'Passed' : 'Failed' ?>
        </span>
      <?php else: ?>
        <div class="alert alert-info mb-0">Your submission is recorded. Results will be available soon.</div>
      <?php endif; ?>

      <div class="row small text-muted mt-4">
        <div class="col-md-4">Status: <?= e(ucfirst(str_replace('_',' ', $attempt['status']))) ?></div>
        <div class="col-md-4">Submitted: <?= $attempt['submitted_at'] ? date('M j, Y g:ia', strtotime($attempt['submitted_at'])) : '-' ?></div>
        <div class="col-md-4">Time Taken: <?= $attempt['time_taken_seconds'] ? gmdate('H:i:s', (int)$attempt['time_taken_seconds']) : '-' ?></div>
      </div>
    </div>

    <?php if (!$canReview): ?>
      <div class="alert alert-secondary small"><i class="fa-solid fa-lock me-2"></i>Detailed answer review is not available for this test.</div>
    <?php else: ?>
      <h6 class="fw-bold mb-3">Answer Review</h6>
      <?php foreach ($questions as $i => $q): ?>
        <div class="card p-4 mb-3">
          <div class="d-flex justify-content-between mb-2">
            <span class="fw-semibold">Question <?= $i + 1 ?></span>
            <span class="badge <?= $q['is_correct'] ? 'text-bg-success' : 'text-bg-danger' ?>"><?= $q['marks_awarded'] ?? 0 ?> / <?= $q['marks'] ?> marks</span>
          </div>
          <p><?= nl2br(e($q['question_text'])) ?></p>
          <?php if ($q['question_type'] === 'short_answer'): ?>
            <p class="mb-1"><strong>Your answer:</strong> <?= e($q['answer_text'] ?: '(no answer)') ?></p>
            <p class="small text-muted mb-0"><strong>Correct answer:</strong> <?= e($q['correct_answer_text']) ?></p>
          <?php else: ?>
            <?php foreach ($q['options'] as $o):
              $isSelected = (int)$q['selected_option_id'] === (int)$o['id'];
              $class = $o['is_correct'] ? 'text-success fw-semibold' : ($isSelected ? 'text-danger fw-semibold' : '');
            ?>
              <div class="form-check mb-1">
                <input class="form-check-input" type="radio" disabled <?= $isSelected ? 'checked' : '' ?>>
                <label class="form-check-label <?= $class ?>">
                  <?= e($o['option_text']) ?>
                  <?php if ($o['is_correct']): ?><i class="fa-solid fa-circle-check ms-1 text-success"></i><?php elseif ($isSelected): ?><i class="fa-solid fa-circle-xmark ms-1 text-danger"></i><?php endif; ?>
                </label>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
