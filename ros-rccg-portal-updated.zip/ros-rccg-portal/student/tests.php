<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
$pageTitle = 'My Tests';

$pdo = getDB();
$studentId = $_SESSION['ref_id'];

$studentStmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$studentStmt->execute([$studentId]);
$student = $studentStmt->fetch();
$courseId = $student['course_id'];
$batchId = $student['batch_id'];
$hasActiveAccess = student_has_active_access($student);

$available = $upcoming = [];

// Currently-assigned tests (available/upcoming) are only ever computed for
// students with active access. Graduated/withdrawn students never see new
// or upcoming tests, regardless of course/batch - their access to *new*
// training activity ends at graduation even if a test happens to match
// their old course.
if ($hasActiveAccess) {
    $stmt = $pdo->prepare("SELECT t.*, c.name AS course_name, f.first_name, f.last_name,
            (SELECT COUNT(*) FROM test_questions q WHERE q.test_id = t.id) AS question_count,
            ta.id AS attempt_id, ta.status AS attempt_status, ta.percentage, ta.passed, ta.submitted_at
            FROM tests t
            LEFT JOIN courses c ON c.id = t.course_id
            JOIN faculty f ON f.id = t.faculty_id
            LEFT JOIN test_attempts ta ON ta.test_id = t.id AND ta.student_id = ?
            WHERE t.status != 'draft'
            AND (t.batch_id IS NULL OR t.batch_id = ?)
            AND (
                EXISTS (SELECT 1 FROM test_assignments a1 WHERE a1.test_id = t.id AND a1.student_id = ?)
                OR (t.course_id = ? AND NOT EXISTS (SELECT 1 FROM test_assignments a2 WHERE a2.test_id = t.id))
            )
            ORDER BY t.start_at DESC");
    $stmt->execute([$studentId, $batchId, $studentId, $courseId]);

    foreach ($stmt->fetchAll() as $t) {
        $hasCompletedAttempt = in_array($t['attempt_status'], ['submitted', 'auto_submitted', 'violation_submitted', 'expired'], true);
        if ($hasCompletedAttempt) {
            continue; // already counted in the historical query below
        } elseif (test_is_open($t)) {
            $available[] = $t;
        } elseif (test_effective_status($t) === 'upcoming') {
            $upcoming[] = $t;
        }
        // A currently-assigned test whose window has closed with no attempt
        // is intentionally omitted here; it has no result to show and isn't
        // "available" - nothing meaningful to display for it.
    }
}

// Historical results: always visible regardless of current status/batch/
// course changes, exactly as required ("historical records ... must remain
// available"). This is driven purely by the student's own past attempts.
$histStmt = $pdo->prepare("SELECT t.*, c.name AS course_name, f.first_name, f.last_name,
        (SELECT COUNT(*) FROM test_questions q WHERE q.test_id = t.id) AS question_count,
        ta.id AS attempt_id, ta.status AS attempt_status, ta.percentage, ta.passed, ta.submitted_at
        FROM test_attempts ta
        JOIN tests t ON t.id = ta.test_id
        LEFT JOIN courses c ON c.id = t.course_id
        JOIN faculty f ON f.id = t.faculty_id
        WHERE ta.student_id = ? AND ta.status IN ('submitted','auto_submitted','violation_submitted','expired')
        ORDER BY ta.submitted_at DESC");
$histStmt->execute([$studentId]);
$completed = $histStmt->fetchAll();

$tab = in_array($_GET['tab'] ?? '', ['available','upcoming','completed'], true) ? $_GET['tab'] : 'available';
if (!$hasActiveAccess) {
    $tab = 'completed'; // graduated/withdrawn students land straight on their history
}

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/student-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">My Tests</h3>

    <?php if (!$hasActiveAccess): ?>
      <div class="alert alert-secondary small">
        <i class="fa-solid fa-graduation-cap me-2"></i>Your account (<?= e(ucfirst($student['status'])) ?>) no longer has access to new or upcoming tests. Your completed test history remains available below.
      </div>
    <?php endif; ?>

    <ul class="nav nav-pills mb-4">
      <?php if ($hasActiveAccess): ?>
      <li class="nav-item"><a class="nav-link <?= $tab==='available'?'active':'' ?>" href="?tab=available">Available <span class="badge text-bg-light ms-1"><?= count($available) ?></span></a></li>
      <li class="nav-item"><a class="nav-link <?= $tab==='upcoming'?'active':'' ?>" href="?tab=upcoming">Upcoming <span class="badge text-bg-light ms-1"><?= count($upcoming) ?></span></a></li>
      <?php endif; ?>
      <li class="nav-item"><a class="nav-link <?= $tab==='completed'?'active':'' ?>" href="?tab=completed">Completed <span class="badge text-bg-light ms-1"><?= count($completed) ?></span></a></li>
    </ul>

    <?php
    $list = $tab === 'available' ? $available : ($tab === 'upcoming' ? $upcoming : $completed);
    ?>

    <?php if (!$list): ?>
      <div class="empty-state">
        <i class="fa-solid fa-file-pen"></i>
        <p>
          <?= $tab === 'available' ? 'No tests are currently open for you.' : ($tab === 'upcoming' ? 'No upcoming tests scheduled.' : 'You have not completed any tests yet.') ?>
        </p>
      </div>
    <?php else: ?>
    <div class="row g-3">
      <?php foreach ($list as $t): ?>
        <div class="col-md-6">
          <div class="card p-4 h-100 d-flex flex-column">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <h6 class="mb-0"><?= e($t['title']) ?></h6>
              <?php if ($tab === 'completed'): ?>
                <?php if ($t['attempt_status']): ?>
                  <span class="badge badge-<?= $t['passed'] ? 'active' : 'suspended' ?> px-2 py-1"><?= $t['passed'] ? 'Passed' : 'Failed' ?></span>
                <?php else: ?>
                  <span class="badge text-bg-secondary">Missed</span>
                <?php endif; ?>
              <?php elseif ($tab === 'available' && $t['attempt_status'] === 'in_progress'): ?>
                <span class="badge text-bg-warning">In Progress</span>
              <?php endif; ?>
            </div>
            <p class="small text-muted mb-2"><?= e($t['course_name'] ?? 'General') ?> &middot; By <?= e($t['first_name'].' '.$t['last_name']) ?></p>
            <p class="small mb-3"><?= e(mb_strimwidth($t['description'] ?: 'No instructions provided.', 0, 120, '...')) ?></p>
            <ul class="list-unstyled small text-muted mb-3">
              <li><i class="fa-solid fa-clock me-1"></i>Duration: <?= format_duration((int)$t['duration_minutes']) ?></li>
              <li><i class="fa-solid fa-list-ol me-1"></i><?= (int)$t['question_count'] ?> question(s)</li>
              <li><i class="fa-solid fa-calendar me-1"></i>
                <?= date('M j, g:ia', strtotime($t['start_at'])) ?> &rarr; <?= date('M j, g:ia', strtotime($t['end_at'])) ?>
              </li>
            </ul>
            <div class="mt-auto">
              <?php if ($tab === 'available'): ?>
                <a href="<?= BASE_URL ?>/student/test-attempt.php?id=<?= (int)$t['id'] ?>" class="btn btn-gold w-100">
                  <?= $t['attempt_status'] === 'in_progress' ? 'Resume Test' : 'Start Test' ?>
                </a>
              <?php elseif ($tab === 'completed' && $t['attempt_id']): ?>
                <a href="<?= BASE_URL ?>/student/test-result.php?attempt_id=<?= (int)$t['attempt_id'] ?>" class="btn btn-outline-secondary w-100">View Result</a>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
