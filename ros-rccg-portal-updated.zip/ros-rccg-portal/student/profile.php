<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
$pageTitle = 'My Profile';

$pdo = getDB();
$studentId = $_SESSION['ref_id'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();

    $phone = clean_str($_POST['phone'] ?? '');
    $whatsapp = clean_str($_POST['whatsapp'] ?? '');
    $address = clean_str($_POST['address'] ?? '');
    $state = clean_str($_POST['state'] ?? '');
    $country = clean_str($_POST['country'] ?? '');
    $church = clean_str($_POST['church_parish'] ?? '');

    if ($phone === '') $errors[] = 'Phone number is required.';
    if ($address === '') $errors[] = 'Address is required.';

    $passportName = null;
    if (!empty($_FILES['passport_photo']['name'])) {
        $res = validate_and_move_upload($_FILES['passport_photo'], UPLOAD_PASSPORTS_PATH, ALLOWED_PASSPORT_TYPES, MAX_PASSPORT_BYTES);
        if (!$res['success']) {
            $errors[] = $res['message'];
        } else {
            $passportName = $res['stored_name'];
        }
    }

    if (!$errors) {
        if ($passportName) {
            $stmt = $pdo->prepare("UPDATE students SET phone=?, whatsapp=?, address=?, state=?, country=?, church_parish=?, passport_photo=? WHERE id=?");
            $stmt->execute([$phone, $whatsapp, $address, $state, $country, $church, $passportName, $studentId]);
        } else {
            $stmt = $pdo->prepare("UPDATE students SET phone=?, whatsapp=?, address=?, state=?, country=?, church_parish=? WHERE id=?");
            $stmt->execute([$phone, $whatsapp, $address, $state, $country, $church, $studentId]);
        }
        audit_log($_SESSION['user_id'], 'student_profile_updated');
        flash('success', 'Your profile has been updated.');
        redirect('/student/profile.php');
    }
}

$stmt = $pdo->prepare("SELECT s.*, c.name AS course_name, se.name AS session_name
                        FROM students s
                        LEFT JOIN courses c ON c.id = s.course_id
                        LEFT JOIN sessions se ON se.id = s.session_id
                        WHERE s.id = ?");
$stmt->execute([$studentId]);
$student = $stmt->fetch();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/student-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">My Profile</h3>

    <?php if ($errors): ?>
      <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>

    <div class="row g-4">
      <div class="col-lg-4">
        <div class="card p-4 text-center">
          <?php if ($student['passport_photo']): ?>
            <img src="<?= BASE_URL ?>/student/download.php?type=passport&file=<?= e($student['passport_photo']) ?>" class="rounded-circle mx-auto mb-3" style="width:120px;height:120px;object-fit:cover;" alt="Passport">
          <?php else: ?>
            <i class="fa-solid fa-circle-user fa-6x text-secondary mb-3"></i>
          <?php endif; ?>
          <h5 class="mb-0"><?= e($student['first_name'] . ' ' . $student['last_name']) ?></h5>
          <p class="text-muted small mb-2"><?= e($student['reg_number']) ?></p>
          <span class="badge badge-active px-3 py-2 rounded-pill">Active Student</span>
          <hr>
          <div class="text-start small">
            <p class="mb-1"><strong>Programme:</strong> <?= e($student['course_name'] ?? '-') ?></p>
            <p class="mb-1"><strong>Session:</strong> <?= e($student['session_name'] ?? '-') ?></p>
            <p class="mb-1"><strong>Email:</strong> <?= e($_SESSION['user_email']) ?></p>
            <p class="mb-0"><strong>Gender:</strong> <?= e($student['gender']) ?></p>
          </div>
        </div>
      </div>

      <div class="col-lg-8">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">Update Contact Information</h6>
          <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label">Phone Number</label>
                <input type="text" name="phone" class="form-control" value="<?= e($student['phone']) ?>" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">WhatsApp Number</label>
                <input type="text" name="whatsapp" class="form-control" value="<?= e($student['whatsapp']) ?>">
              </div>
              <div class="col-12">
                <label class="form-label">Address</label>
                <input type="text" name="address" class="form-control" value="<?= e($student['address']) ?>" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">State</label>
                <input type="text" name="state" class="form-control" value="<?= e($student['state']) ?>">
              </div>
              <div class="col-md-6">
                <label class="form-label">Country</label>
                <input type="text" name="country" class="form-control" value="<?= e($student['country']) ?>">
              </div>
              <div class="col-md-6">
                <label class="form-label">Church / Parish</label>
                <input type="text" name="church_parish" class="form-control" value="<?= e($student['church_parish']) ?>">
              </div>
              <div class="col-md-6">
                <label class="form-label">Update Passport Photo</label>
                <input type="file" name="passport_photo" class="form-control" accept=".jpg,.jpeg,.png">
              </div>
            </div>
            <button type="submit" class="btn btn-gold mt-4"><i class="fa-solid fa-floppy-disk me-2"></i>Save Changes</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
