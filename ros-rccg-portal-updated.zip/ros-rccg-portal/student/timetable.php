<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
$pageTitle = 'My Timetable';

$pdo = getDB();
$studentId = $_SESSION['ref_id'];

$studentStmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$studentStmt->execute([$studentId]);
$student = $studentStmt->fetch();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/student-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">My Timetable</h3>

    <?php if (!student_has_active_access($student)): ?>
      <div class="alert alert-secondary small"><i class="fa-solid fa-graduation-cap me-2"></i>The current training timetable is only available to actively enrolled students.</div>
    <?php else:
      // Only entries matching the student's own course (or open to all
      // programmes) AND their own batch (or open to all batches) are shown -
      // never another cohort's schedule.
      $stmt = $pdo->prepare("SELECT t.*, f.first_name, f.last_name, c.name AS course_name
                              FROM timetable_entries t
                              JOIN faculty f ON f.id = t.faculty_id
                              LEFT JOIN courses c ON c.id = t.course_id
                              WHERE (t.course_id IS NULL OR t.course_id = ?)
                              AND (t.batch_id IS NULL OR t.batch_id = ?)
                              AND t.entry_date >= CURDATE() - INTERVAL 7 DAY
                              ORDER BY t.entry_date ASC, t.start_time ASC");
      $stmt->execute([$student['course_id'], $student['batch_id']]);
      $entries = $stmt->fetchAll();
    ?>
      <?php if (!$entries): ?>
        <div class="empty-state"><i class="fa-solid fa-calendar-days"></i><p>No upcoming lectures scheduled.</p></div>
      <?php else: ?>
      <div class="card p-4">
        <div class="table-responsive">
          <table class="table align-middle">
            <thead><tr><th>Date</th><th>Time</th><th>Topic</th><th>Lecturer</th></tr></thead>
            <tbody>
            <?php foreach ($entries as $t): $isToday = $t['entry_date'] === date('Y-m-d'); ?>
              <tr class="<?= $isToday ? 'table-warning' : '' ?>">
                <td><?= date('D, M j, Y', strtotime($t['entry_date'])) ?> <?= $isToday ? '<span class="badge text-bg-warning ms-1">Today</span>' : '' ?></td>
                <td><?= date('g:ia', strtotime($t['start_time'])) ?> &ndash; <?= date('g:ia', strtotime($t['end_time'])) ?></td>
                <td><?= e($t['topic']) ?></td>
                <td><?= e($t['first_name'].' '.$t['last_name']) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
