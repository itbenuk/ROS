<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
$pageTitle = 'Learning Materials';

$pdo = getDB();
$studentId = $_SESSION['ref_id'];

$studentStmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$studentStmt->execute([$studentId]);
$student = $studentStmt->fetch();

if (!student_has_active_access($student)) {
    flash('info', 'Current training materials are only available to actively enrolled students. Your historical records remain accessible to administrators on request.');
    redirect('/student/dashboard.php');
}

$search = clean_str($_GET['q'] ?? '');
$courseId = (int) ($_GET['course_id'] ?? 0);
$categoryId = (int) ($_GET['category_id'] ?? 0);
$fileType = clean_str($_GET['file_type'] ?? '');
$sort = in_array($_GET['sort'] ?? '', ['newest', 'oldest', 'title'], true) ? $_GET['sort'] : 'newest';
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 9;

// Batch scoping: a material with no batch set is visible to the whole
// course; a material tied to a specific batch is visible only to students
// in that same batch, so newer/older cohorts never cross-see each other's
// resources by accident.
$where = ["m.status = 'published'", "(m.batch_id IS NULL OR m.batch_id = ?)"];
$params = [$student['batch_id']];

if ($search !== '') {
    $where[] = "(m.title LIKE ? OR m.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($courseId) { $where[] = "m.course_id = ?"; $params[] = $courseId; }
if ($categoryId) { $where[] = "m.category_id = ?"; $params[] = $categoryId; }
if ($fileType !== '') { $where[] = "m.file_type = ?"; $params[] = $fileType; }

$whereSql = implode(' AND ', $where);

$countStmt = $pdo->prepare("SELECT COUNT(*) c FROM materials m WHERE $whereSql");
$countStmt->execute($params);
$total = (int) $countStmt->fetch()['c'];
$p = paginate($total, $perPage, $page);

$orderSql = match ($sort) {
    'oldest' => 'm.created_at ASC',
    'title'  => 'm.title ASC',
    default  => 'm.created_at DESC',
};

$sql = "SELECT m.*, c.name AS course_name, cat.name AS category_name, f.first_name, f.last_name
        FROM materials m
        LEFT JOIN courses c ON c.id = m.course_id
        LEFT JOIN categories cat ON cat.id = m.category_id
        LEFT JOIN faculty f ON f.id = m.faculty_id
        WHERE $whereSql
        ORDER BY $orderSql
        LIMIT {$p['perPage']} OFFSET {$p['offset']}";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$materials = $stmt->fetchAll();

$courses = $pdo->query("SELECT id, name FROM courses ORDER BY name")->fetchAll();
$categories = $pdo->query("SELECT id, name FROM categories ORDER BY name")->fetchAll();

$fileIcon = fn($t) => match ($t) {
    'pdf' => 'fa-file-pdf text-danger',
    'doc','docx' => 'fa-file-word text-primary',
    'ppt','pptx' => 'fa-file-powerpoint text-warning',
    'zip' => 'fa-file-zipper text-secondary',
    'mp4','mov' => 'fa-file-video text-info',
    'mp3','wav' => 'fa-file-audio text-success',
    'jpg','jpeg','png' => 'fa-file-image text-purple',
    default => 'fa-file',
};

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/student-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Learning Materials</h3>

    <div class="card p-3 mb-4">
      <form method="get" class="row g-2 align-items-end">
        <div class="col-md-4">
          <label class="form-label mb-1">Search</label>
          <input type="text" name="q" class="form-control" placeholder="Title or keyword..." value="<?= e($search) ?>">
        </div>
        <div class="col-md-2">
          <label class="form-label mb-1">Course</label>
          <select name="course_id" class="form-select">
            <option value="">All</option>
            <?php foreach ($courses as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= $courseId == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-2">
          <label class="form-label mb-1">Category</label>
          <select name="category_id" class="form-select">
            <option value="">All</option>
            <?php foreach ($categories as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= $categoryId == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-2">
          <label class="form-label mb-1">Sort By</label>
          <select name="sort" class="form-select">
            <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Newest</option>
            <option value="oldest" <?= $sort === 'oldest' ? 'selected' : '' ?>>Oldest</option>
            <option value="title" <?= $sort === 'title' ? 'selected' : '' ?>>Title A-Z</option>
          </select>
        </div>
        <div class="col-md-2">
          <button class="btn btn-gold w-100" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button>
        </div>
      </form>
    </div>

    <?php if (!$materials): ?>
      <div class="empty-state"><i class="fa-solid fa-book-open"></i><p>No materials match your search.</p></div>
    <?php else: ?>
    <div class="row g-3">
      <?php foreach ($materials as $m): ?>
        <div class="col-md-6 col-lg-4">
          <div class="card p-3 h-100">
            <div class="d-flex align-items-start gap-3">
              <i class="fa-solid <?= $fileIcon($m['file_type']) ?> material-icon"></i>
              <div class="flex-grow-1">
                <a href="<?= BASE_URL ?>/student/material-view.php?id=<?= (int)$m['id'] ?>" class="fw-semibold text-decoration-none d-block"><?= e($m['title']) ?></a>
                <div class="small text-muted mb-1"><?= e($m['course_name'] ?? 'General') ?> &middot; <?= e($m['category_name'] ?? 'Uncategorized') ?></div>
                <div class="small text-muted">By <?= e(trim(($m['first_name'] ?? '') . ' ' . ($m['last_name'] ?? '')) ?: 'Faculty') ?></div>
                <div class="d-flex justify-content-between align-items-center mt-2">
                  <span class="badge text-bg-light text-uppercase"><?= e($m['file_type']) ?></span>
                  <span class="small text-muted"><i class="fa-solid fa-download me-1"></i><?= (int)$m['download_count'] ?></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <?php if ($p['totalPages'] > 1): ?>
      <nav class="mt-4">
        <ul class="pagination justify-content-center">
          <?php for ($i = 1; $i <= $p['totalPages']; $i++): $qs = $_GET; $qs['page'] = $i; ?>
            <li class="page-item <?= $i === $p['currentPage'] ? 'active' : '' ?>">
              <a class="page-link" href="?<?= http_build_query($qs) ?>"><?= $i ?></a>
            </li>
          <?php endfor; ?>
        </ul>
      </nav>
    <?php endif; ?>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
