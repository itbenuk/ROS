<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
$pageTitle = 'Change Password';

$errors = [];
$pdo = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $current = $_POST['current_password'] ?? '';
    $newPass = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $hash = $stmt->fetch()['password_hash'];

    if (!password_verify($current, $hash)) {
        $errors[] = 'Current password is incorrect.';
    }
    if (!is_strong_password($newPass)) {
        $errors[] = 'New password must be at least 8 characters and include letters and numbers.';
    }
    if ($newPass !== $confirm) {
        $errors[] = 'New passwords do not match.';
    }

    if (!$errors) {
        $newHash = password_hash($newPass, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([$newHash, $_SESSION['user_id']]);
        audit_log($_SESSION['user_id'], 'password_changed');
        flash('success', 'Your password has been changed successfully.');
        redirect('/student/change-password.php');
    }
}

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/student-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Change Password</h3>
    <div class="card p-4" style="max-width:520px;">
      <?php if ($errors): ?>
        <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div>
      <?php endif; ?>
      <form method="post">
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label">Current Password</label>
          <input type="password" name="current_password" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">New Password</label>
          <input type="password" name="new_password" class="form-control" minlength="8" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Confirm New Password</label>
          <input type="password" name="confirm_password" class="form-control" minlength="8" required>
        </div>
        <button type="submit" class="btn btn-gold"><i class="fa-solid fa-key me-2"></i>Update Password</button>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
