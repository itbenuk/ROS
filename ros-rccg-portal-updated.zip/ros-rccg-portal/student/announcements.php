<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
$pageTitle = 'Announcements';

$pdo = getDB();
$userId = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT a.*, u.email AS poster_email,
                        (SELECT COUNT(*) FROM announcement_reads r WHERE r.announcement_id = a.id AND r.user_id = ?) AS is_read
                        FROM announcements a
                        JOIN users u ON u.id = a.posted_by_user_id
                        WHERE a.is_published = 1 AND a.audience IN ('all','students')
                        ORDER BY a.created_at DESC");
$stmt->execute([$userId]);
$announcements = $stmt->fetchAll();

// Mark viewed announcement as read
if (isset($_GET['read'])) {
    $aid = (int) $_GET['read'];
    $pdo->prepare("INSERT IGNORE INTO announcement_reads (announcement_id, user_id) VALUES (?,?)")->execute([$aid, $userId]);
    redirect('/student/announcements.php');
}

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/student-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Announcements</h3>
    <?php if (!$announcements): ?>
      <div class="empty-state"><i class="fa-solid fa-bullhorn"></i><p>No announcements at this time.</p></div>
    <?php else: foreach ($announcements as $a): ?>
      <div class="card p-4 mb-3 <?= !$a['is_read'] ? 'border-start border-4 border-warning' : '' ?>">
        <div class="d-flex justify-content-between flex-wrap gap-2">
          <h5 class="mb-1"><?= e($a['title']) ?> <?php if (!$a['is_read']): ?><span class="badge text-bg-warning ms-1">New</span><?php endif; ?></h5>
          <span class="text-muted small"><?= date('M j, Y g:ia', strtotime($a['created_at'])) ?></span>
        </div>
        <p class="mb-2 text-muted small">Posted by <?= e($a['poster_email']) ?></p>
        <p class="mb-2"><?= nl2br(e($a['body'])) ?></p>
        <?php if (!$a['is_read']): ?>
          <a href="?read=<?= (int)$a['id'] ?>" class="small">Mark as read</a>
        <?php endif; ?>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
