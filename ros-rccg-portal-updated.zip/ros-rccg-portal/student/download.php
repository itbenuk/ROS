<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');

$pdo = getDB();

// Passport photo streaming (used for <img> src) - restricted to own photo or generally viewable avatar
if (($_GET['type'] ?? '') === 'passport') {
    $file = basename($_GET['file'] ?? ''); // basename() strips any path traversal attempt
    $path = UPLOAD_PASSPORTS_PATH . $file;
    if (!$file || !is_file($path)) {
        http_response_code(404);
        exit('Not found.');
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    header('Content-Type: ' . finfo_file($finfo, $path));
    finfo_close($finfo);
    header('Content-Disposition: inline; filename="' . $file . '"');
    readfile($path);
    exit;
}

// Material download
$id = (int) ($_GET['id'] ?? 0);
$studentId = $_SESSION['ref_id'];

$studentStmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$studentStmt->execute([$studentId]);
$student = $studentStmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM materials WHERE id = ? AND status = 'published'");
$stmt->execute([$id]);
$material = $stmt->fetch();

if (!$material || !student_can_access_material($material, $student)) {
    flash('warning', 'Material not found or unavailable to you.');
    redirect('/student/materials.php');
}

$path = UPLOAD_MATERIALS_PATH . $material['stored_name'];
if (!is_file($path)) {
    flash('error', 'The requested file could not be located on the server.');
    redirect('/student/materials.php');
}

// Log the download + increment counter
$pdo->beginTransaction();
$pdo->prepare("INSERT INTO material_downloads (material_id, student_id, ip_address) VALUES (?,?,?)")
    ->execute([$id, $studentId, $_SERVER['REMOTE_ADDR'] ?? null]);
$pdo->prepare("UPDATE materials SET download_count = download_count + 1 WHERE id = ?")->execute([$id]);
$pdo->commit();

// Stream the file
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $path);
finfo_close($finfo);

header('Content-Type: ' . $mime);
header('Content-Disposition: attachment; filename="' . $material['file_name'] . '"');
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
