<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
$pageTitle = 'Material Details';

$pdo = getDB();
$studentId = $_SESSION['ref_id'];
$id = (int) ($_GET['id'] ?? 0);

$studentStmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$studentStmt->execute([$studentId]);
$student = $studentStmt->fetch();

$stmt = $pdo->prepare("SELECT m.*, c.name AS course_name, cat.name AS category_name, f.first_name, f.last_name
                        FROM materials m
                        LEFT JOIN courses c ON c.id = m.course_id
                        LEFT JOIN categories cat ON cat.id = m.category_id
                        LEFT JOIN faculty f ON f.id = m.faculty_id
                        WHERE m.id = ? AND m.status = 'published'");
$stmt->execute([$id]);
$material = $stmt->fetch();

if (!$material || !student_can_access_material($material, $student)) {
    flash('warning', 'Material not found or is no longer available to you.');
    redirect('/student/materials.php');
}

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/student-sidebar.php'; ?>
  <div class="dash-content">
    <a href="<?= BASE_URL ?>/student/materials.php" class="small mb-3 d-inline-block"><i class="fa-solid fa-arrow-left me-1"></i>Back to Materials</a>
    <div class="card p-4">
      <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
        <div>
          <h4 class="mb-1"><?= e($material['title']) ?></h4>
          <div class="text-muted small">
            <?= e($material['course_name'] ?? 'General') ?> &middot; <?= e($material['category_name'] ?? 'Uncategorized') ?>
            &middot; Uploaded by <?= e(trim(($material['first_name'] ?? '') . ' ' . ($material['last_name'] ?? '')) ?: 'Faculty') ?>
          </div>
        </div>
        <span class="badge text-bg-light text-uppercase fs-6"><?= e($material['file_type']) ?></span>
      </div>
      <p><?= nl2br(e($material['description'] ?: 'No description provided.')) ?></p>
      <ul class="list-inline text-muted small">
        <li class="list-inline-item me-4"><i class="fa-solid fa-weight-hanging me-1"></i><?= human_filesize((int)$material['file_size']) ?></li>
        <li class="list-inline-item me-4"><i class="fa-solid fa-calendar me-1"></i><?= date('M j, Y', strtotime($material['created_at'])) ?></li>
        <li class="list-inline-item"><i class="fa-solid fa-download me-1"></i><?= (int)$material['download_count'] ?> downloads</li>
      </ul>
      <a href="<?= BASE_URL ?>/student/download.php?id=<?= (int)$material['id'] ?>" class="btn btn-gold mt-3">
        <i class="fa-solid fa-download me-2"></i>Download Material
      </a>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
