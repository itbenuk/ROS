<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
$pageTitle = 'Dashboard';

$pdo = getDB();
$studentId = $_SESSION['ref_id'];

$stmt = $pdo->prepare("SELECT s.*, c.name AS course_name, se.name AS session_name
                        FROM students s
                        LEFT JOIN courses c ON c.id = s.course_id
                        LEFT JOIN sessions se ON se.id = s.session_id
                        WHERE s.id = ?");
$stmt->execute([$studentId]);
$student = $stmt->fetch();

$materialCount = $pdo->query("SELECT COUNT(*) c FROM materials WHERE status='published'")->fetch()['c'];

$availableTestsCount = $pdo->prepare("SELECT COUNT(*) c FROM tests t
    WHERE t.status IN ('published','scheduled') AND NOW() BETWEEN t.start_at AND t.end_at
    AND (
        EXISTS (SELECT 1 FROM test_assignments a1 WHERE a1.test_id = t.id AND a1.student_id = ?)
        OR (t.course_id = (SELECT course_id FROM students WHERE id = ?) AND NOT EXISTS (SELECT 1 FROM test_assignments a2 WHERE a2.test_id = t.id))
    )
    AND NOT EXISTS (SELECT 1 FROM test_attempts ta WHERE ta.test_id = t.id AND ta.student_id = ? AND ta.status != 'in_progress')");
$availableTestsCount->execute([$studentId, $studentId, $studentId]);
$availableTestsCount = $availableTestsCount->fetch()['c'];

$recentMaterials = $pdo->query("SELECT m.*, c.name AS course_name, cat.name AS category_name
                                 FROM materials m
                                 LEFT JOIN courses c ON c.id = m.course_id
                                 LEFT JOIN categories cat ON cat.id = m.category_id
                                 WHERE m.status = 'published'
                                 ORDER BY m.created_at DESC LIMIT 5")->fetchAll();

$announcements = $pdo->query("SELECT a.*, u.email AS poster_email FROM announcements a
                               JOIN users u ON u.id = a.posted_by_user_id
                               WHERE a.is_published = 1 AND a.audience IN ('all','students')
                               ORDER BY a.created_at DESC LIMIT 4")->fetchAll();

$downloadStmt = $pdo->prepare("SELECT COUNT(*) c FROM material_downloads WHERE student_id = ?");
$downloadStmt->execute([$studentId]);
$myDownloads = $downloadStmt->fetch()['c'];

$recentDownloads = $pdo->prepare("SELECT md.downloaded_at, m.title FROM material_downloads md
                                   JOIN materials m ON m.id = md.material_id
                                   WHERE md.student_id = ? ORDER BY md.downloaded_at DESC LIMIT 5");
$recentDownloads->execute([$studentId]);
$recentDownloads = $recentDownloads->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/student-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="mb-1">Welcome, <?= e($student['first_name']) ?> 👋</h3>
    <p class="text-muted mb-4">Reg. No: <strong><?= e($student['reg_number']) ?></strong> &middot; <?= e($student['course_name'] ?? 'No programme assigned') ?></p>

    <div class="row g-3 mb-4">
      <div class="col-6 col-lg-3">
        <div class="stat-card">
          <div class="stat-icon mb-2" style="background:#6b1530;"><i class="fa-solid fa-book-open"></i></div>
          <div class="stat-value"><?= (int)$materialCount ?></div>
          <div class="stat-label">Available Materials</div>
        </div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card">
          <div class="stat-icon mb-2" style="background:#c9a24b;"><i class="fa-solid fa-download"></i></div>
          <div class="stat-value"><?= (int)$myDownloads ?></div>
          <div class="stat-label">My Downloads</div>
        </div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card">
          <div class="stat-icon mb-2" style="background:#1e7e34;"><i class="fa-solid fa-graduation-cap"></i></div>
          <div class="stat-value"><?= e($student['session_name'] ?? '-') ?></div>
          <div class="stat-label">Current Session</div>
        </div>
      </div>
      <div class="col-6 col-lg-3">
        <a href="<?= BASE_URL ?>/student/tests.php" class="text-decoration-none">
        <div class="stat-card">
          <div class="stat-icon mb-2" style="background:#4a0e21;"><i class="fa-solid fa-file-pen"></i></div>
          <div class="stat-value"><?= (int)$availableTestsCount ?></div>
          <div class="stat-label">Tests Available Now</div>
        </div>
        </a>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card">
          <div class="stat-icon mb-2" style="background:#b26a00;"><i class="fa-solid fa-bullhorn"></i></div>
          <div class="stat-value"><?= count($announcements) ?></div>
          <div class="stat-label">New Announcements</div>
        </div>
      </div>
    </div>

    <div class="row g-4">
      <div class="col-lg-7">
        <div class="card p-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="mb-0 fw-bold">Recently Uploaded Materials</h6>
            <a href="<?= BASE_URL ?>/student/materials.php" class="small">View all</a>
          </div>
          <?php if (!$recentMaterials): ?>
            <div class="empty-state py-3"><i class="fa-solid fa-inbox"></i><p>No materials available yet.</p></div>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table align-middle">
                <tbody>
                <?php foreach ($recentMaterials as $m): ?>
                  <tr>
                    <td style="width:42px;"><i class="fa-solid fa-file-lines material-icon text-gold"></i></td>
                    <td>
                      <a href="<?= BASE_URL ?>/student/material-view.php?id=<?= (int)$m['id'] ?>" class="fw-semibold text-decoration-none"><?= e($m['title']) ?></a>
                      <div class="small text-muted"><?= e($m['course_name'] ?? 'General') ?> &middot; <?= e($m['category_name'] ?? '') ?></div>
                    </td>
                    <td class="text-muted small text-end"><?= time_ago($m['created_at']) ?></td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <div class="col-lg-5">
        <div class="card p-4 mb-4">
          <h6 class="mb-3 fw-bold">Announcements</h6>
          <?php if (!$announcements): ?>
            <div class="empty-state py-3"><i class="fa-solid fa-bullhorn"></i><p>No announcements yet.</p></div>
          <?php else: foreach ($announcements as $a): ?>
            <div class="border-bottom pb-2 mb-2">
              <div class="fw-semibold"><?= e($a['title']) ?></div>
              <div class="small text-muted"><?= time_ago($a['created_at']) ?></div>
            </div>
          <?php endforeach; endif; ?>
        </div>

        <div class="card p-4">
          <h6 class="mb-3 fw-bold">My Download History</h6>
          <?php if (!$recentDownloads): ?>
            <div class="empty-state py-3"><i class="fa-solid fa-clock-rotate-left"></i><p>No downloads yet.</p></div>
          <?php else: foreach ($recentDownloads as $d): ?>
            <div class="d-flex justify-content-between small mb-2">
              <span><?= e($d['title']) ?></span>
              <span class="text-muted"><?= time_ago($d['downloaded_at']) ?></span>
            </div>
          <?php endforeach; endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
