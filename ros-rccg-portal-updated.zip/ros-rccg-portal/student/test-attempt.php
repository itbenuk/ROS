<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');

$pdo = getDB();
$studentId = $_SESSION['ref_id'];
$testId = (int) ($_GET['id'] ?? $_POST['test_id'] ?? 0);

$studentStmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$studentStmt->execute([$studentId]);
$student = $studentStmt->fetch();

$stmt = $pdo->prepare("SELECT t.*, c.name AS course_name FROM tests t LEFT JOIN courses c ON c.id = t.course_id WHERE t.id = ?");
$stmt->execute([$testId]);
$test = $stmt->fetch();

if (!$test || $test['status'] === 'draft' || !student_can_access_test($pdo, $test, $student)) {
    flash('error', 'That test is not available to you.');
    redirect('/student/tests.php');
}

// Existing attempt?
$attStmt = $pdo->prepare("SELECT * FROM test_attempts WHERE test_id = ? AND student_id = ?");
$attStmt->execute([$testId, $studentId]);
$attempt = $attStmt->fetch();

if ($attempt && $attempt['status'] !== 'in_progress') {
    redirect('/student/test-result.php?attempt_id=' . $attempt['id']);
}

// Handle "Start Test" submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'start') {
    require_csrf_or_die();

    if (!test_is_open($test)) {
        flash('error', 'This test is not currently open.');
        redirect('/student/tests.php');
    }
    if (!$attempt) {
        $qCount = $pdo->prepare("SELECT COUNT(*) c FROM test_questions WHERE test_id = ?");
        $qCount->execute([$testId]);
        if ((int) $qCount->fetch()['c'] === 0) {
            flash('error', 'This test has no questions yet. Please check back later.');
            redirect('/student/tests.php');
        }

        $startedAt = date('Y-m-d H:i:s');
        $expiresBydur = strtotime($startedAt) + ((int) $test['duration_minutes'] * 60);
        $expiresByWindow = strtotime($test['end_at']);
        $expiresAt = date('Y-m-d H:i:s', min($expiresBydur, $expiresByWindow));

        try {
            $ins = $pdo->prepare("INSERT INTO test_attempts (test_id, student_id, status, started_at, expires_at, ip_address)
                                   VALUES (?,?, 'in_progress', ?, ?, ?)");
            $ins->execute([$testId, $studentId, $startedAt, $expiresAt, $_SERVER['REMOTE_ADDR'] ?? null]);
            audit_log($_SESSION['user_id'], 'test_attempt_started', "Test #$testId");
        } catch (Throwable $e) {
            // UNIQUE(test_id, student_id) collision = attempt already exists (race/double click)
        }
    }
    redirect('/student/test-attempt.php?id=' . $testId);
}

// Re-fetch attempt in case it was just created
$attStmt->execute([$testId, $studentId]);
$attempt = $attStmt->fetch();

$pageTitle = $test['title'];

if (!$attempt) {
    // Show start confirmation screen
    $questionCount = $pdo->prepare("SELECT COUNT(*) c FROM test_questions WHERE test_id = ?");
    $questionCount->execute([$testId]);
    $questionCount = (int) $questionCount->fetch()['c'];

    include __DIR__ . '/../includes/header.php';
    ?>
    <div class="dash-wrapper">
      <?php include __DIR__ . '/../includes/student-sidebar.php'; ?>
      <div class="dash-content">
        <?php if (!test_is_open($test)): ?>
          <div class="alert alert-warning">This test is not currently open. <a href="<?= BASE_URL ?>/student/tests.php">Back to My Tests</a></div>
        <?php else: ?>
        <div class="card p-4 mx-auto" style="max-width:640px;">
          <h4 class="mb-1"><?= e($test['title']) ?></h4>
          <p class="text-muted mb-3"><?= e($test['course_name'] ?? 'General') ?></p>
          <p><?= nl2br(e($test['description'] ?: 'No special instructions.')) ?></p>
          <ul class="list-unstyled small mb-4">
            <li class="mb-1"><i class="fa-solid fa-list-ol me-2 text-gold"></i><?= $questionCount ?> question(s)</li>
            <li class="mb-1"><i class="fa-solid fa-clock me-2 text-gold"></i>Duration: <?= format_duration((int)$test['duration_minutes']) ?></li>
            <li class="mb-1"><i class="fa-solid fa-hourglass-end me-2 text-gold"></i>Closes: <?= date('M j, Y g:ia', strtotime($test['end_at'])) ?></li>
            <li class="mb-1"><i class="fa-solid fa-check-double me-2 text-gold"></i>Pass mark: <?= e($test['passing_score']) ?>%</li>
          </ul>
          <div class="alert alert-danger small">
            <i class="fa-solid fa-triangle-exclamation me-1"></i><strong>Stay on this tab for the entire test.</strong>
            Switching to another tab or window, minimizing the browser, or leaving this page in any detectable way
            will <strong>immediately and automatically submit your test</strong> exactly as it stands at that moment &mdash;
            this cannot be undone or reopened.
          </div>
          <div class="alert alert-info small">
            <i class="fa-solid fa-circle-info me-1"></i>Once started, the timer cannot be paused. If you lose your internet connection, your answers already saved are kept and the timer keeps running &mdash; the test will auto-submit when time runs out.
          </div>
          <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="test_id" value="<?= (int)$testId ?>">
            <input type="hidden" name="action" value="start">
            <button type="submit" class="btn btn-gold w-100 btn-lg"><i class="fa-solid fa-play me-2"></i>Start Test</button>
          </form>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php include __DIR__ . '/../includes/footer.php';
    exit;
}

// ---- Attempt is in_progress: render the test-taking interface ----

$questions = $pdo->prepare("SELECT q.id, q.question_text, q.question_type, q.marks, q.order_index FROM test_questions q WHERE q.test_id = ? ORDER BY q.order_index");
$questions->execute([$testId]);
$questions = $questions->fetchAll();

if ($test['shuffle_questions']) {
    // Deterministic per-student shuffle so refreshing doesn't reorder mid-attempt
    mt_srand($attempt['id']);
    shuffle($questions);
}

$existingAnswers = $pdo->prepare("SELECT question_id, selected_option_id, answer_text FROM test_answers WHERE attempt_id = ?");
$existingAnswers->execute([$attempt['id']]);
$answersByQuestion = [];
foreach ($existingAnswers->fetchAll() as $a) {
    $answersByQuestion[$a['question_id']] = $a;
}

$questions = load_public_options_for_questions($pdo, $questions);
foreach ($questions as &$q) {
    $existing = $answersByQuestion[$q['id']] ?? null;
    $q['selected_option_id'] = $existing['selected_option_id'] ?? null;
    $q['answer_text'] = $existing['answer_text'] ?? '';
}
unset($q);

$serverNow = time();
$expiresAtTs = strtotime($attempt['expires_at']);

include __DIR__ . '/../includes/header.php';
?>
<style>
  .qa-timer { font-variant-numeric: tabular-nums; font-size: 1.3rem; font-weight: 700; }
  .qa-nav-btn { width: 38px; height: 38px; border-radius: 8px; flex-shrink: 0; }
  .qa-nav-btn.answered { background: #e6f4ea; border-color: #1e7e34; color: #1e7e34; }
  .qa-nav-btn.current { outline: 3px solid var(--gold); }
  .qa-question { display: none; }
  .qa-question.active { display: block; }
  .qa-nav-scroll { overflow-x: auto; padding-bottom: 4px; }
  @media (max-width: 576px) {
    .qa-controls { flex-direction: column; align-items: stretch !important; }
    .qa-controls .qa-prevnext { display: flex; gap: .5rem; }
    .qa-controls .qa-prevnext .btn { flex: 1; }
  }
</style>

<div class="container-fluid pt-3 px-3">
  <div class="alert alert-danger py-2 px-3 mb-0 text-center small mx-auto" style="max-width:900px;">
    <i class="fa-solid fa-triangle-exclamation me-1"></i>Do not switch tabs or leave this window &mdash; doing so will automatically submit your test.
  </div>
</div>
<div class="container-fluid py-3">
  <div class="row g-3 justify-content-center">
    <div class="col-12 col-xl-10">
      <div class="card p-4 mb-3 d-flex flex-row justify-content-between align-items-center flex-wrap gap-2 sticky-top" style="top:80px; z-index:10;">
        <div>
          <h5 class="mb-0"><?= e($test['title']) ?></h5>
          <span class="small text-muted">Question <span id="currentQNum">1</span> of <?= count($questions) ?></span>
        </div>
        <div class="text-center">
          <div class="small text-muted mb-0">Time Remaining</div>
          <div class="qa-timer text-danger" id="timerDisplay">--:--</div>
        </div>
      </div>

      <div id="questionsContainer">
        <?php foreach ($questions as $i => $q): ?>
          <div class="card p-4 mb-3 qa-question <?= $i === 0 ? 'active' : '' ?>" data-index="<?= $i ?>" data-question-id="<?= (int)$q['id'] ?>">
            <div class="d-flex justify-content-between mb-3">
              <span class="fw-semibold">Question <?= $i + 1 ?> of <?= count($questions) ?></span>
              <span class="badge text-bg-light"><?= e($q['marks']) ?> mark(s)</span>
            </div>
            <p class="mb-3"><?= nl2br(e($q['question_text'])) ?></p>

            <?php if ($q['question_type'] === 'short_answer'): ?>
              <input type="text" class="form-control qa-answer-input" data-type="short_answer" placeholder="Type your answer here" value="<?= e($q['answer_text']) ?>">
            <?php else: ?>
              <?php foreach ($q['options'] as $o): ?>
                <div class="form-check mb-2 p-3 border rounded">
                  <input class="form-check-input qa-answer-input" type="radio" data-type="option"
                         name="q<?= (int)$q['id'] ?>" value="<?= (int)$o['id'] ?>"
                         id="opt<?= (int)$o['id'] ?>" <?= (int)$q['selected_option_id'] === (int)$o['id'] ? 'checked' : '' ?>>
                  <label class="form-check-label w-100" for="opt<?= (int)$o['id'] ?>"><?= e($o['option_text']) ?></label>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
            <div class="small text-muted mt-2 save-status"></div>
          </div>
        <?php endforeach; ?>
      </div>

      <!-- Pagination / navigation controls now sit directly below the question, full width -->
      <div class="card p-3">
        <div class="qa-nav-scroll mb-3">
          <div class="d-flex gap-2" id="qNav"></div>
        </div>
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 qa-controls">
          <div class="qa-prevnext d-flex gap-2">
            <button class="btn btn-outline-secondary" id="prevBtn"><i class="fa-solid fa-arrow-left me-2"></i>Previous</button>
            <button class="btn btn-outline-secondary" id="nextBtn">Next<i class="fa-solid fa-arrow-right ms-2"></i></button>
          </div>
          <div class="small text-muted">
            <span class="qa-nav-btn answered d-inline-block" style="width:12px;height:12px;"></span> Answered
            &nbsp;&nbsp;<span class="qa-nav-btn d-inline-block border" style="width:12px;height:12px;"></span> Unanswered
          </div>
          <button class="btn btn-gold" id="submitBtn" data-bs-toggle="modal" data-bs-target="#submitModal"><i class="fa-solid fa-paper-plane me-2"></i>Submit Test</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Submit confirmation modal -->
<div class="modal fade" id="submitModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Submit Test?</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <p>You have answered <strong id="answeredCount">0</strong> of <strong><?= count($questions) ?></strong> questions.</p>
        <p class="text-muted small mb-0">Once submitted, you cannot change your answers.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Keep Reviewing</button>
        <button type="button" class="btn btn-gold" id="confirmSubmitBtn">Submit Now</button>
      </div>
    </div>
  </div>
</div>

<script>
const ATTEMPT_ID = <?= (int) $attempt['id'] ?>;
const CSRF_TOKEN = <?= json_encode(csrf_token()) ?>;
const AJAX_BASE = <?= json_encode(BASE_URL . '/ajax') ?>;
const RESULT_URL = <?= json_encode(BASE_URL . '/student/test-result.php?attempt_id=' . $attempt['id']) ?>;
let SERVER_EXPIRES_TS = <?= (int) $expiresAtTs ?>; // unix seconds, server-authoritative
let CLOCK_OFFSET = <?= (int) $serverNow ?> - Math.floor(Date.now() / 1000); // corrects for client clock drift
let submitted = false;
let currentIndex = 0;
const questions = document.querySelectorAll('.qa-question');
const total = questions.length;
const answered = new Set();

function nowServerTime() {
  return Math.floor(Date.now() / 1000) + CLOCK_OFFSET;
}

function buildNav() {
  const nav = document.getElementById('qNav');
  nav.innerHTML = '';
  questions.forEach((q, i) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn btn-outline-secondary qa-nav-btn' + (i === currentIndex ? ' current' : '');
    btn.textContent = i + 1;
    btn.onclick = () => showQuestion(i);
    btn.dataset.index = i;
    nav.appendChild(btn);
  });
  refreshNavStates();
}

function refreshNavStates() {
  document.querySelectorAll('#qNav button').forEach((btn, i) => {
    btn.classList.toggle('current', i === currentIndex);
    btn.classList.toggle('answered', answered.has(i));
  });
  document.getElementById('answeredCount').textContent = answered.size;
}

function showQuestion(index) {
  questions[currentIndex].classList.remove('active');
  currentIndex = index;
  questions[currentIndex].classList.add('active');
  document.getElementById('currentQNum').textContent = currentIndex + 1;
  document.getElementById('prevBtn').disabled = currentIndex === 0;
  document.getElementById('nextBtn').disabled = currentIndex === total - 1;
  refreshNavStates();
}

document.getElementById('prevBtn').addEventListener('click', () => { if (currentIndex > 0) showQuestion(currentIndex - 1); });
document.getElementById('nextBtn').addEventListener('click', () => { if (currentIndex < total - 1) showQuestion(currentIndex + 1); });

async function saveAnswer(questionEl) {
  if (submitted) return;
  const qId = questionEl.dataset.questionId;
  const qIndex = parseInt(questionEl.dataset.index, 10);
  const input = questionEl.querySelector('.qa-answer-input[data-type="short_answer"]');
  const radio = questionEl.querySelector('.qa-answer-input[data-type="option"]:checked');
  const statusEl = questionEl.querySelector('.save-status');

  if (!input && !radio) return; // nothing selected yet

  const body = new FormData();
  body.append('csrf_token', CSRF_TOKEN);
  body.append('attempt_id', ATTEMPT_ID);
  body.append('question_id', qId);
  if (input) body.append('answer_text', input.value);
  if (radio) body.append('selected_option_id', radio.value);

  statusEl.textContent = 'Saving...';
  try {
    const res = await fetch(`${AJAX_BASE}/test_save_answer.php`, { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' }, body });
    const data = await res.json();
    if (data.success) {
      answered.add(qIndex);
      statusEl.textContent = 'Saved ✓';
      refreshNavStates();
      if (data.force_submit) { forceSubmit(); }
    } else {
      statusEl.textContent = data.message || 'Could not save. Retrying...';
    }
  } catch (e) {
    statusEl.textContent = 'Network issue — will retry on next change.';
  }
}

questions.forEach((q) => {
  q.querySelectorAll('.qa-answer-input[data-type="option"]').forEach((r) => r.addEventListener('change', () => saveAnswer(q)));
  const textInput = q.querySelector('.qa-answer-input[data-type="short_answer"]');
  if (textInput) {
    let debounce;
    textInput.addEventListener('input', () => {
      clearTimeout(debounce);
      debounce = setTimeout(() => saveAnswer(q), 700);
    });
  }
  if (q.querySelector('.qa-answer-input[data-type="option"]:checked') || (textInput && textInput.value.trim() !== '')) {
    answered.add(parseInt(q.dataset.index, 10));
  }
});

async function doSubmit() {
  if (submitted) return;
  submitted = true;
  const body = new FormData();
  body.append('csrf_token', CSRF_TOKEN);
  body.append('attempt_id', ATTEMPT_ID);
  try {
    const res = await fetch(`${AJAX_BASE}/test_submit.php`, { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' }, body });
    await res.json();
  } catch (e) { /* fall through to redirect regardless */ }
  window.location.href = RESULT_URL;
}

function forceSubmit() {
  if (submitted) return;
  App.toast('Time is up! Submitting your test...', 'warning');
  doSubmit();
}

document.getElementById('confirmSubmitBtn').addEventListener('click', doSubmit);

// ---- Exam monitoring: auto-submit if the student navigates away from this tab ----
// We rely solely on the Page Visibility API (document.hidden / visibilitychange),
// which reliably fires for tab switches, minimizing, and switching apps across all
// modern browsers, and — unlike window "blur" — is NOT triggered by benign in-page
// interactions such as opening a Bootstrap modal, a native <select>, or a file
// picker, so it will not cause accidental submissions during normal use.
let violationTriggered = false;

function submitWithReason(reason) {
  if (submitted) return;
  submitted = true;
  violationTriggered = true;
  const body = new FormData();
  body.append('csrf_token', CSRF_TOKEN);
  body.append('attempt_id', ATTEMPT_ID);
  body.append('reason', reason);
  // sendBeacon is used (rather than fetch) because it is specifically designed to
  // reliably deliver a request even as the page is being hidden/unloaded.
  const delivered = navigator.sendBeacon ? navigator.sendBeacon(`${AJAX_BASE}/test_submit.php`, body) : false;
  if (!delivered) {
    fetch(`${AJAX_BASE}/test_submit.php`, { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' }, body, keepalive: true }).catch(() => {});
  }
}

document.addEventListener('visibilitychange', function () {
  if (document.hidden) {
    if (!submitted) {
      submitWithReason('tab_switch');
    }
  } else if (violationTriggered) {
    // The student came back to the tab after a violation was already recorded -
    // send them straight to the result screen; the attempt can't be resumed.
    window.location.href = RESULT_URL;
  }
});

// ---- Timer: local tick every second, resynced with the server every 15s ----
function tick() {
  const remaining = SERVER_EXPIRES_TS - nowServerTime();
  const display = document.getElementById('timerDisplay');
  if (remaining <= 0) {
    display.textContent = '00:00';
    forceSubmit();
    return;
  }
  const h = Math.floor(remaining / 3600);
  const m = Math.floor((remaining % 3600) / 60);
  const s = remaining % 60;
  display.textContent = (h > 0 ? String(h).padStart(2,'0') + ':' : '') + String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
  if (remaining <= 60) { display.classList.add('text-danger'); }
}

async function heartbeat() {
  if (submitted) return;
  try {
    const body = new FormData();
    body.append('csrf_token', CSRF_TOKEN);
    body.append('attempt_id', ATTEMPT_ID);
    const res = await fetch(`${AJAX_BASE}/test_heartbeat.php`, { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' }, body });
    const data = await res.json();
    if (data.success) {
      SERVER_EXPIRES_TS = data.expires_at;
      CLOCK_OFFSET = data.server_now - Math.floor(Date.now() / 1000);
      if (data.status !== 'in_progress') { forceSubmit(); }
    }
  } catch (e) { /* keep local timer running on transient network errors */ }
}

buildNav();
showQuestion(0);
refreshNavStates();
setInterval(tick, 1000);
tick();
setInterval(heartbeat, 15000);
heartbeat();

window.addEventListener('beforeunload', function (e) {
  if (!submitted) {
    e.preventDefault();
    e.returnValue = '';
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
