<?php
require_once __DIR__ . '/../config/config.php';
require_role('student');
$pageTitle = 'My Courses';

$pdo = getDB();
$studentId = $_SESSION['ref_id'];

$stmt = $pdo->prepare("SELECT s.*, c.id AS course_id, c.name AS course_name, c.code, c.description, se.name AS session_name
                        FROM students s
                        LEFT JOIN courses c ON c.id = s.course_id
                        LEFT JOIN sessions se ON se.id = s.session_id
                        WHERE s.id = ?");
$stmt->execute([$studentId]);
$student = $stmt->fetch();

$faculty = [];
$materialCount = 0;
$testCount = 0;
if ($student['course_id']) {
    $f = $pdo->prepare("SELECT f.first_name, f.last_name, f.title, f.department
                         FROM faculty_courses fc JOIN faculty f ON f.id = fc.faculty_id
                         WHERE fc.course_id = ?");
    $f->execute([$student['course_id']]);
    $faculty = $f->fetchAll();

    $mc = $pdo->prepare("SELECT COUNT(*) c FROM materials WHERE course_id = ? AND status = 'published'");
    $mc->execute([$student['course_id']]);
    $materialCount = $mc->fetch()['c'];

    $tc = $pdo->prepare("SELECT COUNT(*) c FROM tests WHERE course_id = ? AND status IN ('published','scheduled')");
    $tc->execute([$student['course_id']]);
    $testCount = $tc->fetch()['c'];
}

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/student-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">My Courses</h3>

    <?php if (!$student['course_id']): ?>
      <div class="empty-state"><i class="fa-solid fa-book"></i><p>You are not yet assigned to a programme. Contact the administrator.</p></div>
    <?php else: ?>
      <div class="card p-4 mb-4">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
          <div>
            <h4 class="mb-1"><?= e($student['course_name']) ?></h4>
            <p class="text-muted mb-2"><?= e($student['code']) ?> &middot; <?= e($student['session_name'] ?? 'No session assigned') ?></p>
          </div>
        </div>
        <p class="mb-0"><?= nl2br(e($student['description'] ?: 'No description provided.')) ?></p>
      </div>

      <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
          <a href="<?= BASE_URL ?>/student/materials.php" class="text-decoration-none">
            <div class="stat-card"><div class="stat-value"><?= (int)$materialCount ?></div><div class="stat-label">Learning Materials</div></div>
          </a>
        </div>
        <div class="col-6 col-lg-3">
          <a href="<?= BASE_URL ?>/student/tests.php" class="text-decoration-none">
            <div class="stat-card"><div class="stat-value"><?= (int)$testCount ?></div><div class="stat-label">Available Tests</div></div>
          </a>
        </div>
      </div>

      <div class="card p-4">
        <h6 class="fw-bold mb-3">Faculty Teaching This Programme</h6>
        <?php if (!$faculty): ?>
          <div class="empty-state py-3"><i class="fa-solid fa-chalkboard-user"></i><p>No faculty assigned yet.</p></div>
        <?php else: foreach ($faculty as $f): ?>
          <div class="d-flex align-items-center gap-2 border-bottom pb-2 mb-2">
            <i class="fa-solid fa-circle-user fa-lg text-secondary"></i>
            <div>
              <div class="fw-semibold"><?= e(trim($f['title'].' '.$f['first_name'].' '.$f['last_name'])) ?></div>
              <div class="small text-muted"><?= e($f['department'] ?: '-') ?></div>
            </div>
          </div>
        <?php endforeach; endif; ?>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
