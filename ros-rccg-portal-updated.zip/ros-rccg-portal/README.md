# ROS RCCG Student Registration & Faculty Learning Management Portal

A complete, self-contained PHP/MySQL web application for student registration,
faculty learning-material management, and system administration — built with
plain HTML5, CSS3, Vanilla JavaScript, PHP 8+, MySQL 8+, and Bootstrap 5.

No frameworks (Laravel, Node.js, React, etc.) are used.

---

## 1. Requirements

| Component | Minimum Version |
|---|---|
| PHP        | 8.0+ (tested with 8.1/8.2) — requires `pdo_mysql`, `fileinfo`, `mbstring` extensions |
| MySQL      | 8.0+ (or MariaDB 10.4+) |
| Web server | Apache with `mod_rewrite`/`mod_headers` (XAMPP, WAMP, LAMP, or standalone Apache/Nginx) |

---

## 2. Folder Structure

```
ros-rccg-portal/
├── index.php, about.php, contact.php
├── student-register.php, student-login.php, faculty-login.php, admin-login.php
├── forgot-password.php, reset-password.php, logout.php
├── config/            → database.php, config.php, constants.php
├── includes/          → auth.php, functions.php, header/footer, sidebars
├── student/           → student portal pages
├── faculty/           → faculty portal pages
├── admin/             → admin portal pages
├── ajax/              → JSON endpoints (upload, search, email check)
├── assets/            → css/, js/, images/
├── uploads/           → materials/ and passports/ (protected by .htaccess)
└── database/database.sql
```

---

## 3. Installation (XAMPP / WAMP / LAMP)

### Step 1 — Copy the project
Place the `ros-rccg-portal` folder inside your server's web root:
- XAMPP: `C:\xampp\htdocs\ros-rccg-portal`
- WAMP: `C:\wamp64\www\ros-rccg-portal`
- LAMP: `/var/www/html/ros-rccg-portal`

### Step 2 — Create the database
1. Open phpMyAdmin (or the MySQL CLI).
2. Create a database, or simply import `database/database.sql`, which
   creates the database `ros_rccg_portal` automatically:
   ```
   mysql -u root -p < database/database.sql
   ```
   or via phpMyAdmin: **Import → choose `database/database.sql` → Go**.

This creates all required tables (`users`, `students`, `faculty`, `courses`,
`categories`, `materials`, `material_downloads`, `announcements`, `sessions`,
`password_resets`, `audit_logs`, `system_settings`) plus seed data (sample
courses, categories, sessions, and one default admin + one sample faculty
account).

### Step 3 — Configure database credentials
Edit `config/database.php`:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'ros_rccg_portal');
define('DB_USER', 'root');
define('DB_PASS', '');          // your MySQL password
```

### Step 4 — Configure the base URL
Edit `config/constants.php` and set `BASE_URL` to match your install path, e.g.:
```php
define('BASE_URL', '/ros-rccg-portal');   // if visiting http://localhost/ros-rccg-portal
// or
define('BASE_URL', '');                   // if this is the web root (e.g. a subdomain)
```

### Step 5 — Configure uploads
The `uploads/materials/` and `uploads/passports/` folders must be writable
by the web server:
```
chmod -R 755 uploads/
```
An `.htaccess` file inside `uploads/` blocks direct script execution — do not
remove it. All files are served through `download.php` controllers, never
linked to directly.

### Step 6 — Configure password-reset email (optional, production)
`forgot-password.php` currently logs reset tokens via `audit_log()` instead of
emailing them (no mail server is assumed in local dev). For production, wire
up `mail()` or a transactional email service (e.g. PHPMailer + SMTP) inside
`forgot-password.php` where indicated by the comment:
```php
// e.g. mail($email, 'Password Reset', BASE_URL . "/reset-password.php?token=$token");
```

### Step 7 — Default administrator login
```
URL:      http://localhost/ros-rccg-portal/admin-login.php
Email:    admin@rosrccg.org
Password: Admin@12345
```
**Change this password immediately** after first login (there is currently no
in-app "change password" screen for admins — update it directly via
`admin/students.php`-style reset logic, or run:
```sql
UPDATE users SET password_hash = '<new bcrypt hash>' WHERE email = 'admin@rosrccg.org';
```
generated with PHP: `password_hash('YourNewPassword', PASSWORD_DEFAULT)`.

A sample faculty login is also seeded:
```
URL:      http://localhost/ros-rccg-portal/faculty-login.php
Email:    faculty@rosrccg.org
Password: Faculty@12345
```

### Step 8 — Visit the site
Open `http://localhost/ros-rccg-portal/index.php` in your browser.

---

## 4. Security Notes

- All database queries use **PDO prepared statements** — no raw string
  concatenation of user input into SQL anywhere in the codebase.
- Passwords are hashed with `password_hash()` / verified with `password_verify()`.
- **CSRF tokens** are required on every state-changing form and AJAX POST
  (`includes/functions.php::csrf_field()` / `verify_csrf()`).
- Sessions use `httponly`, `SameSite=Lax` cookies, are regenerated on login
  (`session_regenerate_id(true)`), and expire after 2 hours of inactivity.
- **Brute-force protection**: 5 failed logins locks an account for 15 minutes.
- **File uploads** are validated server-side by real MIME type (`finfo`), not
  by trusting the client-supplied extension. Files are renamed to random
  hex strings on disk and stored inside `/uploads`, which has `.htaccess`
  rules denying script execution. All downloads are streamed through a PHP
  controller (`student/download.php`, `faculty/download.php`,
  `admin/download.php`) rather than being linked to directly.
- Output is escaped via `e()` (an `htmlspecialchars` wrapper) everywhere
  user-supplied or database content is echoed into HTML, preventing XSS.
- Role-based authorization is enforced with `require_role()` at the top of
  every protected page — never trust a hidden form field or URL parameter
  for access control.
- Raw exceptions and database errors are logged to `error.log`, never shown
  to the browser.
- Every significant administrative action (status changes, deletions,
  password resets, uploads) is written to the `audit_logs` table.

For production deployment, additionally:
- Serve the whole application over **HTTPS** (the session cookie's `secure`
  flag activates automatically once `$_SERVER['HTTPS']` is set).
- Set `display_errors = Off` in `php.ini` (already forced in `config/config.php`).
- Consider moving `/uploads` entirely outside the web root and streaming
  through the download controllers with an absolute path — the current
  `.htaccess` approach is a strong second line of defense but a directory
  outside the docroot is strictest.
- Rotate the default admin password and delete/rotate the seeded faculty
  demo account.
- Set a real `session.cookie_domain` and review `config/constants.php`
  upload limits against your `php.ini` `upload_max_filesize` / `post_max_size`.

---

## 5. Feature Summary

**Public**: Home, About, Contact (validated form), Student Registration,
Student/Faculty/Admin Login, Forgot/Reset Password.

**Student Portal**: Dashboard, Profile (with passport photo), browse/search/
filter Learning Materials (by title, course, category, file type, date),
material detail + secure download (download counter + history),
Announcements (read/unread), Change Password.

**Faculty Portal**: Dashboard (upload/download stats), Profile, Upload
Material (AJAX with progress bar), Manage Materials (edit/replace file/
delete), Announcements (if authorized by admin).

**Admin Portal**: Dashboard (system-wide stats), Students (search, view,
activate/deactivate, reset password, delete), Faculty (add, permissions,
activate/deactivate, reset password, delete), Courses, Categories, Materials
(oversight: change status/delete any material), Announcements
(system-wide, audience targeting), Reports (charts: registrations/uploads
trend, top downloads, students per programme), Settings (site config +
recent audit log).

---

## 6. Faculty, Student & Test Management (Enhancement)

This release adds a full Student/Faculty management layer and a Test
Management System on top of the original portal, reusing the existing
authentication, session, CSRF, and role system rather than creating a
parallel one.

### What's new in the database
Run `database/migration_002_test_management.sql` against an **existing**
installation to add the new tables (fresh installs already get everything
from `database.sql`):
- `faculty_courses` — which faculty teach which courses; a faculty member's
  "my students" list resolves as everyone enrolled in a course they teach.
- `notifications` — lightweight per-user notifications (bell icon in the
  top navbar) for registrations, test publication, submission, etc.
- `tests`, `test_questions`, `test_options`, `test_assignments`,
  `test_attempts`, `test_answers` — the full test engine.

```
mysql -u root -p ros_rccg_portal < database/migration_002_test_management.sql
```

### Faculty Portal additions
- **Students** — now scoped to the faculty's assigned courses only, with
  search/sort/filter and a per-student profile + test-participation view.
- **Courses/Classes** — the courses this faculty member has been assigned to
  by an admin.
- **Tests** — full CRUD: create, edit, add questions (multiple choice,
  true/false, short answer), preview exactly what a student will see,
  publish/unpublish/close, duplicate, delete.
- **Results/Analytics** — per-test dashboard (assigned/started/completed
  counts, average/high/low score, pass rate) plus a per-student answer
  review.

### Admin Portal additions
- **Students** — a new "Assign Programme" action lets admins move a student
  between courses at any time.
- **Courses** — a new "Assign Faculty" action links faculty members to the
  courses they teach (drives what faculty can see everywhere else).
- **Tests** — system-wide oversight of every test regardless of who created
  it: publish/unpublish/close/delete, and full results/analytics.

### Student Portal additions
- **My Courses** — enrolled programme details and which faculty teach it.
- **Available Tests** (tabs: Available / Upcoming / Completed) — a test only
  appears once a faculty/admin publishes it, and only inside its configured
  time window.
- **Test-taking screen** — one question at a time, a question navigator
  showing answered/unanswered state, autosaved answers, and a prominent
  countdown timer.
- **My Results** — score, pass/fail, and (if the test allows it) a full
  answer review after submission.

### How the timer is kept honest
- `test_attempts.expires_at` is computed and stored **once, server-side**,
  the moment a student clicks "Start Test" (`started_at + duration`, capped
  by the test's configured end date). The browser is only ever shown this
  value — it never sets or extends it.
- The on-screen countdown ticks locally for a smooth UI, but resyncs every
  15 seconds against `ajax/test_heartbeat.php`, which returns the *real*
  remaining time computed from the database. Refreshing the page, closing
  the tab, or changing the system clock on the student's device has no
  effect on `expires_at`.
- The moment the server-computed time is up — whether detected by a
  heartbeat, an answer autosave, or the final submit call — the attempt is
  finalized inside a locked transaction (`SELECT ... FOR UPDATE`) so a
  network race between "time ran out" and "student clicked submit" can never
  produce two results or a duplicate submission.
- Every answer is graded and saved server-side as soon as it's submitted
  (multiple choice / true-false against `test_options.is_correct`, short
  answer via a case-insensitive exact match against
  `test_questions.correct_answer_text`). Correct answers and `is_correct`
  flags are **never sent to the browser** while a test is in progress —
  only after the attempt is finalized and the test's
  "show result immediately" setting allows it.

### Notifications
The bell icon in the top navbar (visible once logged in) covers: new
student registration (→ admins), test published (→ assigned students), and
test submitted / auto-submitted on timer expiry (→ the faculty owner).

---

## 6.1 Navigation, Import & Exam Monitoring Update

### Navigation & typography
- The top navbar no longer shows a name/role dropdown. Logged-in users see a
  plain "Welcome, [Name]" link (goes to their dashboard); **Logout now lives
  only in each portal's sidebar** (it was already there — the navbar's
  duplicate Logout option has been removed).
- Headings, stat values, and section titles now follow one consistent, more
  compact type scale (`assets/css/style.css`) instead of oversized Bootstrap
  defaults.

### Import Session (bulk question import)
Faculty can bulk-import questions into a draft test from an Excel file:
`faculty/test-questions.php` → **Import Session** → download the provided
`.xlsx` template, fill it in, upload it.

- Parsing is done by a small dependency-free reader
  (`includes/xlsx_reader.php`) built only on PHP's built-in `ZipArchive` +
  `SimpleXML` — there is no Composer/Packagist access in this environment,
  so no third-party spreadsheet library is used. **Only `.xlsx` is
  supported**; legacy binary `.xls` files are rejected with a message asking
  the user to re-save as `.xlsx`.
- Each row is validated independently (question text, type, marks, options,
  correct answer). Valid rows are imported; invalid rows are skipped and
  listed with the exact reason, so the user can fix just those rows and
  re-upload rather than starting over.
- Import is disabled once a test is published (same rule as manually editing
  questions) to prevent changing a live test's content.

### Question navigator placement
The question-navigator (numbered question buttons) and Previous/Next/Submit
controls now sit **below the question, full width**, instead of in a
right-hand sidebar column. On narrow screens the navigator scrolls
horizontally and the controls stack vertically.

### Exam monitoring (tab-switch detection)
Run `database/migration_003_exam_monitoring.sql` against an **existing**
database (fresh installs already have this):
```
mysql -u root -p ros_rccg_portal < database/migration_003_exam_monitoring.sql
```
This adds a `violation_submitted` attempt status and a `termination_reason`
column to `test_attempts`.

- While a test is in progress, the page listens for the browser's Page
  Visibility API (`visibilitychange` / `document.hidden`). The moment the
  student switches tabs, minimizes the window, or switches apps, the
  in-progress attempt is **immediately auto-submitted** with whatever
  answers were already saved, using `navigator.sendBeacon` so the request is
  reliably delivered even as the tab is being hidden or closed.
- The attempt is stored with `status = 'violation_submitted'` and
  `termination_reason = 'Test automatically submitted because tab
  navigation was detected.'` — visible to the student on their result page
  and flagged with a red "Violation" badge (hover for the reason) on every
  faculty/admin results table and attempt-detail view.
- The event is written to `audit_logs` (`test_violation_auto_submit`) and a
  notification is sent to the test's faculty owner.
- Because the attempt's status is no longer `in_progress`, the existing
  "already attempted" redirect on `student/test-attempt.php` automatically
  blocks the student from reopening or continuing that attempt.
- Detection is deliberately based on Page Visibility rather than `window
  blur`, since blur can fire from benign in-page interactions (opening a
  modal, a native file picker, a `<select>`) and would risk accidental
  submissions; `document.hidden` does not.
- Students see the rule twice: a detailed warning on the "Start Test"
  confirmation screen, and a persistent reminder banner at the top of the
  test-taking screen itself.

---

## 6.2 UI Overhaul, Batches, Timetable & Security Update

### Database changes
Run these against an **existing** installation, in order (fresh installs
already have everything from `database.sql`):
```
mysql -u root -p ros_rccg_portal < database/migration_004_batches_timetable.sql
```
This adds: `batches`, `timetable_entries`, `students.batch_id` /
`students.status` (lifecycle: registered/active/graduated/withdrawn) /
`students.enrollment_date` / `students.graduation_date`,
`materials.batch_id`, `tests.batch_id`, and several new indexes. See
`SCALABILITY.md` for why each index was added.

### Navigation & sidebar
- The navbar no longer shows the user's name at all (previously it showed
  "Welcome, [Name]"; now removed per the latest request).
- Every portal sidebar is now collapsible: a toggle button in the navbar
  collapses the desktop sidebar to an icon-only rail (state persisted in
  `localStorage`) or, on tablet/mobile, opens it as an off-canvas drawer
  with a backdrop. Menu items show a tooltip when collapsed.
- Logout moved into the sidebar (it already lived there from the previous
  update) and is now styled identically to every other sidebar link, with
  a matching hover/active state — no more low-contrast text.

### Modals & alerts
- Every modal in the app now shares one standardized look (header, spacing,
  shadows, close control, mobile scrolling) via `assets/css/style.css` —
  no per-page modal markup changes were needed since Bootstrap's
  `.modal-content` classes were restyled globally.
- The application's one `window.confirm()` call (used by every
  `data-confirm-delete` destructive-action button, ~10 pages) was replaced
  with a proper Promise-based confirmation modal (`App.confirm()` in
  `assets/js/main.js`).
- Flash messages (`flash()` in PHP) now render as auto-dismissing top-right
  toasts instead of a full-width banner under the navbar, so they never
  shift page content. This also fixed a latent bug: `flash('error', ...)`
  messages previously rendered with an invalid CSS class
  (`alert-error` isn't a Bootstrap class) and were unstyled.

### Password fields
- Every `<input type="password">` in the app automatically gets a show/hide
  eye-icon toggle (`initPasswordToggles()` in `main.js`) — this is applied
  globally on page load, so login, registration, change-password,
  forgot/reset-password, and the new admin reset-password modals all behave
  identically for free, with no per-form markup required.
- **Admin password reset** (`admin/students.php`, `admin/faculty.php`): the
  previous "generate a random temporary password" flow was replaced with a
  proper modal where the admin types and confirms a new password
  themselves. The old password is never shown or recoverable; only the
  fact that a reset occurred (by whom, when) is written to `audit_logs` —
  never the password itself.

### Course codes
`admin/courses.php` now auto-generates a course code from the course name
(e.g. "Diploma in Theology" → `DT101`, with collisions bumping the sequence
number) via `generate_course_code()`. The admin can still type their own
code or edit the suggestion before saving; uniqueness is always
re-validated server-side regardless of where the code came from.

### Student batches & lifecycle
- `admin/batches.php`: create/edit batches (cohorts), each optionally tied
  to a programme, with enrollment/training-start/expected-completion dates.
  "Graduate Now" immediately transitions every registered/active student in
  the batch to `graduated` (with today's date) and marks the batch
  `completed`. There is no background scheduler in this environment, so an
  overdue batch (past its expected completion date) is also checked
  opportunistically every time `admin/batches.php` loads
  (`maybe_graduate_batch()`); wire the same function into a daily cron job
  in production instead of relying on that page being visited.
- `admin/students.php` gained batch assignment, a manual lifecycle-status
  change action, and clearly separates **account status** (login
  enabled/disabled) from **lifecycle status** (registered/active/graduated/
  withdrawn) — these are two different `status` columns on two different
  tables (`users.status` vs `students.status`) and are never conflated in
  the UI.
- Student registration now offers an optional batch selection (only
  batches currently open for enrollment are listed); an admin can also
  assign or change it later.

### Access control (graduates & batch isolation)
Enforced **server-side**, not by hiding menu items — see
`student_has_active_access()`, `content_visible_to_batch()`,
`student_can_access_test()`, and `student_can_access_material()` in
`includes/functions.php`:
- A `graduated` or `withdrawn` student is blocked from the materials list,
  a specific material's detail/download, and both the "available" and
  "upcoming" test tabs — enforced at the query level and re-checked on
  every direct-access page (`material-view.php`, `download.php`,
  `test-attempt.php`), not only on the listing page.
- Their **historical** completed test results remain visible indefinitely
  (a separate, unconditional query in `student/tests.php`'s "Completed" tab
  and `test-result.php`), exactly as required — graduating never deletes or
  hides a student's own past record.
- Materials and tests can optionally be pinned to one specific batch
  (`batch_id`); when set, only students in that exact batch can see them,
  while `batch_id = NULL` keeps the previous behaviour (visible to the
  whole course). This was verified with real cross-batch data: a batch-1
  student correctly saw batch-1-only and general content but not
  batch-2-only content.

### Timetable
New `admin/timetable.php`, `faculty/timetable.php` (scoped to the faculty's
own assigned courses/entries), and a read-only `student/timetable.php`
(scoped to the student's own course + batch, with the same active-access
gate as materials/tests). Verified with real data that a batch-1 student's
timetable query correctly excludes a batch-2-only entry while still showing
batch-1 and general entries.

### Scalability
See **`SCALABILITY.md`** for the full, honest write-up: what was actually
tested against a real MariaDB/PHP instance in this environment (schema
migrations, access-control logic, a genuine N+1 query bug found and fixed
across six test-related pages, a genuine `status` column collision bug
found and fixed across three pages), what indexes were added and why, and
— importantly — what a claim of supporting 1,000 concurrent users would
actually require to verify (a real deployment and a real load test with
k6/JMeter), since that cannot be simulated from within this sandbox.

---

## 6.3 Demo Data Seeder

`database/seed_demo_data.php` populates the database with a realistic
spread of ~400 records across every module, for demoing the app or testing
against non-trivial data volumes instead of a handful of rows. Run it from
the project root after importing the schema:

```
php database/seed_demo_data.php
```

It adds, in one all-or-nothing transaction (rolls back cleanly on any
error, including cleaning up any placeholder files already written to
disk):

| Module | Count | Notes |
|---|---|---|
| Courses | +6 | on top of whatever already exists |
| Batches | +5 | mixed `active`/`completed`/`upcoming` statuses |
| Faculty | +10 | each assigned to 1-2 random courses |
| Students | +150 | realistic mix of statuses: ~65% active, ~15% graduated, ~15% registered, ~5% withdrawn; spread across all batches |
| Materials | +40 | each with a **real, valid placeholder PDF** written to `uploads/materials/`, so downloads genuinely work, not just the DB row |
| Tests | +15 | 5 questions each (mcq / true_false / short_answer) = 75 questions + their options; mixed closed/open/upcoming timing |
| Test attempts | ~40-60 | plausible scores/pass-fail for eligible students on closed/open tests |
| Timetable entries | +30 | spread across faculty/courses/batches |
| Announcements | +15 | mixed audience targeting |

All generated student and faculty accounts share the password
**`Demo@12345`** so they're easy to log into for testing. This is seed/demo
data only — never run it against a production database with real users.
The script is safe to run more than once (each run generates its own
uniquely-emailed/numbered batch rather than erroring on duplicates), but
running it repeatedly will keep adding more demo records rather than
replacing the previous batch.

---

## 6.4 Homepage Update: Portal Login Cards & Enrol Now

- **Contact page removed.** `contact.php` and its navbar link are gone;
  `about.php` and everything else are unaffected (nothing else linked to it).
- **Three portal-access cards** (Student / Faculty / Admin), each with a
  two-line description and its own clearly styled login button
  (`student-login.php` / `faculty-login.php` / `admin-login.php`), replacing
  the old bare login links in the hero. Verified with a real headless
  browser that all three buttons link to the right page and are reachable
  on both desktop and mobile.
- **"New Batch Enrolling Now"** section, shown only when at least one batch
  is genuinely open for enrollment — never hard-coded. A batch counts as
  open via `get_open_enrollment_batches()` in `includes/functions.php`
  when: its status is `upcoming` or `active`, its enrollment window has
  started (or has none set), and its training hasn't started yet (or has no
  date set). This same helper now also powers the batch dropdown on
  `student-register.php`, so the homepage promo and the registration form
  can never disagree about which batches are open.
  - Verified with real data: a batch with `training_start_date` already in
    the past is correctly excluded; deleting/closing the only open batch
    makes the whole section disappear (no empty heading left behind);
    a genuinely open batch shows its name, code, programme, and start date
    with a working "Enrol Now" button.
  - Clicking "Enrol Now" links to `student-register.php?batch_id=<id>`,
    which pre-selects that batch (and its associated programme, if any) in
    the registration form and shows a confirmation banner — verified by
    actually clicking through in a real browser and reading the resulting
    page's selected `<option>`, not just by inspecting the code.

---

## 7. Support

This is a self-contained deliverable — there is no external service
dependency beyond your own MySQL server and a standard Apache/PHP stack.
For any customization (branding, additional fields, email integration,
multi-language support), edit the relevant files directly; the codebase is
deliberately kept framework-free and readable for that purpose.
