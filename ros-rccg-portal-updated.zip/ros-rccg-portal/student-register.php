<?php
require_once __DIR__ . '/config/config.php';
$pageTitle = 'Student Registration';

if (is_logged_in()) {
    redirect('/student/dashboard.php');
}

$pdo = getDB();
$courses = $pdo->query("SELECT id, name FROM courses WHERE is_active = 1 ORDER BY name")->fetchAll();
$sessions = $pdo->query("SELECT id, name FROM sessions ORDER BY id DESC")->fetchAll();
$batches = get_open_enrollment_batches($pdo);
$preselectedBatchId = (int) ($_GET['batch_id'] ?? 0);

$errors = [];
$old = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();

    $old = $_POST;
    $fields = [
        'first_name' => 'First name', 'last_name' => 'Last name', 'gender' => 'Gender',
        'date_of_birth' => 'Date of birth', 'email' => 'Email', 'phone' => 'Phone number',
        'address' => 'Address', 'state' => 'State', 'country' => 'Country',
        'course_id' => 'Programme', 'session_id' => 'Academic session',
        'password' => 'Password', 'confirm_password' => 'Confirm password',
    ];

    foreach ($fields as $key => $label) {
        if (clean_str($_POST[$key] ?? '') === '') {
            $errors[] = "$label is required.";
        }
    }

    $email = clean_str($_POST['email'] ?? '');
    if ($email !== '' && !is_valid_email($email)) {
        $errors[] = 'Please provide a valid email address.';
    }

    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    if ($password !== '' && !is_strong_password($password)) {
        $errors[] = 'Password must be at least 8 characters and include letters and numbers.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (empty($_POST['terms'])) {
        $errors[] = 'You must accept the Terms and Conditions to register.';
    }

    // Uniqueness check
    if (!$errors) {
        $chk = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $chk->execute([$email]);
        if ($chk->fetch()) {
            $errors[] = 'An account already exists with this email address.';
        }
    }

    // Passport photo (optional but validated if provided)
    $passportResult = null;
    if (!$errors && !empty($_FILES['passport_photo']['name'])) {
        $passportResult = validate_and_move_upload(
            $_FILES['passport_photo'], UPLOAD_PASSPORTS_PATH, ALLOWED_PASSPORT_TYPES, MAX_PASSPORT_BYTES
        );
        if (!$passportResult['success']) {
            $errors[] = $passportResult['message'];
        }
    }

    if (!$errors) {
        try {
            $pdo->beginTransaction();

            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (role, email, password_hash, status) VALUES ('student', ?, ?, 'active')");
            $stmt->execute([$email, $hash]);
            $userId = (int) $pdo->lastInsertId();

            $regNumber = generate_reg_number($pdo);

            $stmt = $pdo->prepare("INSERT INTO students
                (user_id, reg_number, first_name, middle_name, last_name, gender, date_of_birth, phone, whatsapp,
                 address, state, country, church_parish, rccg_region, rccg_province, rccg_area, rccg_parish,
                 course_id, session_id, batch_id, status, enrollment_date, passport_photo)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'registered',CURDATE(),?)");
            $stmt->execute([
                $userId, $regNumber,
                clean_str($_POST['first_name']), clean_str($_POST['middle_name'] ?? ''), clean_str($_POST['last_name']),
                $_POST['gender'], $_POST['date_of_birth'], clean_str($_POST['phone']), clean_str($_POST['whatsapp'] ?? ''),
                clean_str($_POST['address']), clean_str($_POST['state']), clean_str($_POST['country']),
                clean_str($_POST['church_parish'] ?? ''), clean_str($_POST['rccg_region'] ?? ''),
                clean_str($_POST['rccg_province'] ?? ''), clean_str($_POST['rccg_area'] ?? ''),
                clean_str($_POST['rccg_parish'] ?? ''),
                (int) $_POST['course_id'], (int) $_POST['session_id'],
                !empty($_POST['batch_id']) ? (int) $_POST['batch_id'] : null,
                $passportResult['stored_name'] ?? null,
            ]);

            $pdo->commit();
            audit_log($userId, 'student_registered', "Reg No: $regNumber");
            notify_admins(
                'student_registered',
                'New Student Registration',
                clean_str($_POST['first_name']) . ' ' . clean_str($_POST['last_name']) . " ($regNumber) just registered.",
                '/admin/student-view.php?id=' . $pdo->lastInsertId()
            );
            flash('success', "Registration successful! Your registration number is $regNumber. Please log in.");
            redirect('/student-login.php');
        } catch (Throwable $e) {
            $pdo->rollBack();
            error_log('Registration error: ' . $e->getMessage());
            $errors[] = 'A system error occurred while processing your registration. Please try again.';
        }
    }
}

// Default selections for the form: prefer a failed-submission's own choice
// (re-displaying the form after a validation error) over the ?batch_id=
// preselect from an "Enrol Now" link, and auto-select that batch's
// programme too when nothing else has been chosen yet.
$defaultBatchId = $old['batch_id'] ?? ($preselectedBatchId ?: '');
$defaultCourseId = $old['course_id'] ?? '';
if (!$defaultCourseId && $preselectedBatchId) {
    foreach ($batches as $b) {
        if ((int) $b['id'] === $preselectedBatchId && $b['course_id']) {
            $defaultCourseId = $b['course_id'];
            break;
        }
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="container py-5">
  <div class="feature-card p-4 p-lg-5 mx-auto" style="max-width: 900px;">
    <h1 class="section-title">Student Registration</h1>

    <?php if ($errors): ?>
      <div class="alert alert-danger">
        <strong>Please fix the following:</strong>
        <ul class="mb-0 mt-1"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
      </div>
    <?php elseif ($preselectedBatchId && $defaultBatchId == $preselectedBatchId): ?>
      <?php foreach ($batches as $b): if ((int) $b['id'] === $preselectedBatchId): ?>
        <div class="alert alert-info small">
          <i class="fa-solid fa-circle-info me-1"></i>You're enrolling into <strong><?= e($b['name']) ?></strong> (<?= e($b['batch_code']) ?>)<?= $b['course_name'] ? ' &mdash; ' . e($b['course_name']) : '' ?>. You can change this below if needed.
        </div>
      <?php endif; endforeach; ?>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" novalidate id="registerForm">
      <?= csrf_field() ?>

      <h6 class="text-uppercase text-muted mb-3 mt-2">Personal Information</h6>
      <div class="row g-3">
        <div class="col-md-4">
          <label class="form-label">First Name *</label>
          <input type="text" name="first_name" class="form-control" value="<?= e($old['first_name'] ?? '') ?>" required>
        </div>
        <div class="col-md-4">
          <label class="form-label">Middle Name</label>
          <input type="text" name="middle_name" class="form-control" value="<?= e($old['middle_name'] ?? '') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Last Name *</label>
          <input type="text" name="last_name" class="form-control" value="<?= e($old['last_name'] ?? '') ?>" required>
        </div>
        <div class="col-md-4">
          <label class="form-label">Gender *</label>
          <select name="gender" class="form-select" required>
            <option value="">Select</option>
            <option value="Male" <?= ($old['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
            <option value="Female" <?= ($old['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">Date of Birth *</label>
          <input type="date" name="date_of_birth" class="form-control" value="<?= e($old['date_of_birth'] ?? '') ?>" required>
        </div>
        <div class="col-md-4">
          <label class="form-label">Passport Photograph</label>
          <input type="file" name="passport_photo" class="form-control" accept=".jpg,.jpeg,.png">
        </div>
      </div>

      <h6 class="text-uppercase text-muted mb-3 mt-4">Contact Information</h6>
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Email Address *</label>
          <input type="email" name="email" class="form-control" value="<?= e($old['email'] ?? '') ?>" required>
        </div>
        <div class="col-md-3">
          <label class="form-label">Phone Number *</label>
          <input type="text" name="phone" class="form-control" value="<?= e($old['phone'] ?? '') ?>" required>
        </div>
        <div class="col-md-3">
          <label class="form-label">WhatsApp Number</label>
          <input type="text" name="whatsapp" class="form-control" value="<?= e($old['whatsapp'] ?? '') ?>">
        </div>
        <div class="col-12">
          <label class="form-label">Address *</label>
          <input type="text" name="address" class="form-control" value="<?= e($old['address'] ?? '') ?>" required>
        </div>
        <div class="col-md-6">
          <label class="form-label">State *</label>
          <input type="text" name="state" class="form-control" value="<?= e($old['state'] ?? '') ?>" required>
        </div>
        <div class="col-md-6">
          <label class="form-label">Country *</label>
          <input type="text" name="country" class="form-control" value="<?= e($old['country'] ?? 'Nigeria') ?>" required>
        </div>
      </div>

      <h6 class="text-uppercase text-muted mb-3 mt-4">Church Information</h6>
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Church / Parish</label>
          <input type="text" name="church_parish" class="form-control" value="<?= e($old['church_parish'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">RCCG Region</label>
          <input type="text" name="rccg_region" class="form-control" value="<?= e($old['rccg_region'] ?? '') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">RCCG Province</label>
          <input type="text" name="rccg_province" class="form-control" value="<?= e($old['rccg_province'] ?? '') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">RCCG Area</label>
          <input type="text" name="rccg_area" class="form-control" value="<?= e($old['rccg_area'] ?? '') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">RCCG Parish</label>
          <input type="text" name="rccg_parish" class="form-control" value="<?= e($old['rccg_parish'] ?? '') ?>">
        </div>
      </div>

      <h6 class="text-uppercase text-muted mb-3 mt-4">Academic Information</h6>
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Programme / Course *</label>
          <select name="course_id" class="form-select" required>
            <option value="">Select Programme</option>
            <?php foreach ($courses as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= ($defaultCourseId == $c['id']) ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">Academic/Training Session *</label>
          <select name="session_id" class="form-select" required>
            <option value="">Select Session</option>
            <?php foreach ($sessions as $s): ?>
              <option value="<?= (int)$s['id'] ?>" <?= (($old['session_id'] ?? '') == $s['id']) ? 'selected' : '' ?>><?= e($s['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">Batch / Cohort</label>
          <select name="batch_id" id="batchSelect" class="form-select">
            <option value="">Assign later (administrator will place you in a batch)</option>
            <?php foreach ($batches as $b): ?>
              <option value="<?= (int)$b['id'] ?>" data-course="<?= (int)$b['course_id'] ?>" <?= ($defaultBatchId == $b['id']) ? 'selected' : '' ?>><?= e($b['name']) ?> (<?= e($b['batch_code']) ?>)</option>
            <?php endforeach; ?>
          </select>
          <div class="form-text">Only batches currently open for enrollment are shown.</div>
        </div>
      </div>

      <h6 class="text-uppercase text-muted mb-3 mt-4">Account Security</h6>
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Password *</label>
          <input type="password" name="password" class="form-control" minlength="8" required>
          <div class="form-text">Minimum 8 characters, include letters and numbers.</div>
        </div>
        <div class="col-md-6">
          <label class="form-label">Confirm Password *</label>
          <input type="password" name="confirm_password" class="form-control" minlength="8" required>
        </div>
      </div>

      <div class="form-check mt-4">
        <input class="form-check-input" type="checkbox" name="terms" id="terms" <?= !empty($old['terms']) ? 'checked' : '' ?> required>
        <label class="form-check-label" for="terms">I agree to the Terms and Conditions of ROS RCCG.</label>
      </div>

      <button type="submit" class="btn btn-gold btn-lg mt-4 px-5"><i class="fa-solid fa-user-plus me-2"></i>Create Account</button>
      <p class="mt-3 mb-0">Already registered? <a href="<?= BASE_URL ?>/student-login.php">Login here</a></p>
    </form>
  </div>
</div>

<script>
// Client-side validation mirror (server-side is authoritative)
document.getElementById('registerForm').addEventListener('submit', function (e) {
  const pw = this.password.value, cpw = this.confirm_password.value;
  if (pw !== cpw) {
    e.preventDefault();
    App.toast('Passwords do not match.', 'error');
  }
});
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
