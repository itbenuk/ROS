<?php
require_once __DIR__ . '/config/config.php';
$pageTitle = 'Reset Password';

$token = $_GET['token'] ?? ($_POST['token'] ?? '');
$tokenHash = hash('sha256', $token);
$pdo = getDB();
$error = null;
$success = false;

$stmt = $pdo->prepare("SELECT pr.*, u.email FROM password_resets pr JOIN users u ON u.id = pr.user_id
                        WHERE pr.token_hash = ? AND pr.used = 0 AND pr.expires_at > NOW() LIMIT 1");
$stmt->execute([$tokenHash]);
$reset = $stmt->fetch();

if (!$reset) {
    $error = 'This password reset link is invalid or has expired. Please request a new one.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!is_strong_password($password)) {
        $error = 'Password must be at least 8 characters and include letters and numbers.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([$hash, $reset['user_id']]);
        $pdo->prepare("UPDATE password_resets SET used = 1 WHERE id = ?")->execute([$reset['id']]);
        audit_log($reset['user_id'], 'password_reset_completed');
        $success = true;
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="auth-wrapper">
  <div class="auth-card" style="max-width:520px;">
    <div class="auth-form w-100">
      <h4 class="mb-3"><i class="fa-solid fa-lock text-gold me-2"></i>Set a New Password</h4>
      <?php if ($success): ?>
        <div class="alert alert-success">Your password has been reset successfully.</div>
        <a href="<?= BASE_URL ?>/student-login.php" class="btn btn-gold w-100">Go to Login</a>
      <?php elseif ($error && !$reset): ?>
        <div class="alert alert-danger"><?= e($error) ?></div>
        <a href="<?= BASE_URL ?>/forgot-password.php" class="btn btn-outline-secondary w-100">Request New Link</a>
      <?php else: ?>
        <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
        <form method="post" novalidate>
          <?= csrf_field() ?>
          <input type="hidden" name="token" value="<?= e($token) ?>">
          <div class="mb-3">
            <label class="form-label">New Password</label>
            <input type="password" name="password" class="form-control" minlength="8" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Confirm New Password</label>
            <input type="password" name="confirm_password" class="form-control" minlength="8" required>
          </div>
          <button type="submit" class="btn btn-gold w-100">Reset Password</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
