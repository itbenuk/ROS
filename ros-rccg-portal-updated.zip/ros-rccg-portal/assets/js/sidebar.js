/**
 * Collapsible sidebar behaviour.
 * Desktop (>=992px): toggles a slim icon-only rail, persisted in localStorage.
 * Mobile/tablet (<992px): toggles an off-canvas drawer with a backdrop.
 */
(function () {
  const BREAKPOINT = 992;
  const STORAGE_KEY = 'sidebarCollapsed';

  function isDesktop() {
    return window.innerWidth >= BREAKPOINT;
  }

  function getSidebar() {
    return document.getElementById('appSidebar');
  }

  function ensureBackdrop() {
    let backdrop = document.getElementById('sidebarBackdrop');
    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'sidebarBackdrop';
      backdrop.className = 'sidebar-backdrop';
      document.body.appendChild(backdrop);
      backdrop.addEventListener('click', closeMobileSidebar);
    }
    return backdrop;
  }

  function openMobileSidebar() {
    const sidebar = getSidebar();
    if (!sidebar) return;
    sidebar.classList.add('sidebar-open');
    ensureBackdrop().classList.add('show');
    document.body.classList.add('sidebar-lock-scroll');
  }

  function closeMobileSidebar() {
    const sidebar = getSidebar();
    if (!sidebar) return;
    sidebar.classList.remove('sidebar-open');
    const backdrop = document.getElementById('sidebarBackdrop');
    if (backdrop) backdrop.classList.remove('show');
    document.body.classList.remove('sidebar-lock-scroll');
  }

  function toggleDesktopCollapse() {
    const wrapper = document.querySelector('.dash-wrapper');
    const sidebar = getSidebar();
    if (!wrapper || !sidebar) return;
    const collapsed = wrapper.classList.toggle('sidebar-collapsed');
    localStorage.setItem(STORAGE_KEY, collapsed ? '1' : '0');
    refreshTooltips();
  }

  function refreshTooltips() {
    if (typeof bootstrap === 'undefined' || !bootstrap.Tooltip) return;
    document.querySelectorAll('#appSidebar [data-bs-toggle="tooltip"]').forEach((el) => {
      const existing = bootstrap.Tooltip.getInstance(el);
      if (existing) existing.dispose();
      new bootstrap.Tooltip(el, { placement: 'right', trigger: 'hover' });
    });
  }

  function restoreDesktopState() {
    const wrapper = document.querySelector('.dash-wrapper');
    if (!wrapper) return;
    if (isDesktop() && localStorage.getItem(STORAGE_KEY) === '1') {
      wrapper.classList.add('sidebar-collapsed');
    }
  }

  function init() {
    const toggleBtn = document.getElementById('sidebarToggleBtn');
    const sidebar = getSidebar();
    if (!sidebar) return; // no sidebar on this page (public pages)

    restoreDesktopState();
    refreshTooltips();

    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => {
        if (isDesktop()) {
          toggleDesktopCollapse();
        } else {
          sidebar.classList.contains('sidebar-open') ? closeMobileSidebar() : openMobileSidebar();
        }
      });
    }

    // Close the mobile drawer after choosing a menu item, for a native feel.
    sidebar.querySelectorAll('a.nav-link, button.nav-link').forEach((link) => {
      link.addEventListener('click', () => { if (!isDesktop()) closeMobileSidebar(); });
    });

    window.addEventListener('resize', () => {
      if (isDesktop()) {
        closeMobileSidebar();
      } else {
        document.querySelector('.dash-wrapper')?.classList.remove('sidebar-collapsed');
      }
    });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
