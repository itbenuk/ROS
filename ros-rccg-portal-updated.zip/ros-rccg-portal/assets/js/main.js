/**
 * Shared front-end behaviour: toast notifications, fetch helper,
 * live search/filter, confirmation modal, AJAX upload progress,
 * flash-message toasts, and the reusable password show/hide control.
 */

const App = (() => {
  function toast(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container position-fixed top-0 end-0 p-3';
      container.style.zIndex = '1090';
      container.style.marginTop = '70px'; // clear the sticky navbar
      document.body.appendChild(container);
    }
    const id = 't' + Date.now() + Math.floor(Math.random() * 1000);
    const bg = { success: 'success', error: 'danger', warning: 'warning', info: 'primary' }[type] || 'success';
    const icon = { success: 'circle-check', error: 'circle-exclamation', warning: 'triangle-exclamation', info: 'circle-info' }[type] || 'circle-check';
    container.insertAdjacentHTML('beforeend', `
      <div id="${id}" class="toast align-items-center text-bg-${bg} border-0 shadow app-toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
          <div class="toast-body"><i class="fa-solid fa-${icon} me-2"></i>${message}</div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
      </div>`);
    const el = document.getElementById(id);
    const t = new bootstrap.Toast(el, { delay: 5000 });
    t.show();
    el.addEventListener('hidden.bs.toast', () => el.remove());
  }

  async function postJSON(url, formData) {
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content ||
      document.querySelector('input[name="csrf_token"]')?.value || '';
    if (formData instanceof FormData) {
      if (!formData.has('csrf_token')) formData.append('csrf_token', csrf);
    }
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      body: formData,
    });
    let data;
    try { data = await res.json(); } catch (e) { data = { success: false, message: 'Unexpected server response.' }; }
    return data;
  }

  // ---------------------------------------------------------------
  // Promise-based confirmation modal - replaces window.confirm()
  // ---------------------------------------------------------------
  function ensureConfirmModal() {
    let modalEl = document.getElementById('appConfirmModal');
    if (modalEl) return modalEl;
    document.body.insertAdjacentHTML('beforeend', `
      <div class="modal fade" id="appConfirmModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="appConfirmTitle"><i class="fa-solid fa-triangle-exclamation text-warning me-2"></i>Please Confirm</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p id="appConfirmMessage" class="mb-0"></p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-outline-secondary" id="appConfirmCancel" data-bs-dismiss="modal">Cancel</button>
              <button type="button" class="btn btn-danger" id="appConfirmOk">Confirm</button>
            </div>
          </div>
        </div>
      </div>`);
    return document.getElementById('appConfirmModal');
  }

  function confirmModal(message, options = {}) {
    return new Promise((resolve) => {
      const modalEl = ensureConfirmModal();
      const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
      modalEl.querySelector('#appConfirmMessage').textContent = message || 'Are you sure you want to proceed?';
      modalEl.querySelector('#appConfirmTitle').innerHTML =
        `<i class="fa-solid fa-triangle-exclamation text-warning me-2"></i>${options.title || 'Please Confirm'}`;
      const okBtn = modalEl.querySelector('#appConfirmOk');
      okBtn.textContent = options.confirmText || 'Confirm';
      okBtn.className = 'btn ' + (options.danger === false ? 'btn-gold' : 'btn-danger');

      let decided = false;
      const onOk = () => { decided = true; modal.hide(); resolve(true); };
      const onHidden = () => { if (!decided) resolve(false); cleanup(); };
      function cleanup() {
        okBtn.removeEventListener('click', onOk);
        modalEl.removeEventListener('hidden.bs.modal', onHidden);
      }
      okBtn.addEventListener('click', onOk);
      modalEl.addEventListener('hidden.bs.modal', onHidden);
      modal.show();
    });
  }

  // Kept for any legacy callers; now backed by the modal (synchronous window.confirm removed).
  function confirmAction(message) {
    return confirmModal(message);
  }

  // Live search/filter for any table with data-search-target rows
  function initLiveFilter() {
    const input = document.getElementById('liveSearch');
    if (!input) return;
    input.addEventListener('input', () => {
      const q = input.value.toLowerCase();
      document.querySelectorAll('[data-search-row]').forEach((row) => {
        row.style.display = row.dataset.searchText.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  }

  // Delete/destructive confirmation buttons: <form data-confirm-delete="Delete this item?">
  function initDeleteConfirms() {
    document.querySelectorAll('form[data-confirm-delete]').forEach((form) => {
      if (form.dataset.confirmBound) return;
      form.dataset.confirmBound = '1';
      form.addEventListener('submit', (e) => {
        if (form.dataset.confirmed === '1') return; // already confirmed, let it submit
        e.preventDefault();
        confirmModal(form.dataset.confirmDelete, { confirmText: 'Delete', danger: true }).then((ok) => {
          if (ok) {
            form.dataset.confirmed = '1';
            form.submit();
          }
        });
      });
    });
  }

  // AJAX upload with progress bar: form[data-ajax-upload]
  function initAjaxUpload() {
    document.querySelectorAll('form[data-ajax-upload]').forEach((form) => {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const progressWrap = form.querySelector('.upload-progress');
        const progressBar = form.querySelector('.progress-bar');
        const submitBtn = form.querySelector('button[type="submit"]');
        const xhr = new XMLHttpRequest();
        xhr.open('POST', form.action, true);
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        if (progressWrap) progressWrap.classList.remove('d-none');
        if (submitBtn) submitBtn.disabled = true;

        xhr.upload.onprogress = (evt) => {
          if (evt.lengthComputable && progressBar) {
            const pct = Math.round((evt.loaded / evt.total) * 100);
            progressBar.style.width = pct + '%';
            progressBar.textContent = pct + '%';
          }
        };

        xhr.onload = () => {
          if (submitBtn) submitBtn.disabled = false;
          let data;
          try { data = JSON.parse(xhr.responseText); } catch (err) { data = { success: false, message: 'Server error.' }; }
          toast(data.message || (data.success ? 'Success' : 'Something went wrong'), data.success ? 'success' : 'error');
          if (data.success) {
            setTimeout(() => { window.location.href = data.redirect || window.location.href; }, 900);
          }
        };
        xhr.onerror = () => {
          if (submitBtn) submitBtn.disabled = false;
          toast('Network error. Please try again.', 'error');
        };
        xhr.send(new FormData(form));
      });
    });
  }

  // Render server-side flash messages (set via PHP flash()) as toasts instead
  // of a full-width banner under the navbar, so they never shift page layout.
  function initFlashToasts() {
    const el = document.getElementById('flash-data');
    if (!el) return;
    let flashes = [];
    try { flashes = JSON.parse(el.textContent || '[]'); } catch (e) { return; }
    flashes.forEach((f, i) => setTimeout(() => toast(f.message, f.type), i * 250));
  }

  // ---------------------------------------------------------------
  // Reusable password show/hide toggle.
  // Applies to any <input type="password"> that isn't already wrapped,
  // so every password field in the app gets identical behaviour for free.
  // ---------------------------------------------------------------
  function initPasswordToggles() {
    document.querySelectorAll('input[type="password"]').forEach((input) => {
      if (input.dataset.toggleBound) return;
      input.dataset.toggleBound = '1';

      if (!input.parentElement.classList.contains('password-field-wrap')) {
        const wrap = document.createElement('div');
        wrap.className = 'password-field-wrap position-relative';
        input.parentNode.insertBefore(wrap, input);
        wrap.appendChild(input);
      }
      input.classList.add('pe-5');

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'password-toggle-btn';
      btn.setAttribute('aria-label', 'Show password');
      btn.setAttribute('title', 'Show password');
      btn.tabIndex = 0;
      btn.innerHTML = '<i class="fa-solid fa-eye"></i>';

      btn.addEventListener('click', () => {
        const showing = input.type === 'text';
        input.type = showing ? 'password' : 'text';
        btn.innerHTML = showing ? '<i class="fa-solid fa-eye"></i>' : '<i class="fa-solid fa-eye-slash"></i>';
        const label = showing ? 'Show password' : 'Hide password';
        btn.setAttribute('aria-label', label);
        btn.setAttribute('title', label);
      });

      input.insertAdjacentElement('afterend', btn);
    });
  }

  function init() {
    initLiveFilter();
    initDeleteConfirms();
    initAjaxUpload();
    initFlashToasts();
    initPasswordToggles();
  }

  return { toast, postJSON, confirmAction, confirm: confirmModal, init, initPasswordToggles, initDeleteConfirms };
})();

document.addEventListener('DOMContentLoaded', App.init);
