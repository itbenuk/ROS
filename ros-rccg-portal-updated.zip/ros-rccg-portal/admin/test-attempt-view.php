<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Attempt Details';

$pdo = getDB();
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT ta.*, t.title, t.passing_score, s.first_name, s.last_name, s.reg_number
                        FROM test_attempts ta
                        JOIN tests t ON t.id = ta.test_id
                        JOIN students s ON s.id = ta.student_id
                        WHERE ta.id = ?");
$stmt->execute([$id]);
$attempt = $stmt->fetch();

if (!$attempt) {
    flash('error', 'Attempt not found.');
    redirect('/admin/tests.php');
}

$questions = $pdo->prepare("SELECT q.*, a.selected_option_id, a.answer_text, a.is_correct, a.marks_awarded
                             FROM test_questions q
                             LEFT JOIN test_answers a ON a.question_id = q.id AND a.attempt_id = ?
                             WHERE q.test_id = (SELECT test_id FROM test_attempts WHERE id = ?)
                             ORDER BY q.order_index");
$questions->execute([$id, $id]);
$questions = $questions->fetchAll();
$questions = load_options_for_questions($pdo, $questions);

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <a href="<?= BASE_URL ?>/admin/test-results.php?id=<?= (int)$attempt['test_id'] ?>" class="small mb-2 d-inline-block"><i class="fa-solid fa-arrow-left me-1"></i>Back to Results</a>

    <?php if ($attempt['status'] === 'violation_submitted'): ?>
      <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i><?= e($attempt['termination_reason']) ?></div>
    <?php endif; ?>

    <div class="card p-4 mb-4">
      <div class="row">
        <div class="col-md-8">
          <h4 class="mb-1"><?= e($attempt['title']) ?></h4>
          <p class="text-muted mb-0"><?= e($attempt['first_name'].' '.$attempt['last_name']) ?> &middot; <?= e($attempt['reg_number']) ?></p>
        </div>
        <div class="col-md-4 text-md-end">
          <div class="fs-4 fw-bold"><?= e($attempt['score']) ?> / <?= e($attempt['total_marks']) ?> (<?= e($attempt['percentage']) ?>%)</div>
          <span class="badge badge-<?= $attempt['passed'] ? 'active' : 'suspended' ?> px-3 py-2">
            <?= $attempt['passed'] ? 'Passed' : 'Failed' ?> &middot; Pass mark <?= e($attempt['passing_score']) ?>%
          </span>
        </div>
      </div>
    </div>

    <?php foreach ($questions as $i => $q): ?>
      <div class="card p-4 mb-3">
        <div class="d-flex justify-content-between mb-2">
          <span class="fw-semibold">Question <?= $i + 1 ?></span>
          <span class="badge <?= $q['is_correct'] ? 'text-bg-success' : 'text-bg-danger' ?>"><?= $q['marks_awarded'] ?? 0 ?> / <?= $q['marks'] ?> marks</span>
        </div>
        <p><?= nl2br(e($q['question_text'])) ?></p>
        <?php if ($q['question_type'] === 'short_answer'): ?>
          <p class="mb-1"><strong>Student's answer:</strong> <?= e($q['answer_text'] ?: '(no answer)') ?></p>
          <p class="small text-muted mb-0"><strong>Correct answer:</strong> <?= e($q['correct_answer_text']) ?></p>
        <?php else: ?>
          <?php foreach ($q['options'] as $o):
            $isSelected = (int)$q['selected_option_id'] === (int)$o['id'];
            $class = $o['is_correct'] ? 'text-success fw-semibold' : ($isSelected ? 'text-danger fw-semibold' : '');
          ?>
            <div class="form-check mb-1">
              <input class="form-check-input" type="radio" disabled <?= $isSelected ? 'checked' : '' ?>>
              <label class="form-check-label <?= $class ?>">
                <?= e($o['option_text']) ?>
                <?php if ($o['is_correct']): ?><i class="fa-solid fa-circle-check ms-1 text-success"></i><?php elseif ($isSelected): ?><i class="fa-solid fa-circle-xmark ms-1 text-danger"></i><?php endif; ?>
              </label>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
