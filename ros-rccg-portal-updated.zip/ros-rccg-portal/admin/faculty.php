<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Manage Faculty';

$pdo = getDB();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $email = clean_str($_POST['email'] ?? '');
        $firstName = clean_str($_POST['first_name'] ?? '');
        $lastName = clean_str($_POST['last_name'] ?? '');
        $phone = clean_str($_POST['phone'] ?? '');
        $department = clean_str($_POST['department'] ?? '');
        $title = clean_str($_POST['title'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!is_valid_email($email)) $errors[] = 'A valid email is required.';
        if ($firstName === '' || $lastName === '') $errors[] = 'First and last name are required.';
        if (!is_strong_password($password)) $errors[] = 'Password must be at least 8 characters with letters and numbers.';

        if (!$errors) {
            $chk = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $chk->execute([$email]);
            if ($chk->fetch()) {
                $errors[] = 'An account with this email already exists.';
            }
        }

        if (!$errors) {
            $pdo->beginTransaction();
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $pdo->prepare("INSERT INTO users (role, email, password_hash, status) VALUES ('faculty', ?, ?, 'active')")
                ->execute([$email, $hash]);
            $userId = (int) $pdo->lastInsertId();
            $staffId = generate_staff_id($pdo);
            $pdo->prepare("INSERT INTO faculty (user_id, staff_id, first_name, last_name, phone, department, title)
                            VALUES (?,?,?,?,?,?,?)")
                ->execute([$userId, $staffId, $firstName, $lastName, $phone, $department, $title]);
            $pdo->commit();
            audit_log($_SESSION['user_id'], 'faculty_created', "Staff: $staffId ($email)");
            flash('success', "Faculty member added successfully. Staff ID: $staffId");
            redirect('/admin/faculty.php');
        }
    } elseif ($action === 'toggle_status') {
        $userId = (int) $_POST['user_id'];
        $newStatus = $_POST['new_status'] === 'active' ? 'active' : 'inactive';
        $pdo->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'faculty'")->execute([$newStatus, $userId]);
        audit_log($_SESSION['user_id'], 'faculty_status_changed', "User $userId => $newStatus");
        flash('success', 'Faculty status updated.');
        redirect('/admin/faculty.php');
    } elseif ($action === 'toggle_permission') {
        $facultyId = (int) $_POST['faculty_id'];
        $field = $_POST['field'] === 'can_view_students' ? 'can_view_students' : 'can_post_announcements';
        $pdo->prepare("UPDATE faculty SET $field = NOT $field WHERE id = ?")->execute([$facultyId]);
        flash('success', 'Permission updated.');
        redirect('/admin/faculty.php');
    } elseif ($action === 'toggle_leadership') {
        $facultyId = (int) $_POST['faculty_id'];
        $pdo->prepare("UPDATE faculty SET show_on_leadership = NOT show_on_leadership WHERE id = ?")->execute([$facultyId]);
        audit_log($_SESSION['user_id'], 'faculty_leadership_visibility_toggled', "Faculty $facultyId");
        flash('success', 'Faculty Members visibility updated.');
        redirect('/admin/faculty.php');
    } elseif ($action === 'update_bio') {
        $facultyId = (int) $_POST['faculty_id'];
        $bio = clean_str($_POST['bio'] ?? '');
        $pdo->prepare("UPDATE faculty SET bio = ? WHERE id = ?")->execute([$bio, $facultyId]);
        flash('success', 'Biography updated.');
        redirect('/admin/faculty.php');
    } elseif ($action === 'reset_password') {
        $userId = (int) $_POST['user_id'];
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (!is_strong_password($newPassword)) {
            flash('error', 'Password must be at least 8 characters and include letters and numbers.');
        } elseif ($newPassword !== $confirmPassword) {
            flash('error', 'The passwords do not match.');
        } else {
            $hash = password_hash($newPassword, PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ? AND role = 'faculty'")->execute([$hash, $userId]);
            audit_log($_SESSION['user_id'], 'faculty_password_reset', "Admin reset password for user #$userId");
            flash('success', 'Password reset successfully.');
        }
        redirect('/admin/faculty.php');
    } elseif ($action === 'delete') {
        $userId = (int) $_POST['user_id'];
        $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'faculty'")->execute([$userId]);
        audit_log($_SESSION['user_id'], 'faculty_deleted', "User $userId");
        flash('success', 'Faculty record deleted.');
        redirect('/admin/faculty.php');
    }
}

$search = clean_str($_GET['q'] ?? '');
$where = "1=1";
$params = [];
if ($search !== '') {
    $where = "(f.first_name LIKE ? OR f.last_name LIKE ? OR f.staff_id LIKE ? OR u.email LIKE ?)";
    $params = ["%$search%", "%$search%", "%$search%", "%$search%"];
}

$stmt = $pdo->prepare("SELECT f.*, u.email, u.status, u.id AS user_id
                        FROM faculty f JOIN users u ON u.id = f.user_id
                        WHERE $where ORDER BY f.created_at DESC");
$stmt->execute($params);
$facultyList = $stmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
      <h3 class="section-title mb-0">Manage Faculty</h3>
      <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#addFacultyModal"><i class="fa-solid fa-plus me-2"></i>Add Faculty</button>
    </div>
    <p class="text-muted small mb-3">Active faculty appear automatically under <a href="<?= BASE_URL ?>/leadership.php#faculty-members" target="_blank">"Faculty Members"</a> on the public Leadership page, using the photo and bio each faculty member sets on their own profile (or that you set here via the <i class="fa-solid fa-pen-to-square"></i> button). Use the <strong>Faculty Members</strong> toggle below to hide any individual staff member from that public section without changing their account status.</p>

    <?php if ($errors): ?>
      <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>

    <div class="card p-3 mb-3">
      <form class="row g-2" method="get">
        <div class="col-md-8"><input type="text" name="q" class="form-control" placeholder="Search by name, staff ID or email..." value="<?= e($search) ?>"></div>
        <div class="col-md-2"><button class="btn btn-outline-secondary w-100" type="submit">Search</button></div>
      </form>
    </div>

    <div class="card p-4">
      <?php if (!$facultyList): ?>
        <div class="empty-state"><i class="fa-solid fa-chalkboard-user"></i><p>No faculty members found.</p></div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Staff ID</th><th>Name</th><th>Email</th><th>Department</th><th>Status</th><th>Permissions</th><th class="text-end">Actions</th></tr></thead>
          <tbody>
          <?php foreach ($facultyList as $f): ?>
            <tr>
              <td><?= e($f['staff_id']) ?></td>
              <td><?= e($f['title'].' '.$f['first_name'].' '.$f['last_name']) ?></td>
              <td><?= e($f['email']) ?></td>
              <td><?= e($f['department'] ?: '-') ?></td>
              <td><span class="badge badge-<?= $f['status']==='active'?'active':'inactive' ?> px-2 py-1"><?= e(ucfirst($f['status'])) ?></span></td>
              <td class="small">
                <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_permission"><input type="hidden" name="faculty_id" value="<?= (int)$f['id'] ?>"><input type="hidden" name="field" value="can_post_announcements">
                  <button class="btn btn-sm <?= $f['can_post_announcements'] ? 'btn-outline-success' : 'btn-outline-secondary' ?>" title="Toggle announcement rights">Announce</button>
                </form>
                <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_permission"><input type="hidden" name="faculty_id" value="<?= (int)$f['id'] ?>"><input type="hidden" name="field" value="can_view_students">
                  <button class="btn btn-sm <?= $f['can_view_students'] ? 'btn-outline-success' : 'btn-outline-secondary' ?>" title="Toggle student visibility">View Students</button>
                </form>
                <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_leadership"><input type="hidden" name="faculty_id" value="<?= (int)$f['id'] ?>">
                  <button class="btn btn-sm <?= $f['show_on_leadership'] ? 'btn-outline-success' : 'btn-outline-secondary' ?>" title="Toggle visibility on the public Faculty Members section"><i class="fa-solid fa-<?= $f['show_on_leadership'] ? 'eye' : 'eye-slash' ?> me-1"></i>Faculty Members</button>
                </form>
              </td>
              <td class="text-end">
                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editBio<?= (int)$f['id'] ?>" title="Edit Biography (shown on Faculty Members)"><i class="fa-solid fa-pen-to-square"></i></button>
                <form method="post" class="d-inline">
                  <?= csrf_field() ?><input type="hidden" name="action" value="toggle_status"><input type="hidden" name="user_id" value="<?= (int)$f['user_id'] ?>">
                  <input type="hidden" name="new_status" value="<?= $f['status']==='active'?'inactive':'active' ?>">
                  <button type="submit" class="btn btn-sm btn-outline-<?= $f['status']==='active'?'warning':'success' ?>" title="Toggle Status"><i class="fa-solid fa-<?= $f['status']==='active'?'ban':'check' ?>"></i></button>
                </form>
                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#resetPw<?= (int)$f['id'] ?>" title="Reset Password"><i class="fa-solid fa-key"></i></button>
                <form method="post" class="d-inline" data-confirm-delete="Permanently delete this faculty record and all their materials?">
                  <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="user_id" value="<?= (int)$f['user_id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="fa-solid fa-trash"></i></button>
                </form>
              </td>
            </tr>

            <!-- Edit Bio Modal -->
            <div class="modal fade" id="editBio<?= (int)$f['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update_bio">
                    <input type="hidden" name="faculty_id" value="<?= (int)$f['id'] ?>">
                    <div class="modal-header"><h5 class="modal-title">Biography &mdash; <?= e($f['first_name'].' '.$f['last_name']) ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body">
                      <label class="form-label">Short Biography</label>
                      <textarea name="bio" class="form-control" rows="5" placeholder="Shown on the public Leadership page..."><?= e($f['bio']) ?></textarea>
                      <div class="form-text">This appears under "Faculty Members" on the public Leadership page. The faculty member can also edit this from their own profile.</div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Save</button></div>
                  </form>
                </div>
              </div>
            </div>

            <!-- Reset Password Modal -->
            <div class="modal fade" id="resetPw<?= (int)$f['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" name="user_id" value="<?= (int)$f['user_id'] ?>">
                    <div class="modal-header"><h5 class="modal-title">Reset Password &mdash; <?= e($f['first_name'].' '.$f['last_name']) ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body">
                      <div class="mb-3">
                        <label class="form-label">New Password</label>
                        <input type="password" name="new_password" class="form-control" minlength="8" required>
                        <div class="form-text">Minimum 8 characters, including letters and numbers.</div>
                      </div>
                      <div class="mb-2">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" name="confirm_password" class="form-control" minlength="8" required>
                      </div>
                      <p class="small text-muted mb-0"><i class="fa-solid fa-shield-halved me-1"></i>The current password is never shown and cannot be recovered - only replaced.</p>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Reset Password</button></div>
                  </form>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Add Faculty Modal -->
<div class="modal fade" id="addFacultyModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <div class="modal-header">
          <h5 class="modal-title">Add Faculty Member</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-4"><label class="form-label">Title</label><input type="text" name="title" class="form-control" placeholder="Rev., Dr."></div>
            <div class="col-md-4"><label class="form-label">First Name *</label><input type="text" name="first_name" class="form-control" required></div>
            <div class="col-md-4"><label class="form-label">Last Name *</label><input type="text" name="last_name" class="form-control" required></div>
            <div class="col-md-6"><label class="form-label">Email *</label><input type="email" name="email" class="form-control" required></div>
            <div class="col-md-6"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">Department</label><input type="text" name="department" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">Temporary Password *</label><input type="password" name="password" class="form-control" minlength="8" required></div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-gold">Add Faculty</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
