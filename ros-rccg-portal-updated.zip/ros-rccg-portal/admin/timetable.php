<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Timetable';

$pdo = getDB();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $topic = clean_str($_POST['topic'] ?? '');
        $facultyId = (int) ($_POST['faculty_id'] ?? 0);
        $courseId = !empty($_POST['course_id']) ? (int) $_POST['course_id'] : null;
        $batchId = !empty($_POST['batch_id']) ? (int) $_POST['batch_id'] : null;
        $entryDate = $_POST['entry_date'] ?? '';
        $startTime = $_POST['start_time'] ?? '';
        $endTime = $_POST['end_time'] ?? '';
        $id = (int) ($_POST['id'] ?? 0);

        if ($topic === '') $errors[] = 'Lecture topic is required.';
        if (!$facultyId) $errors[] = 'Please select a lecturer.';
        if (!$entryDate) $errors[] = 'Date is required.';
        if (!$startTime || !$endTime) {
            $errors[] = 'Start and end time are required.';
        } elseif ($endTime <= $startTime) {
            $errors[] = 'End time must be after the start time.';
        }

        if (!$errors) {
            if ($action === 'add') {
                $pdo->prepare("INSERT INTO timetable_entries (topic, faculty_id, course_id, batch_id, entry_date, start_time, end_time, created_by)
                                VALUES (?,?,?,?,?,?,?,?)")
                    ->execute([$topic, $facultyId, $courseId, $batchId, $entryDate, $startTime, $endTime, $_SESSION['user_id']]);
                audit_log($_SESSION['user_id'], 'timetable_entry_created', $topic);
                flash('success', 'Timetable entry added.');
            } else {
                $pdo->prepare("UPDATE timetable_entries SET topic=?, faculty_id=?, course_id=?, batch_id=?, entry_date=?, start_time=?, end_time=? WHERE id=?")
                    ->execute([$topic, $facultyId, $courseId, $batchId, $entryDate, $startTime, $endTime, $id]);
                audit_log($_SESSION['user_id'], 'timetable_entry_updated', "Entry #$id");
                flash('success', 'Timetable entry updated.');
            }
            redirect('/admin/timetable.php');
        }
    } elseif ($action === 'delete') {
        $id = (int) $_POST['id'];
        $pdo->prepare("DELETE FROM timetable_entries WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'timetable_entry_deleted', "Entry #$id");
        flash('success', 'Timetable entry cancelled.');
        redirect('/admin/timetable.php');
    }
}

$courseFilter = (int) ($_GET['course_id'] ?? 0);
$batchFilter = (int) ($_GET['batch_id'] ?? 0);
$where = ["1=1"];
$params = [];
if ($courseFilter) { $where[] = "t.course_id = ?"; $params[] = $courseFilter; }
if ($batchFilter) { $where[] = "t.batch_id = ?"; $params[] = $batchFilter; }
$whereSql = implode(' AND ', $where);

$entries = $pdo->prepare("SELECT t.*, f.first_name, f.last_name, c.name AS course_name, b.name AS batch_name
                           FROM timetable_entries t
                           JOIN faculty f ON f.id = t.faculty_id
                           LEFT JOIN courses c ON c.id = t.course_id
                           LEFT JOIN batches b ON b.id = t.batch_id
                           WHERE $whereSql
                           ORDER BY t.entry_date DESC, t.start_time DESC");
$entries->execute($params);
$entries = $entries->fetchAll();

$facultyList = $pdo->query("SELECT id, first_name, last_name FROM faculty ORDER BY first_name")->fetchAll();
$courses = $pdo->query("SELECT id, name FROM courses ORDER BY name")->fetchAll();
$batches = $pdo->query("SELECT id, name FROM batches ORDER BY name")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
      <h3 class="section-title mb-0">Timetable</h3>
      <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#addEntryModal" onclick="resetEntryForm()"><i class="fa-solid fa-plus me-2"></i>Add Entry</button>
    </div>

    <?php if ($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

    <div class="card p-3 mb-3">
      <form class="row g-2" method="get">
        <div class="col-md-4">
          <select name="course_id" class="form-select">
            <option value="">All Programmes</option>
            <?php foreach ($courses as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $courseFilter==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-4">
          <select name="batch_id" class="form-select">
            <option value="">All Batches</option>
            <?php foreach ($batches as $b): ?><option value="<?= (int)$b['id'] ?>" <?= $batchFilter==$b['id']?'selected':'' ?>><?= e($b['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-4"><button class="btn btn-outline-secondary w-100" type="submit">Filter</button></div>
      </form>
    </div>

    <div class="card p-4">
      <?php if (!$entries): ?>
        <div class="empty-state"><i class="fa-solid fa-calendar-days"></i><p>No timetable entries yet.</p></div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Date</th><th>Time</th><th>Topic</th><th>Lecturer</th><th>Programme / Batch</th><th class="text-end">Actions</th></tr></thead>
          <tbody>
          <?php foreach ($entries as $t): ?>
            <tr>
              <td><?= date('M j, Y', strtotime($t['entry_date'])) ?></td>
              <td><?= date('g:ia', strtotime($t['start_time'])) ?> &ndash; <?= date('g:ia', strtotime($t['end_time'])) ?></td>
              <td><?= e($t['topic']) ?></td>
              <td><?= e($t['first_name'].' '.$t['last_name']) ?></td>
              <td class="small"><?= e($t['course_name'] ?? 'All Programmes') ?><?= $t['batch_name'] ? ' &middot; '.e($t['batch_name']) : '' ?></td>
              <td class="text-end">
                <button class="btn btn-sm btn-outline-secondary" onclick='editEntry(<?= json_encode($t, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'><i class="fa-solid fa-pen"></i></button>
                <form method="post" class="d-inline" data-confirm-delete="Cancel this timetable entry?">
                  <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="modal fade" id="addEntryModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post" id="entryForm">
        <?= csrf_field() ?>
        <input type="hidden" name="action" id="entryAction" value="add">
        <input type="hidden" name="id" id="entryId" value="">
        <div class="modal-header"><h5 class="modal-title" id="entryModalTitle">Add Timetable Entry</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <div class="mb-3"><label class="form-label">Lecture Topic *</label><input type="text" name="topic" id="entryTopic" class="form-control" required></div>
          <div class="mb-3">
            <label class="form-label">Lecturer *</label>
            <select name="faculty_id" id="entryFaculty" class="form-select" required>
              <option value="">Select Lecturer</option>
              <?php foreach ($facultyList as $f): ?><option value="<?= (int)$f['id'] ?>"><?= e($f['first_name'].' '.$f['last_name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="row g-2">
            <div class="col-md-6">
              <label class="form-label">Programme</label>
              <select name="course_id" id="entryCourse" class="form-select">
                <option value="">All Programmes</option>
                <?php foreach ($courses as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Batch</label>
              <select name="batch_id" id="entryBatch" class="form-select">
                <option value="">All Batches</option>
                <?php foreach ($batches as $b): ?><option value="<?= (int)$b['id'] ?>"><?= e($b['name']) ?></option><?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="row g-2 mt-1">
            <div class="col-md-4"><label class="form-label">Date *</label><input type="date" name="entry_date" id="entryDate" class="form-control" required></div>
            <div class="col-md-4"><label class="form-label">Start Time *</label><input type="time" name="start_time" id="entryStart" class="form-control" required></div>
            <div class="col-md-4"><label class="form-label">End Time *</label><input type="time" name="end_time" id="entryEnd" class="form-control" required></div>
          </div>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Save Entry</button></div>
      </form>
    </div>
  </div>
</div>

<script>
function resetEntryForm() {
  document.getElementById('entryModalTitle').textContent = 'Add Timetable Entry';
  document.getElementById('entryAction').value = 'add';
  document.getElementById('entryId').value = '';
  document.getElementById('entryForm').reset();
}
function editEntry(t) {
  document.getElementById('entryModalTitle').textContent = 'Edit Timetable Entry';
  document.getElementById('entryAction').value = 'edit';
  document.getElementById('entryId').value = t.id;
  document.getElementById('entryTopic').value = t.topic;
  document.getElementById('entryFaculty').value = t.faculty_id;
  document.getElementById('entryCourse').value = t.course_id || '';
  document.getElementById('entryBatch').value = t.batch_id || '';
  document.getElementById('entryDate').value = t.entry_date;
  document.getElementById('entryStart').value = t.start_time;
  document.getElementById('entryEnd').value = t.end_time;
  new bootstrap.Modal(document.getElementById('addEntryModal')).show();
}
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
