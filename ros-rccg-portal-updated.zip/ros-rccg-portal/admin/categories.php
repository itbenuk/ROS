<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Manage Categories';

$pdo = getDB();
$errors = [];

function slugify(string $text): string
{
    $text = preg_replace('/[^a-zA-Z0-9]+/', '-', strtolower(trim($text)));
    return trim($text, '-');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name = clean_str($_POST['name'] ?? '');
        $description = clean_str($_POST['description'] ?? '');
        if ($name === '') {
            $errors[] = 'Category name is required.';
        } else {
            $slug = slugify($name);
            $chk = $pdo->prepare("SELECT id FROM categories WHERE slug = ?");
            $chk->execute([$slug]);
            if ($chk->fetch()) {
                $errors[] = 'A category with this name already exists.';
            } else {
                $pdo->prepare("INSERT INTO categories (name, slug, description) VALUES (?,?,?)")->execute([$name, $slug, $description]);
                audit_log($_SESSION['user_id'], 'category_created', $name);
                flash('success', 'Category added.');
                redirect('/admin/categories.php');
            }
        }
    } elseif ($action === 'delete') {
        $id = (int) $_POST['id'];
        $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'category_deleted', "ID: $id");
        flash('success', 'Category deleted.');
        redirect('/admin/categories.php');
    }
}

$categories = $pdo->query("SELECT c.*, (SELECT COUNT(*) FROM materials m WHERE m.category_id = c.id) AS material_count
                            FROM categories c ORDER BY c.name")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Manage Material Categories</h3>
    <?php if ($errors): ?><div class="alert alert-danger"><?= e($errors[0]) ?></div><?php endif; ?>

    <div class="row g-4">
      <div class="col-lg-5">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">Add New Category</h6>
          <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add">
            <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" class="form-control" required></div>
            <div class="mb-3"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="3"></textarea></div>
            <button type="submit" class="btn btn-gold"><i class="fa-solid fa-plus me-2"></i>Add Category</button>
          </form>
        </div>
      </div>
      <div class="col-lg-7">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">All Categories</h6>
          <?php if (!$categories): ?>
            <div class="empty-state"><i class="fa-solid fa-tags"></i><p>No categories yet.</p></div>
          <?php else: ?>
          <table class="table align-middle">
            <thead><tr><th>Name</th><th>Materials</th><th class="text-end">Actions</th></tr></thead>
            <tbody>
            <?php foreach ($categories as $c): ?>
              <tr>
                <td><?= e($c['name']) ?></td>
                <td><?= (int)$c['material_count'] ?></td>
                <td class="text-end">
                  <form method="post" class="d-inline" data-confirm-delete="Delete this category?">
                    <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
