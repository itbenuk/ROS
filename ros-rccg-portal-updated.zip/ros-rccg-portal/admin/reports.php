<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Reports & Statistics';

$pdo = getDB();

// Registrations per month (last 6 months)
$regTrend = $pdo->query("SELECT DATE_FORMAT(created_at, '%Y-%m') ym, COUNT(*) c FROM students
                          WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
                          GROUP BY ym ORDER BY ym")->fetchAll();

// Uploads per month
$uploadTrend = $pdo->query("SELECT DATE_FORMAT(created_at, '%Y-%m') ym, COUNT(*) c FROM materials
                             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
                             GROUP BY ym ORDER BY ym")->fetchAll();

// Most downloaded materials
$topMaterials = $pdo->query("SELECT title, download_count FROM materials ORDER BY download_count DESC LIMIT 8")->fetchAll();

// Students per course
$byCourse = $pdo->query("SELECT c.name, COUNT(s.id) cnt FROM courses c LEFT JOIN students s ON s.course_id = c.id
                          GROUP BY c.id ORDER BY cnt DESC")->fetchAll();

$totalDownloads = $pdo->query("SELECT COUNT(*) c FROM material_downloads")->fetch()['c'];
$totalStudents = $pdo->query("SELECT COUNT(*) c FROM students")->fetch()['c'];
$totalFaculty = $pdo->query("SELECT COUNT(*) c FROM faculty")->fetch()['c'];

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="section-title mb-0">Reports &amp; Statistics</h3>
      <a href="<?= BASE_URL ?>/admin/reports.php?export=csv" class="btn btn-outline-secondary btn-sm" onclick="window.print(); return false;"><i class="fa-solid fa-print me-2"></i>Print Report</a>
    </div>

    <div class="row g-4 mb-4">
      <div class="col-lg-6">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">Student Registrations (Last 6 Months)</h6>
          <canvas id="regChart" height="220"></canvas>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">Material Uploads (Last 6 Months)</h6>
          <canvas id="uploadChart" height="220"></canvas>
        </div>
      </div>
    </div>

    <div class="row g-4">
      <div class="col-lg-6">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">Most Downloaded Materials</h6>
          <?php if (!$topMaterials): ?>
            <div class="empty-state py-3"><i class="fa-solid fa-download"></i><p>No downloads recorded yet.</p></div>
          <?php else: foreach ($topMaterials as $m): ?>
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="small"><?= e($m['title']) ?></span>
              <span class="badge text-bg-light"><?= (int)$m['download_count'] ?></span>
            </div>
          <?php endforeach; endif; ?>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">Students per Programme</h6>
          <canvas id="courseChart" height="220"></canvas>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
const regLabels = <?= json_encode(array_column($regTrend, 'ym')) ?>;
const regData = <?= json_encode(array_map('intval', array_column($regTrend, 'c'))) ?>;
new Chart(document.getElementById('regChart'), {
  type: 'line',
  data: { labels: regLabels, datasets: [{ label: 'Registrations', data: regData, borderColor: '#6b1530', backgroundColor: 'rgba(11,61,46,.1)', tension: .3, fill: true }] },
  options: { plugins: { legend: { display: false } } }
});

const uploadLabels = <?= json_encode(array_column($uploadTrend, 'ym')) ?>;
const uploadData = <?= json_encode(array_map('intval', array_column($uploadTrend, 'c'))) ?>;
new Chart(document.getElementById('uploadChart'), {
  type: 'bar',
  data: { labels: uploadLabels, datasets: [{ label: 'Uploads', data: uploadData, backgroundColor: '#c9a24b' }] },
  options: { plugins: { legend: { display: false } } }
});

const courseLabels = <?= json_encode(array_column($byCourse, 'name')) ?>;
const courseData = <?= json_encode(array_map('intval', array_column($byCourse, 'cnt'))) ?>;
new Chart(document.getElementById('courseChart'), {
  type: 'doughnut',
  data: { labels: courseLabels, datasets: [{ data: courseData, backgroundColor: ['#6b1530','#c9a24b','#1e7e34','#b26a00','#6c757d','#495057'] }] },
});
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
