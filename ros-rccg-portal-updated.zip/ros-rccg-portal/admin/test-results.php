<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');

$pdo = getDB();
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT t.*, c.name AS course_name, f.first_name, f.last_name
                        FROM tests t LEFT JOIN courses c ON c.id = t.course_id
                        JOIN faculty f ON f.id = t.faculty_id WHERE t.id = ?");
$stmt->execute([$id]);
$test = $stmt->fetch();

if (!$test) {
    flash('error', 'Test not found.');
    redirect('/admin/tests.php');
}
$pageTitle = 'Results — ' . $test['title'];

$explicitCount = $pdo->prepare("SELECT COUNT(*) c FROM test_assignments WHERE test_id = ?");
$explicitCount->execute([$id]);
$explicitCount = (int) $explicitCount->fetch()['c'];

if ($explicitCount > 0) {
    $assignedCount = $explicitCount;
} else {
    $courseCount = $pdo->prepare("SELECT COUNT(*) c FROM students WHERE course_id = ?");
    $courseCount->execute([$test['course_id']]);
    $assignedCount = (int) $courseCount->fetch()['c'];
}

$attempts = $pdo->prepare("SELECT ta.*, s.first_name, s.last_name, s.reg_number
                            FROM test_attempts ta JOIN students s ON s.id = ta.student_id
                            WHERE ta.test_id = ? ORDER BY ta.created_at DESC");
$attempts->execute([$id]);
$attempts = $attempts->fetchAll();

$started = count($attempts);
$completed = count(array_filter($attempts, fn($a) => in_array($a['status'], ['submitted','auto_submitted','violation_submitted'], true)));
$scores = array_column(array_filter($attempts, fn($a) => $a['percentage'] !== null), 'percentage');
$avgScore = $scores ? round(array_sum($scores) / count($scores), 1) : null;
$highScore = $scores ? max($scores) : null;
$lowScore = $scores ? min($scores) : null;
$passCount = count(array_filter($attempts, fn($a) => $a['passed'] == 1));
$passRate = $completed > 0 ? round(($passCount / $completed) * 100, 1) : null;

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <a href="<?= BASE_URL ?>/admin/tests.php" class="small mb-2 d-inline-block"><i class="fa-solid fa-arrow-left me-1"></i>Back to Tests</a>
    <h3 class="section-title mb-1"><?= e($test['title']) ?></h3>
    <p class="text-muted mb-4"><?= e($test['course_name'] ?? 'General') ?> &middot; By <?= e($test['first_name'].' '.$test['last_name']) ?> &middot; Pass mark <?= e($test['passing_score']) ?>%</p>

    <div class="row g-3 mb-4">
      <div class="col-6 col-lg-2"><div class="stat-card"><div class="stat-value"><?= $assignedCount ?></div><div class="stat-label">Assigned</div></div></div>
      <div class="col-6 col-lg-2"><div class="stat-card"><div class="stat-value"><?= $started ?></div><div class="stat-label">Started</div></div></div>
      <div class="col-6 col-lg-2"><div class="stat-card"><div class="stat-value"><?= $completed ?></div><div class="stat-label">Completed</div></div></div>
      <div class="col-6 col-lg-2"><div class="stat-card"><div class="stat-value"><?= $avgScore ?? '-' ?><?= $avgScore !== null ? '%' : '' ?></div><div class="stat-label">Average Score</div></div></div>
      <div class="col-6 col-lg-2"><div class="stat-card"><div class="stat-value"><?= $highScore ?? '-' ?><?= $highScore !== null ? '%' : '' ?> / <?= $lowScore ?? '-' ?><?= $lowScore !== null ? '%' : '' ?></div><div class="stat-label">High / Low</div></div></div>
      <div class="col-6 col-lg-2"><div class="stat-card"><div class="stat-value"><?= $passRate ?? '-' ?><?= $passRate !== null ? '%' : '' ?></div><div class="stat-label">Pass Rate</div></div></div>
    </div>

    <div class="card p-4">
      <h6 class="fw-bold mb-3">Student Attempts</h6>
      <?php if (!$attempts): ?>
        <div class="empty-state"><i class="fa-solid fa-file-pen"></i><p>No student has started this test yet.</p></div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Student</th><th>Reg. No.</th><th>Status</th><th>Score</th><th>Result</th><th>Submitted</th><th>Time Taken</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($attempts as $a): ?>
            <tr>
              <td><?= e($a['first_name'].' '.$a['last_name']) ?></td>
              <td><?= e($a['reg_number']) ?></td>
              <td>
                <span class="badge <?= $a['status']==='violation_submitted' ? 'text-bg-danger' : 'text-bg-light' ?> text-capitalize"
                      <?= $a['termination_reason'] ? 'title="' . e($a['termination_reason']) . '"' : '' ?>>
                  <?= $a['status']==='violation_submitted' ? '<i class="fa-solid fa-triangle-exclamation me-1"></i>Violation' : e(str_replace('_',' ',$a['status'])) ?>
                </span>
              </td>
              <td><?= $a['percentage'] !== null ? e($a['score']).'/'.e($a['total_marks']).' ('.e($a['percentage']).'%)' : '-' ?></td>
              <td><?php if ($a['passed'] !== null): ?><span class="badge badge-<?= $a['passed'] ? 'active' : 'suspended' ?> px-2 py-1"><?= $a['passed'] ? 'Pass' : 'Fail' ?></span><?php else: ?>-<?php endif; ?></td>
              <td class="small text-muted"><?= $a['submitted_at'] ? time_ago($a['submitted_at']) : '-' ?></td>
              <td class="small text-muted"><?= $a['time_taken_seconds'] ? gmdate('H:i:s', (int)$a['time_taken_seconds']) : '-' ?></td>
              <td class="text-end">
                <?php if (in_array($a['status'], ['submitted','auto_submitted','violation_submitted'], true)): ?>
                  <a href="<?= BASE_URL ?>/admin/test-attempt-view.php?id=<?= (int)$a['id'] ?>" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-eye"></i></a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
