<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Manage Batches';

$pdo = getDB();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name = clean_str($_POST['name'] ?? '');
        $batchCode = strtoupper(clean_str($_POST['batch_code'] ?? ''));
        $courseId = !empty($_POST['course_id']) ? (int) $_POST['course_id'] : null;
        $enrollStart = $_POST['enrollment_start_date'] ?: null;
        $trainingStart = $_POST['training_start_date'] ?: null;
        $expectedCompletion = $_POST['expected_completion_date'] ?: null;
        $id = (int) ($_POST['id'] ?? 0);

        if ($name === '') $errors[] = 'Batch name is required.';
        if ($batchCode === '') {
            // Auto-generate: e.g. B2025A style code based on enrollment year + sequence letter
            $year = $enrollStart ? date('Y', strtotime($enrollStart)) : date('Y');
            for ($i = 0; $i < 26; $i++) {
                $candidate = 'B' . $year . chr(65 + $i);
                $chk = $pdo->prepare("SELECT id FROM batches WHERE batch_code = ? AND id != ?");
                $chk->execute([$candidate, $id]);
                if (!$chk->fetch()) { $batchCode = $candidate; break; }
            }
        }

        if (!$errors) {
            $chk = $pdo->prepare("SELECT id FROM batches WHERE batch_code = ? AND id != ?");
            $chk->execute([$batchCode, $id]);
            if ($chk->fetch()) {
                $errors[] = "The batch code \"$batchCode\" is already in use. Please choose a different one.";
            }
        }

        if (!$errors) {
            if ($action === 'add') {
                $pdo->prepare("INSERT INTO batches (name, batch_code, course_id, enrollment_start_date, training_start_date, expected_completion_date, status)
                                VALUES (?,?,?,?,?,?, 'active')")
                    ->execute([$name, $batchCode, $courseId, $enrollStart, $trainingStart, $expectedCompletion]);
                flash('success', "Batch \"$name\" ($batchCode) created.");
                audit_log($_SESSION['user_id'], 'batch_created', "$name ($batchCode)");
            } else {
                $pdo->prepare("UPDATE batches SET name=?, batch_code=?, course_id=?, enrollment_start_date=?, training_start_date=?, expected_completion_date=? WHERE id=?")
                    ->execute([$name, $batchCode, $courseId, $enrollStart, $trainingStart, $expectedCompletion, $id]);
                flash('success', 'Batch updated.');
                audit_log($_SESSION['user_id'], 'batch_updated', "Batch #$id");
            }
            redirect('/admin/batches.php');
        }
    } elseif ($action === 'graduate_now') {
        $id = (int) $_POST['id'];
        $count = graduate_batch_now($pdo, $id);
        audit_log($_SESSION['user_id'], 'batch_graduated_manually', "Batch #$id, $count student(s)");
        flash('success', "Batch marked as completed. $count student(s) transitioned to Graduated.");
        redirect('/admin/batches.php');
    } elseif ($action === 'delete') {
        $id = (int) $_POST['id'];
        $pdo->prepare("DELETE FROM batches WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'batch_deleted', "Batch #$id");
        flash('success', 'Batch deleted. Any assigned students are now unassigned rather than removed.');
        redirect('/admin/batches.php');
    }
}

// Opportunistically auto-graduate any active batch past its expected completion
// date. There is no background scheduler in this environment - see the README
// section on scalability for wiring this into a real cron job in production.
$activeBatches = $pdo->query("SELECT id FROM batches WHERE status = 'active'")->fetchAll();
foreach ($activeBatches as $b) {
    maybe_graduate_batch($pdo, (int) $b['id']);
}

$batches = $pdo->query("SELECT b.*, c.name AS course_name,
                         (SELECT COUNT(*) FROM students s WHERE s.batch_id = b.id) AS student_count,
                         (SELECT COUNT(*) FROM students s WHERE s.batch_id = b.id AND s.status IN ('registered','active')) AS active_count
                         FROM batches b LEFT JOIN courses c ON c.id = b.course_id
                         ORDER BY b.created_at DESC")->fetchAll();
$courses = $pdo->query("SELECT id, name FROM courses ORDER BY name")->fetchAll();

$statusBadge = fn($s) => match ($s) { 'active' => 'active', 'completed' => 'graduated', 'archived' => 'inactive', default => 'inactive' };

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="section-title mb-0">Manage Batches / Cohorts</h3>
      <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#addBatchModal"><i class="fa-solid fa-plus me-2"></i>Add Batch</button>
    </div>

    <?php if ($errors): ?><div class="alert alert-danger"><?= e($errors[0]) ?></div><?php endif; ?>

    <div class="card p-4">
      <?php if (!$batches): ?>
        <div class="empty-state"><i class="fa-solid fa-people-group"></i><p>No batches created yet.</p></div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Batch</th><th>Programme</th><th>Training Window</th><th>Students</th><th>Status</th><th class="text-end">Actions</th></tr></thead>
          <tbody>
          <?php foreach ($batches as $b): ?>
            <tr>
              <td><strong><?= e($b['name']) ?></strong><div class="small text-muted"><?= e($b['batch_code']) ?></div></td>
              <td><?= e($b['course_name'] ?? 'General') ?></td>
              <td class="small">
                <?= $b['training_start_date'] ? date('M j, Y', strtotime($b['training_start_date'])) : '-' ?>
                &rarr;
                <?= $b['expected_completion_date'] ? date('M j, Y', strtotime($b['expected_completion_date'])) : '-' ?>
                <?php if ($b['actual_completion_date']): ?><div class="text-muted">Completed <?= date('M j, Y', strtotime($b['actual_completion_date'])) ?></div><?php endif; ?>
              </td>
              <td><?= (int)$b['active_count'] ?> active / <?= (int)$b['student_count'] ?> total</td>
              <td><span class="badge badge-<?= $statusBadge($b['status']) ?> px-2 py-1"><?= e(ucfirst($b['status'])) ?></span></td>
              <td class="text-end">
                <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#editBatch<?= (int)$b['id'] ?>"><i class="fa-solid fa-pen"></i></button>
                <?php if ($b['status'] === 'active'): ?>
                  <form method="post" class="d-inline" data-confirm-delete="Mark this batch as completed now and graduate all <?= (int)$b['active_count'] ?> active/registered students in it? This cannot be undone.">
                    <?= csrf_field() ?><input type="hidden" name="action" value="graduate_now"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-outline-success" title="Graduate Batch Now"><i class="fa-solid fa-graduation-cap"></i></button>
                  </form>
                <?php endif; ?>
                <form method="post" class="d-inline" data-confirm-delete="Delete this batch? Students assigned to it will become unassigned, not deleted.">
                  <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></button>
                </form>
              </td>
            </tr>

            <div class="modal fade" id="editBatch<?= (int)$b['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
                    <div class="modal-header"><h5 class="modal-title">Edit Batch</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body">
                      <div class="mb-3"><label class="form-label">Batch Name</label><input type="text" name="name" class="form-control" value="<?= e($b['name']) ?>" required></div>
                      <div class="mb-3"><label class="form-label">Batch Code</label><input type="text" name="batch_code" class="form-control text-uppercase" value="<?= e($b['batch_code']) ?>"></div>
                      <div class="mb-3">
                        <label class="form-label">Programme</label>
                        <select name="course_id" class="form-select">
                          <option value="">General (no specific programme)</option>
                          <?php foreach ($courses as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)$b['course_id']===(int)$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
                        </select>
                      </div>
                      <div class="row g-2">
                        <div class="col-md-4"><label class="form-label">Enrollment Start</label><input type="date" name="enrollment_start_date" class="form-control" value="<?= e($b['enrollment_start_date']) ?>"></div>
                        <div class="col-md-4"><label class="form-label">Training Start</label><input type="date" name="training_start_date" class="form-control" value="<?= e($b['training_start_date']) ?>"></div>
                        <div class="col-md-4"><label class="form-label">Expected Completion</label><input type="date" name="expected_completion_date" class="form-control" value="<?= e($b['expected_completion_date']) ?>"></div>
                      </div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Save</button></div>
                  </form>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="modal fade" id="addBatchModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <div class="modal-header"><h5 class="modal-title">Add Batch / Cohort</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <div class="mb-3"><label class="form-label">Batch Name</label><input type="text" name="name" class="form-control" placeholder="e.g. Batch 2026-A" required></div>
          <div class="mb-3">
            <label class="form-label">Batch Code</label>
            <input type="text" name="batch_code" class="form-control text-uppercase" placeholder="Leave blank to auto-generate">
          </div>
          <div class="mb-3">
            <label class="form-label">Programme</label>
            <select name="course_id" class="form-select">
              <option value="">General (no specific programme)</option>
              <?php foreach ($courses as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="row g-2">
            <div class="col-md-4"><label class="form-label">Enrollment Start</label><input type="date" name="enrollment_start_date" class="form-control"></div>
            <div class="col-md-4"><label class="form-label">Training Start</label><input type="date" name="training_start_date" class="form-control"></div>
            <div class="col-md-4"><label class="form-label">Expected Completion</label><input type="date" name="expected_completion_date" class="form-control"></div>
          </div>
          <div class="form-text mt-2">Training cycles are typically ~6 months from the training start date.</div>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Create Batch</button></div>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
