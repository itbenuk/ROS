<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Student Details';

$pdo = getDB();
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT s.*, u.email, u.status AS account_status, u.last_login_at, u.id AS user_id,
                        c.name AS course_name, se.name AS session_name, b.name AS batch_name, b.batch_code
                        FROM students s JOIN users u ON u.id = s.user_id
                        LEFT JOIN courses c ON c.id = s.course_id
                        LEFT JOIN sessions se ON se.id = s.session_id
                        LEFT JOIN batches b ON b.id = s.batch_id
                        WHERE s.id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();

if (!$student) {
    flash('error', 'Student not found.');
    redirect('/admin/students.php');
}

$downloads = $pdo->prepare("SELECT md.*, m.title FROM material_downloads md
                             JOIN materials m ON m.id = md.material_id
                             WHERE md.student_id = ? ORDER BY md.downloaded_at DESC LIMIT 10");
$downloads->execute([$id]);
$downloads = $downloads->fetchAll();

$attempts = $pdo->prepare("SELECT ta.*, t.title FROM test_attempts ta JOIN tests t ON t.id = ta.test_id
                            WHERE ta.student_id = ? ORDER BY ta.created_at DESC LIMIT 10");
$attempts->execute([$id]);
$attempts = $attempts->fetchAll();

$lifecycleBadge = fn($status) => match ($status) {
    'active'    => 'active',
    'graduated' => 'graduated',
    'withdrawn' => 'suspended',
    default     => 'inactive',
};

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <a href="<?= BASE_URL ?>/admin/students.php" class="small mb-3 d-inline-block"><i class="fa-solid fa-arrow-left me-1"></i>Back to Students</a>

    <div class="row g-4">
      <div class="col-lg-4">
        <div class="card p-4 text-center">
          <?php if ($student['passport_photo']): ?>
            <img src="<?= BASE_URL ?>/admin/download.php?type=passport&file=<?= e($student['passport_photo']) ?>" class="rounded-circle mx-auto mb-3" style="width:120px;height:120px;object-fit:cover;">
          <?php else: ?>
            <i class="fa-solid fa-circle-user fa-6x text-secondary mb-3"></i>
          <?php endif; ?>
          <h5 class="mb-0"><?= e($student['first_name'].' '.$student['middle_name'].' '.$student['last_name']) ?></h5>
          <p class="text-muted small mb-2"><?= e($student['reg_number']) ?></p>
          <div class="d-flex justify-content-center gap-2 flex-wrap">
            <span class="badge badge-<?= $lifecycleBadge($student['status']) ?> px-3 py-2 rounded-pill"><?= e(ucfirst($student['status'])) ?></span>
            <span class="badge badge-<?= $student['account_status']==='active'?'active':'inactive' ?> px-3 py-2 rounded-pill">Account: <?= e(ucfirst($student['account_status'])) ?></span>
          </div>
          <?php if ($student['batch_name']): ?><p class="small text-muted mt-2 mb-0"><?= e($student['batch_name']) ?> (<?= e($student['batch_code']) ?>)</p><?php endif; ?>
          <?php if ($student['graduation_date']): ?><p class="small text-muted mb-0">Graduated <?= date('M j, Y', strtotime($student['graduation_date'])) ?></p><?php endif; ?>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="card p-4 mb-4">
          <h6 class="fw-bold mb-3">Personal & Academic Information</h6>
          <div class="row small">
            <div class="col-md-6 mb-2"><strong>Email:</strong> <?= e($student['email']) ?></div>
            <div class="col-md-6 mb-2"><strong>Phone:</strong> <?= e($student['phone']) ?></div>
            <div class="col-md-6 mb-2"><strong>WhatsApp:</strong> <?= e($student['whatsapp'] ?: '-') ?></div>
            <div class="col-md-6 mb-2"><strong>Gender:</strong> <?= e($student['gender']) ?></div>
            <div class="col-md-6 mb-2"><strong>Date of Birth:</strong> <?= e($student['date_of_birth']) ?></div>
            <div class="col-md-6 mb-2"><strong>Address:</strong> <?= e($student['address']) ?></div>
            <div class="col-md-6 mb-2"><strong>State / Country:</strong> <?= e($student['state'].', '.$student['country']) ?></div>
            <div class="col-md-6 mb-2"><strong>Programme:</strong> <?= e($student['course_name'] ?? '-') ?></div>
            <div class="col-md-6 mb-2"><strong>Session:</strong> <?= e($student['session_name'] ?? '-') ?></div>
            <div class="col-md-6 mb-2"><strong>Enrollment Date:</strong> <?= $student['enrollment_date'] ? date('M j, Y', strtotime($student['enrollment_date'])) : '-' ?></div>
            <div class="col-md-6 mb-2"><strong>Last Login:</strong> <?= $student['last_login_at'] ? time_ago($student['last_login_at']) : 'Never' ?></div>
            <div class="col-md-6 mb-2"><strong>Church/Parish:</strong> <?= e($student['church_parish'] ?: '-') ?></div>
            <div class="col-md-6 mb-2"><strong>RCCG Region/Province/Area/Parish:</strong>
              <?= e(implode(' / ', array_filter([$student['rccg_region'],$student['rccg_province'],$student['rccg_area'],$student['rccg_parish']]))) ?: '-' ?>
            </div>
          </div>
        </div>

        <div class="card p-4 mb-4">
          <h6 class="fw-bold mb-3">Test History <span class="small text-muted fw-normal">(always retained regardless of graduation status)</span></h6>
          <?php if (!$attempts): ?>
            <div class="empty-state py-3"><i class="fa-solid fa-file-pen"></i><p>No test attempts recorded.</p></div>
          <?php else: foreach ($attempts as $a): ?>
            <div class="d-flex justify-content-between small border-bottom pb-2 mb-2">
              <span><?= e($a['title']) ?></span>
              <span class="text-muted"><?= $a['percentage'] !== null ? e($a['percentage']).'%' : e(ucfirst(str_replace('_',' ',$a['status']))) ?></span>
            </div>
          <?php endforeach; endif; ?>
        </div>

        <div class="card p-4">
          <h6 class="fw-bold mb-3">Recent Downloads</h6>
          <?php if (!$downloads): ?>
            <div class="empty-state py-3"><i class="fa-solid fa-download"></i><p>No downloads recorded.</p></div>
          <?php else: foreach ($downloads as $d): ?>
            <div class="d-flex justify-content-between small border-bottom pb-2 mb-2">
              <span><?= e($d['title']) ?></span>
              <span class="text-muted"><?= time_ago($d['downloaded_at']) ?></span>
            </div>
          <?php endforeach; endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
