<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'System Settings';

$pdo = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();

    $settings = [
        'site_name'          => clean_str($_POST['site_name'] ?? ''),
        'site_email'         => clean_str($_POST['site_email'] ?? ''),
        'max_upload_mb'      => (string) max(1, (int) ($_POST['max_upload_mb'] ?? 25)),
        'allow_registration' => isset($_POST['allow_registration']) ? '1' : '0',
        'maintenance_mode'   => isset($_POST['maintenance_mode']) ? '1' : '0',
    ];

    foreach ($settings as $key => $value) {
        $stmt = $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)
                                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        $stmt->execute([$key, $value]);
    }
    audit_log($_SESSION['user_id'], 'settings_updated');
    flash('success', 'Settings updated successfully.');
    redirect('/admin/settings.php');
}

$rows = $pdo->query("SELECT setting_key, setting_value FROM system_settings")->fetchAll();
$settings = [];
foreach ($rows as $r) { $settings[$r['setting_key']] = $r['setting_value']; }

// Recent audit log for transparency
$logs = $pdo->query("SELECT al.*, u.email FROM audit_logs al LEFT JOIN users u ON u.id = al.user_id
                      ORDER BY al.created_at DESC LIMIT 15")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">System Settings</h3>

    <div class="row g-4">
      <div class="col-lg-6">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">General Configuration</h6>
          <form method="post">
            <?= csrf_field() ?>
            <div class="mb-3"><label class="form-label">Site Name</label><input type="text" name="site_name" class="form-control" value="<?= e($settings['site_name'] ?? '') ?>"></div>
            <div class="mb-3"><label class="form-label">Contact Email</label><input type="email" name="site_email" class="form-control" value="<?= e($settings['site_email'] ?? '') ?>"></div>
            <div class="mb-3"><label class="form-label">Max Upload Size (MB)</label><input type="number" name="max_upload_mb" class="form-control" value="<?= e($settings['max_upload_mb'] ?? '25') ?>" min="1" max="200"></div>
            <div class="form-check mb-2">
              <input type="checkbox" name="allow_registration" class="form-check-input" <?= ($settings['allow_registration'] ?? '1') === '1' ? 'checked' : '' ?>>
              <label class="form-check-label">Allow new student registrations</label>
            </div>
            <div class="form-check mb-3">
              <input type="checkbox" name="maintenance_mode" class="form-check-input" <?= ($settings['maintenance_mode'] ?? '0') === '1' ? 'checked' : '' ?>>
              <label class="form-check-label">Maintenance mode</label>
            </div>
            <button type="submit" class="btn btn-gold"><i class="fa-solid fa-floppy-disk me-2"></i>Save Settings</button>
          </form>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">Recent Administrative Activity</h6>
          <?php if (!$logs): ?>
            <div class="empty-state py-3"><i class="fa-solid fa-clipboard-list"></i><p>No activity recorded yet.</p></div>
          <?php else: ?>
          <div class="table-responsive" style="max-height:420px; overflow-y:auto;">
            <table class="table table-sm align-middle">
              <thead><tr><th>Action</th><th>By</th><th>When</th></tr></thead>
              <tbody>
              <?php foreach ($logs as $l): ?>
                <tr>
                  <td class="small"><?= e($l['action']) ?><br><span class="text-muted"><?= e($l['details']) ?></span></td>
                  <td class="small"><?= e($l['email'] ?? 'System') ?></td>
                  <td class="small text-muted"><?= time_ago($l['created_at']) ?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
