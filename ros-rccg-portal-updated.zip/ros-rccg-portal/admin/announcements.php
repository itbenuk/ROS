<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Manage Announcements';

$pdo = getDB();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $title = clean_str($_POST['title'] ?? '');
        $body = clean_str($_POST['body'] ?? '');
        $audience = in_array($_POST['audience'] ?? '', ['all','students','faculty'], true) ? $_POST['audience'] : 'all';

        if ($title === '' || $body === '') {
            $errors[] = 'Title and message are required.';
        } else {
            $pdo->prepare("INSERT INTO announcements (title, body, audience, posted_by_user_id) VALUES (?,?,?,?)")
                ->execute([$title, $body, $audience, $_SESSION['user_id']]);
            audit_log($_SESSION['user_id'], 'admin_announcement_posted', $title);
            flash('success', 'Announcement published.');
            redirect('/admin/announcements.php');
        }
    } elseif ($action === 'delete') {
        $id = (int) $_POST['id'];
        $pdo->prepare("DELETE FROM announcements WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'announcement_deleted', "ID: $id");
        flash('success', 'Announcement deleted.');
        redirect('/admin/announcements.php');
    } elseif ($action === 'toggle_publish') {
        $id = (int) $_POST['id'];
        $pdo->prepare("UPDATE announcements SET is_published = NOT is_published WHERE id = ?")->execute([$id]);
        redirect('/admin/announcements.php');
    }
}

$announcements = $pdo->query("SELECT a.*, u.email FROM announcements a JOIN users u ON u.id = a.posted_by_user_id
                               ORDER BY a.created_at DESC")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Manage Announcements</h3>
    <?php if ($errors): ?><div class="alert alert-danger"><?= e($errors[0]) ?></div><?php endif; ?>

    <div class="card p-4 mb-4">
      <h6 class="fw-bold mb-3">Publish New Announcement</h6>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <div class="row g-3">
          <div class="col-md-8"><label class="form-label">Title</label><input type="text" name="title" class="form-control" required></div>
          <div class="col-md-4">
            <label class="form-label">Audience</label>
            <select name="audience" class="form-select">
              <option value="all">Everyone</option>
              <option value="students">Students Only</option>
              <option value="faculty">Faculty Only</option>
            </select>
          </div>
          <div class="col-12"><label class="form-label">Message</label><textarea name="body" class="form-control" rows="3" required></textarea></div>
        </div>
        <button type="submit" class="btn btn-gold mt-3"><i class="fa-solid fa-paper-plane me-2"></i>Publish</button>
      </form>
    </div>

    <div class="card p-4">
      <h6 class="fw-bold mb-3">All Announcements</h6>
      <?php if (!$announcements): ?>
        <div class="empty-state"><i class="fa-solid fa-bullhorn"></i><p>No announcements yet.</p></div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Title</th><th>Audience</th><th>Posted By</th><th>Status</th><th>Date</th><th class="text-end">Actions</th></tr></thead>
          <tbody>
          <?php foreach ($announcements as $a): ?>
            <tr>
              <td class="fw-semibold"><?= e($a['title']) ?></td>
              <td><span class="badge text-bg-light text-capitalize"><?= e($a['audience']) ?></span></td>
              <td><?= e($a['email']) ?></td>
              <td>
                <form method="post" class="d-inline">
                  <?= csrf_field() ?><input type="hidden" name="action" value="toggle_publish"><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                  <button class="btn btn-sm badge-<?= $a['is_published']?'active':'inactive' ?> border-0 px-2 py-1" type="submit">
                    <?= $a['is_published'] ? 'Published' : 'Hidden' ?>
                  </button>
                </form>
              </td>
              <td class="text-muted small"><?= time_ago($a['created_at']) ?></td>
              <td class="text-end">
                <form method="post" class="d-inline" data-confirm-delete="Delete this announcement?">
                  <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
