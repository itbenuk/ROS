<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Admin Dashboard';

$pdo = getDB();

$stats = [
    'students'   => $pdo->query("SELECT COUNT(*) c FROM students")->fetch()['c'],
    'faculty'    => $pdo->query("SELECT COUNT(*) c FROM faculty")->fetch()['c'],
    'materials'  => $pdo->query("SELECT COUNT(*) c FROM materials")->fetch()['c'],
    'downloads'  => $pdo->query("SELECT COUNT(*) c FROM material_downloads")->fetch()['c'],
    'active'     => $pdo->query("SELECT COUNT(*) c FROM users WHERE status='active'")->fetch()['c'],
    'tests'      => $pdo->query("SELECT COUNT(*) c FROM tests")->fetch()['c'],
    'attempts'   => $pdo->query("SELECT COUNT(*) c FROM test_attempts")->fetch()['c'],
];

$recentStudents = $pdo->query("SELECT s.reg_number, s.first_name, s.last_name, s.created_at, c.name AS course_name
                                FROM students s LEFT JOIN courses c ON c.id = s.course_id
                                ORDER BY s.created_at DESC LIMIT 5")->fetchAll();

$recentUploads = $pdo->query("SELECT m.title, m.created_at, f.first_name, f.last_name
                               FROM materials m JOIN faculty f ON f.id = m.faculty_id
                               ORDER BY m.created_at DESC LIMIT 5")->fetchAll();

$announcements = $pdo->query("SELECT title, created_at FROM announcements WHERE is_published=1 ORDER BY created_at DESC LIMIT 5")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">System Overview</h3>

    <div class="row g-3 mb-4">
      <div class="col-6 col-lg-3">
        <div class="stat-card"><div class="stat-icon mb-2" style="background:#6b1530;"><i class="fa-solid fa-user-graduate"></i></div>
          <div class="stat-value"><?= (int)$stats['students'] ?></div><div class="stat-label">Total Students</div></div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card"><div class="stat-icon mb-2" style="background:#c9a24b;"><i class="fa-solid fa-chalkboard-user"></i></div>
          <div class="stat-value"><?= (int)$stats['faculty'] ?></div><div class="stat-label">Total Faculty</div></div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card"><div class="stat-icon mb-2" style="background:#1e7e34;"><i class="fa-solid fa-folder-open"></i></div>
          <div class="stat-value"><?= (int)$stats['materials'] ?></div><div class="stat-label">Total Materials</div></div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card"><div class="stat-icon mb-2" style="background:#b26a00;"><i class="fa-solid fa-download"></i></div>
          <div class="stat-value"><?= (int)$stats['downloads'] ?></div><div class="stat-label">Total Downloads</div></div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card"><div class="stat-icon mb-2" style="background:#4a0e21;"><i class="fa-solid fa-file-pen"></i></div>
          <div class="stat-value"><?= (int)$stats['tests'] ?></div><div class="stat-label">Total Tests</div></div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card"><div class="stat-icon mb-2" style="background:#a13355;"><i class="fa-solid fa-square-poll-vertical"></i></div>
          <div class="stat-value"><?= (int)$stats['attempts'] ?></div><div class="stat-label">Test Attempts</div></div>
      </div>
    </div>

    <div class="row g-4">
      <div class="col-lg-4">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">Recent Registrations</h6>
          <?php if (!$recentStudents): ?><div class="empty-state py-3"><i class="fa-solid fa-user-graduate"></i><p>None yet.</p></div>
          <?php else: foreach ($recentStudents as $s): ?>
            <div class="d-flex justify-content-between border-bottom pb-2 mb-2 small">
              <div><strong><?= e($s['first_name'].' '.$s['last_name']) ?></strong><br><span class="text-muted"><?= e($s['reg_number']) ?> &middot; <?= e($s['course_name'] ?? '-') ?></span></div>
              <span class="text-muted"><?= time_ago($s['created_at']) ?></span>
            </div>
          <?php endforeach; endif; ?>
          <a href="<?= BASE_URL ?>/admin/students.php" class="small">View all students &rarr;</a>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">Recent Uploads</h6>
          <?php if (!$recentUploads): ?><div class="empty-state py-3"><i class="fa-solid fa-folder-open"></i><p>None yet.</p></div>
          <?php else: foreach ($recentUploads as $m): ?>
            <div class="d-flex justify-content-between border-bottom pb-2 mb-2 small">
              <div><strong><?= e($m['title']) ?></strong><br><span class="text-muted">By <?= e($m['first_name'].' '.$m['last_name']) ?></span></div>
              <span class="text-muted"><?= time_ago($m['created_at']) ?></span>
            </div>
          <?php endforeach; endif; ?>
          <a href="<?= BASE_URL ?>/admin/materials.php" class="small">View all materials &rarr;</a>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card p-4">
          <h6 class="fw-bold mb-3">System Announcements</h6>
          <?php if (!$announcements): ?><div class="empty-state py-3"><i class="fa-solid fa-bullhorn"></i><p>None yet.</p></div>
          <?php else: foreach ($announcements as $a): ?>
            <div class="d-flex justify-content-between border-bottom pb-2 mb-2 small">
              <strong><?= e($a['title']) ?></strong>
              <span class="text-muted"><?= time_ago($a['created_at']) ?></span>
            </div>
          <?php endforeach; endif; ?>
          <a href="<?= BASE_URL ?>/admin/announcements.php" class="small">Manage announcements &rarr;</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
