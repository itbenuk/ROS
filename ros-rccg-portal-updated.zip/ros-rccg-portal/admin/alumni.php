<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Alumni / Graduated Students';

$pdo = getDB();

// Alumni are never stored as a separate record - this page (and the public
// alumni.php page) simply query `students` WHERE status = 'graduated'.
// The only thing an admin can set here is whether a graduate is shown on
// the public page (show_in_alumni); everything else is edited on the
// student's normal profile so there is only ever one record per student.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';

    if ($action === 'toggle_public') {
        $id = (int) $_POST['id'];
        $pdo->prepare("UPDATE students SET show_in_alumni = NOT show_in_alumni WHERE id = ? AND status = 'graduated'")->execute([$id]);
        audit_log($_SESSION['user_id'], 'alumni_visibility_toggled', "Student $id");
        flash('success', 'Alumni public visibility updated.');
    }
    redirect('/admin/alumni.php' . (isset($_GET['q']) || isset($_GET['course_id']) || isset($_GET['year']) ? '?' . http_build_query($_GET) : ''));
}

$search = clean_str($_GET['q'] ?? '');
$courseId = (int) ($_GET['course_id'] ?? 0);
$year = (int) ($_GET['year'] ?? 0);
$page = max(1, (int) ($_GET['page'] ?? 1));

$result = get_alumni($pdo, [
    'search'      => $search,
    'course_id'   => $courseId,
    'year'        => $year,
    'public_only' => false,
    'per_page'    => 15,
    'page'        => $page,
]);
$alumni = $result['rows'];
$p = $result['pagination'];

$courses = $pdo->query("SELECT id, name FROM courses ORDER BY name")->fetchAll();
$years = get_alumni_years($pdo, false);

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
      <h3 class="section-title mb-0">Alumni / Graduated Students</h3>
      <span class="text-muted small"><?= (int)$result['total'] ?> graduate<?= $result['total']==1?'':'s' ?></span>
    </div>
    <p class="text-muted small mb-3">This list is generated automatically from student records whose status is <strong>Graduated</strong> — nothing here is a separate entry. To correct a graduate's details, edit their profile from <a href="<?= BASE_URL ?>/admin/students.php">Manage Students</a>; changes appear here and on the public Alumni page immediately.</p>

    <div class="card p-3 mb-3">
      <form class="row g-2" method="get">
        <div class="col-md-4"><input type="text" name="q" class="form-control" placeholder="Search by name or reg. no..." value="<?= e($search) ?>"></div>
        <div class="col-md-3">
          <select name="course_id" class="form-select">
            <option value="">All Programmes</option>
            <?php foreach ($courses as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $courseId==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3">
          <select name="year" class="form-select">
            <option value="">All Graduation Years</option>
            <?php foreach ($years as $y): ?><option value="<?= (int)$y ?>" <?= $year==$y?'selected':'' ?>><?= (int)$y ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-2"><button class="btn btn-gold w-100" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button></div>
      </form>
    </div>

    <div class="card p-4">
      <?php if (!$alumni): ?>
        <div class="empty-state"><i class="fa-solid fa-user-graduate"></i><p>No graduated students found.</p></div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th></th><th>Name</th><th>Reg. No.</th><th>Programme</th><th>Graduation</th><th>Public on Alumni Page</th><th class="text-end">Actions</th></tr></thead>
          <tbody>
          <?php foreach ($alumni as $a): ?>
            <tr>
              <td>
                <?php if ($a['passport_photo']): ?>
                  <img src="<?= BASE_URL ?>/admin/download.php?type=passport&file=<?= e($a['passport_photo']) ?>" class="rounded-circle" style="width:40px;height:40px;object-fit:cover;">
                <?php else: ?>
                  <i class="fa-solid fa-circle-user fa-2x text-secondary"></i>
                <?php endif; ?>
              </td>
              <td><?= e($a['first_name'].' '.$a['last_name']) ?></td>
              <td><?= e($a['reg_number']) ?></td>
              <td><?= e($a['course_name'] ?? '-') ?></td>
              <td><?= $a['graduation_date'] ? date('M j, Y', strtotime($a['graduation_date'])) : '-' ?></td>
              <td>
                <form method="post" class="d-inline">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="toggle_public">
                  <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-<?= $a['show_in_alumni'] ? 'success' : 'secondary' ?>">
                    <i class="fa-solid fa-<?= $a['show_in_alumni'] ? 'eye' : 'eye-slash' ?> me-1"></i><?= $a['show_in_alumni'] ? 'Shown' : 'Hidden' ?>
                  </button>
                </form>
              </td>
              <td class="text-end">
                <a href="<?= BASE_URL ?>/admin/student-view.php?id=<?= (int)$a['id'] ?>" class="btn btn-sm btn-outline-secondary" title="View Full Profile"><i class="fa-solid fa-eye"></i></a>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php if ($p['totalPages'] > 1): ?>
        <nav class="mt-3"><ul class="pagination justify-content-center">
          <?php for ($i=1;$i<=$p['totalPages'];$i++): $qs=$_GET; $qs['page']=$i; ?>
            <li class="page-item <?= $i===$p['currentPage']?'active':'' ?>"><a class="page-link" href="?<?= http_build_query($qs) ?>"><?= $i ?></a></li>
          <?php endfor; ?>
        </ul></nav>
      <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
