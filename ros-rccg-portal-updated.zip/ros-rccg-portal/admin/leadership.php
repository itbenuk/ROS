<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Manage Leadership';

$pdo = getDB();
$errors = [];

$categoryOptions = [
    'general_overseer' => 'General Overseer',
    'overseer_wife'    => "General Overseer's Wife",
    'parish_pastor'    => 'Parish Pastor',
    'pastor_wife'      => "Parish Pastor's Wife",
    'other'            => 'Other Leadership',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $id = (int) ($_POST['id'] ?? 0);
        $category = array_key_exists($_POST['category'] ?? '', $categoryOptions) ? $_POST['category'] : 'other';
        $fullName = clean_str($_POST['full_name'] ?? '');
        $title = clean_str($_POST['title'] ?? '');
        $bio = clean_str($_POST['bio'] ?? '');
        $displayOrder = (int) ($_POST['display_order'] ?? 0);

        if ($fullName === '') $errors[] = 'Full name is required.';
        if ($title === '') $errors[] = 'Official title/position is required.';

        $newPhoto = null;
        if (!empty($_FILES['photo']['name'])) {
            $res = validate_and_move_upload($_FILES['photo'], UPLOAD_LEADERSHIP_PATH, ALLOWED_LEADERSHIP_PHOTO_TYPES, MAX_LEADERSHIP_PHOTO_BYTES);
            if (!$res['success']) {
                $errors[] = $res['message'];
            } else {
                $newPhoto = $res['stored_name'];
            }
        } elseif ($action === 'add') {
            $errors[] = 'A profile picture is required.';
        }

        if (!$errors && $action === 'add') {
            $stmt = $pdo->prepare("INSERT INTO leadership_profiles (category, full_name, title, bio, photo, display_order, is_active)
                                    VALUES (?,?,?,?,?,?,1)");
            $stmt->execute([$category, $fullName, $title, $bio, $newPhoto, $displayOrder]);
            audit_log($_SESSION['user_id'], 'leadership_created', "$fullName ($title)");
            flash('success', 'Leadership profile added.');
        } elseif (!$errors && $action === 'edit') {
            $chk = $pdo->prepare("SELECT photo FROM leadership_profiles WHERE id = ?");
            $chk->execute([$id]);
            $existing = $chk->fetch();
            if (!$existing) {
                $errors[] = 'Profile not found.';
            } else {
                if ($newPhoto) {
                    if (!empty($existing['photo']) && is_file(UPLOAD_LEADERSHIP_PATH . $existing['photo'])) {
                        unlink(UPLOAD_LEADERSHIP_PATH . $existing['photo']);
                    }
                    $stmt = $pdo->prepare("UPDATE leadership_profiles SET category=?, full_name=?, title=?, bio=?, photo=?, display_order=? WHERE id=?");
                    $stmt->execute([$category, $fullName, $title, $bio, $newPhoto, $displayOrder, $id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE leadership_profiles SET category=?, full_name=?, title=?, bio=?, display_order=? WHERE id=?");
                    $stmt->execute([$category, $fullName, $title, $bio, $displayOrder, $id]);
                }
                audit_log($_SESSION['user_id'], 'leadership_updated', "ID: $id");
                flash('success', 'Leadership profile updated.');
            }
        }

        if ($errors) {
            foreach ($errors as $err) flash('error', $err);
        }
        redirect('/admin/leadership.php');
    } elseif ($action === 'toggle_active') {
        $id = (int) $_POST['id'];
        $pdo->prepare("UPDATE leadership_profiles SET is_active = NOT is_active WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'leadership_visibility_toggled', "ID: $id");
        flash('success', 'Visibility updated.');
        redirect('/admin/leadership.php');
    } elseif ($action === 'delete') {
        $id = (int) $_POST['id'];
        $stmt = $pdo->prepare("SELECT photo FROM leadership_profiles WHERE id = ?");
        $stmt->execute([$id]);
        if ($row = $stmt->fetch()) {
            if (!empty($row['photo']) && is_file(UPLOAD_LEADERSHIP_PATH . $row['photo'])) {
                unlink(UPLOAD_LEADERSHIP_PATH . $row['photo']);
            }
            $pdo->prepare("DELETE FROM leadership_profiles WHERE id = ?")->execute([$id]);
            audit_log($_SESSION['user_id'], 'leadership_deleted', "ID: $id");
            flash('success', 'Leadership profile removed.');
        }
        redirect('/admin/leadership.php');
    }
}

$profiles = get_leadership_profiles($pdo, false);

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
      <h3 class="section-title mb-0">Manage Leadership</h3>
      <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#addLeadershipModal"><i class="fa-solid fa-plus me-2"></i>Add Profile</button>
    </div>
    <p class="text-muted small mb-4">These profiles power the public <a href="<?= BASE_URL ?>/leadership.php" target="_blank">Leadership page</a>, which is organized into three sections: <strong>General Overseer &amp; Wife</strong> (the first two roles below), <strong>ROS Leadership</strong> (Parish Pastor, his wife, and anything you add as "Other Leadership"), and <strong>Faculty Members</strong> (managed separately under <a href="<?= BASE_URL ?>/admin/faculty.php">Manage Faculty</a>). Hidden profiles stay here for editing but are not shown publicly.</p>

    <?php if (!$profiles): ?>
      <div class="card p-4"><div class="empty-state"><i class="fa-solid fa-people-roof"></i><p>No leadership profiles yet.</p></div></div>
    <?php else: ?>
    <div class="row g-4">
      <?php foreach ($profiles as $p): ?>
        <div class="col-md-6 col-lg-4 col-xl-3">
          <div class="card p-3 h-100 text-center leadership-admin-card">
            <?php if ($p['photo']): ?>
              <img src="<?= BASE_URL ?>/admin/download.php?type=leadership&file=<?= e($p['photo']) ?>" class="rounded-circle mx-auto mb-3" style="width:96px;height:96px;object-fit:cover;" alt="<?= e($p['full_name']) ?>">
            <?php else: ?>
              <i class="fa-solid fa-circle-user fa-5x text-secondary mb-3"></i>
            <?php endif; ?>
            <span class="badge text-bg-light mb-2 align-self-center"><?= e(leadership_category_label($p['category'])) ?></span>
            <h6 class="mb-0"><?= e($p['full_name']) ?></h6>
            <p class="text-muted small mb-2"><?= e($p['title']) ?></p>
            <p class="small mb-3" style="min-height:2.5em;"><?= e(strlen($p['bio']) > 90 ? substr($p['bio'], 0, 90) . '…' : $p['bio']) ?></p>
            <div class="mt-auto d-flex justify-content-center gap-1 flex-wrap">
              <span class="badge badge-<?= $p['is_active'] ? 'active' : 'inactive' ?> px-2 py-1 mb-2"><?= $p['is_active'] ? 'Visible' : 'Hidden' ?></span>
            </div>
            <div class="d-flex justify-content-center gap-1">
              <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editLeadership<?= (int)$p['id'] ?>" title="Edit"><i class="fa-solid fa-pen"></i></button>
              <form method="post" class="d-inline">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="toggle_active">
                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                <button type="submit" class="btn btn-sm btn-outline-<?= $p['is_active'] ? 'warning' : 'success' ?>" title="<?= $p['is_active'] ? 'Hide from public page' : 'Show on public page' ?>"><i class="fa-solid fa-<?= $p['is_active'] ? 'eye-slash' : 'eye' ?>"></i></button>
              </form>
              <form method="post" class="d-inline" data-confirm-delete="Permanently remove this leadership profile?">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div>
          </div>
        </div>

        <!-- Edit Modal -->
        <div class="modal fade" id="editLeadership<?= (int)$p['id'] ?>" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <form method="post" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                <div class="modal-header"><h5 class="modal-title">Edit &mdash; <?= e($p['full_name']) ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                  <div class="mb-3">
                    <label class="form-label">Role</label>
                    <select name="category" class="form-select">
                      <?php foreach ($categoryOptions as $val => $label): ?>
                        <option value="<?= e($val) ?>" <?= $p['category']===$val?'selected':'' ?>><?= e($label) ?></option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                  <div class="mb-3"><label class="form-label">Full Name *</label><input type="text" name="full_name" class="form-control" value="<?= e($p['full_name']) ?>" required></div>
                  <div class="mb-3"><label class="form-label">Official Title/Position *</label><input type="text" name="title" class="form-control" value="<?= e($p['title']) ?>" required></div>
                  <div class="mb-3"><label class="form-label">Short Biography</label><textarea name="bio" class="form-control" rows="3"><?= e($p['bio']) ?></textarea></div>
                  <div class="mb-3"><label class="form-label">Display Order</label><input type="number" name="display_order" class="form-control" value="<?= (int)$p['display_order'] ?>" min="0"></div>
                  <div class="mb-2">
                    <label class="form-label">Replace Profile Picture</label>
                    <input type="file" name="photo" class="form-control" accept=".jpg,.jpeg,.png">
                    <div class="form-text">Leave blank to keep the current picture.</div>
                  </div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Save Changes</button></div>
              </form>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Add Leadership Modal -->
<div class="modal fade" id="addLeadershipModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <div class="modal-header"><h5 class="modal-title">Add Leadership Profile</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Role</label>
            <select name="category" class="form-select">
              <?php foreach ($categoryOptions as $val => $label): ?>
                <option value="<?= e($val) ?>"><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3"><label class="form-label">Full Name *</label><input type="text" name="full_name" class="form-control" required></div>
          <div class="mb-3"><label class="form-label">Official Title/Position *</label><input type="text" name="title" class="form-control" placeholder="e.g. General Overseer, RCCG" required></div>
          <div class="mb-3"><label class="form-label">Short Biography</label><textarea name="bio" class="form-control" rows="3"></textarea></div>
          <div class="mb-3"><label class="form-label">Display Order</label><input type="number" name="display_order" class="form-control" value="0" min="0"></div>
          <div class="mb-2">
            <label class="form-label">Profile Picture *</label>
            <input type="file" name="photo" class="form-control" accept=".jpg,.jpeg,.png" required>
            <div class="form-text">JPG or PNG, up to 3&nbsp;MB.</div>
          </div>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Add Profile</button></div>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
