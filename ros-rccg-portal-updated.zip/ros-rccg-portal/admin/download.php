<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');

$type = $_GET['type'] ?? '';
$file = basename($_GET['file'] ?? ''); // basename() strips path traversal attempts

if ($type === 'passport' || $type === 'photo') {
    $path = UPLOAD_PASSPORTS_PATH . $file;
} elseif ($type === 'material') {
    $path = UPLOAD_MATERIALS_PATH . $file;
} elseif ($type === 'leadership') {
    $path = UPLOAD_LEADERSHIP_PATH . $file;
} else {
    http_response_code(400);
    exit('Invalid request.');
}

if (!$file || !is_file($path)) {
    http_response_code(404);
    exit('Not found.');
}

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $path);
finfo_close($finfo);

header('Content-Type: ' . $mime);
header('Content-Disposition: inline; filename="' . $file . '"');
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
