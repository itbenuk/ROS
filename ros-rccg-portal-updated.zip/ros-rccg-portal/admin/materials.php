<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Manage Materials';

$pdo = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'delete') {
        $stmt = $pdo->prepare("SELECT stored_name FROM materials WHERE id = ?");
        $stmt->execute([$id]);
        if ($m = $stmt->fetch()) {
            $path = UPLOAD_MATERIALS_PATH . $m['stored_name'];
            if (is_file($path)) unlink($path);
            $pdo->prepare("DELETE FROM materials WHERE id = ?")->execute([$id]);
            audit_log($_SESSION['user_id'], 'admin_material_deleted', "ID: $id");
            flash('success', 'Material deleted.');
        }
    } elseif ($action === 'change_status') {
        $status = in_array($_POST['status'] ?? '', ['published','draft','archived'], true) ? $_POST['status'] : 'published';
        $pdo->prepare("UPDATE materials SET status = ? WHERE id = ?")->execute([$status, $id]);
        flash('success', 'Material status updated.');
    }
    redirect('/admin/materials.php');
}

$search = clean_str($_GET['q'] ?? '');
$status = clean_str($_GET['status'] ?? '');
$where = ["1=1"];
$params = [];
if ($search !== '') { $where[] = "m.title LIKE ?"; $params[] = "%$search%"; }
if ($status !== '') { $where[] = "m.status = ?"; $params[] = $status; }
$whereSql = implode(' AND ', $where);

$stmt = $pdo->prepare("SELECT m.*, c.name AS course_name, cat.name AS category_name, f.first_name, f.last_name
                        FROM materials m
                        LEFT JOIN courses c ON c.id = m.course_id
                        LEFT JOIN categories cat ON cat.id = m.category_id
                        JOIN faculty f ON f.id = m.faculty_id
                        WHERE $whereSql ORDER BY m.created_at DESC");
$stmt->execute($params);
$materials = $stmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Manage All Materials</h3>

    <div class="card p-3 mb-3">
      <form class="row g-2" method="get">
        <div class="col-md-6"><input type="text" name="q" class="form-control" placeholder="Search by title..." value="<?= e($search) ?>"></div>
        <div class="col-md-3">
          <select name="status" class="form-select">
            <option value="">All Statuses</option>
            <option value="published" <?= $status==='published'?'selected':'' ?>>Published</option>
            <option value="draft" <?= $status==='draft'?'selected':'' ?>>Draft</option>
            <option value="archived" <?= $status==='archived'?'selected':'' ?>>Archived</option>
          </select>
        </div>
        <div class="col-md-3"><button class="btn btn-gold w-100" type="submit">Filter</button></div>
      </form>
    </div>

    <div class="card p-4">
      <?php if (!$materials): ?>
        <div class="empty-state"><i class="fa-solid fa-folder-open"></i><p>No materials found.</p></div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Title</th><th>Faculty</th><th>Course</th><th>Type</th><th>Status</th><th>Downloads</th><th class="text-end">Actions</th></tr></thead>
          <tbody>
          <?php foreach ($materials as $m): ?>
            <tr>
              <td class="fw-semibold"><?= e($m['title']) ?></td>
              <td><?= e($m['first_name'].' '.$m['last_name']) ?></td>
              <td><?= e($m['course_name'] ?? '-') ?></td>
              <td><span class="badge text-bg-light text-uppercase"><?= e($m['file_type']) ?></span></td>
              <td>
                <form method="post" class="d-inline">
                  <?= csrf_field() ?><input type="hidden" name="action" value="change_status"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                  <select name="status" class="form-select form-select-sm d-inline w-auto" onchange="this.form.submit()">
                    <option value="published" <?= $m['status']==='published'?'selected':'' ?>>Published</option>
                    <option value="draft" <?= $m['status']==='draft'?'selected':'' ?>>Draft</option>
                    <option value="archived" <?= $m['status']==='archived'?'selected':'' ?>>Archived</option>
                  </select>
                </form>
              </td>
              <td><?= (int)$m['download_count'] ?></td>
              <td class="text-end">
                <form method="post" class="d-inline" data-confirm-delete="Permanently delete this material?">
                  <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
