<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Manage Tests';

$pdo = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    $stmt = $pdo->prepare("SELECT * FROM tests WHERE id = ?");
    $stmt->execute([$id]);
    $test = $stmt->fetch();

    if (!$test) {
        flash('error', 'Test not found.');
        redirect('/admin/tests.php');
    }

    if ($action === 'publish') {
        $newStatus = strtotime($test['start_at']) > time() ? 'scheduled' : 'published';
        $pdo->prepare("UPDATE tests SET status = ? WHERE id = ?")->execute([$newStatus, $id]);
        audit_log($_SESSION['user_id'], 'admin_test_published', "Test #$id");
        flash('success', 'Test published.');
    } elseif ($action === 'unpublish') {
        $pdo->prepare("UPDATE tests SET status = 'draft' WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'admin_test_unpublished', "Test #$id");
        flash('success', 'Test moved back to draft.');
    } elseif ($action === 'close') {
        $pdo->prepare("UPDATE tests SET status = 'closed' WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'admin_test_closed', "Test #$id");
        flash('success', 'Test closed.');
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM tests WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'admin_test_deleted', "Test #$id");
        flash('success', 'Test deleted.');
    }
    redirect('/admin/tests.php');
}

$search = clean_str($_GET['q'] ?? '');
$status = clean_str($_GET['status'] ?? '');
$where = ["1=1"];
$params = [];
if ($search !== '') { $where[] = "t.title LIKE ?"; $params[] = "%$search%"; }
if ($status !== '') { $where[] = "t.status = ?"; $params[] = $status; }
$whereSql = implode(' AND ', $where);

$stmt = $pdo->prepare("SELECT t.*, c.name AS course_name, f.first_name, f.last_name,
                        (SELECT COUNT(*) FROM test_questions q WHERE q.test_id = t.id) AS question_count,
                        (SELECT COUNT(*) FROM test_attempts a WHERE a.test_id = t.id) AS attempt_count
                        FROM tests t
                        LEFT JOIN courses c ON c.id = t.course_id
                        JOIN faculty f ON f.id = t.faculty_id
                        WHERE $whereSql ORDER BY t.created_at DESC");
$stmt->execute($params);
$tests = $stmt->fetchAll();

$statusBadge = fn($t) => match (test_effective_status($t)) {
    'draft'    => ['secondary', 'Draft'],
    'upcoming' => ['info', 'Scheduled'],
    'open'     => ['success', 'Open Now'],
    'closed'   => ['danger', 'Closed'],
};

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Manage All Tests</h3>

    <div class="card p-3 mb-3">
      <form class="row g-2" method="get">
        <div class="col-md-6"><input type="text" name="q" class="form-control" placeholder="Search by title..." value="<?= e($search) ?>"></div>
        <div class="col-md-3">
          <select name="status" class="form-select">
            <option value="">All Statuses</option>
            <option value="draft" <?= $status==='draft'?'selected':'' ?>>Draft</option>
            <option value="scheduled" <?= $status==='scheduled'?'selected':'' ?>>Scheduled</option>
            <option value="published" <?= $status==='published'?'selected':'' ?>>Published</option>
            <option value="closed" <?= $status==='closed'?'selected':'' ?>>Closed</option>
          </select>
        </div>
        <div class="col-md-3"><button class="btn btn-gold w-100" type="submit">Filter</button></div>
      </form>
    </div>

    <?php if (!$tests): ?>
      <div class="empty-state"><i class="fa-solid fa-file-pen"></i><p>No tests found.</p></div>
    <?php else: ?>
    <div class="row g-3">
      <?php foreach ($tests as $t): [$badgeColor, $badgeLabel] = $statusBadge($t); ?>
        <div class="col-12">
          <div class="card p-3">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-2">
              <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                  <h6 class="mb-0"><?= e($t['title']) ?></h6>
                  <span class="badge text-bg-<?= $badgeColor ?>"><?= $badgeLabel ?></span>
                </div>
                <div class="small text-muted">
                  <?= e($t['course_name'] ?? 'General') ?> &middot; By <?= e($t['first_name'].' '.$t['last_name']) ?> &middot;
                  <?= (int)$t['question_count'] ?> questions &middot; <?= (int)$t['attempt_count'] ?> attempt(s)
                </div>
                <div class="small text-muted"><?= date('M j, Y g:ia', strtotime($t['start_at'])) ?> &rarr; <?= date('M j, Y g:ia', strtotime($t['end_at'])) ?></div>
              </div>
              <div class="d-flex flex-wrap gap-1">
                <a href="<?= BASE_URL ?>/admin/test-results.php?id=<?= (int)$t['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Results"><i class="fa-solid fa-chart-simple"></i></a>
                <?php if ($t['status'] === 'draft'): ?>
                  <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="publish"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                    <button class="btn btn-sm btn-gold" type="submit"><i class="fa-solid fa-paper-plane me-1"></i>Publish</button>
                  </form>
                <?php elseif (in_array($t['status'], ['published','scheduled'], true)): ?>
                  <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="unpublish"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                    <button class="btn btn-sm btn-outline-warning" type="submit" title="Unpublish"><i class="fa-solid fa-arrow-rotate-left"></i></button>
                  </form>
                  <form method="post" class="d-inline" data-confirm-delete="Close this test now?">
                    <?= csrf_field() ?><input type="hidden" name="action" value="close"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                    <button class="btn btn-sm btn-outline-danger" type="submit" title="Close Now"><i class="fa-solid fa-lock"></i></button>
                  </form>
                <?php endif; ?>
                <form method="post" class="d-inline" data-confirm-delete="Permanently delete this test, its questions and all attempts?">
                  <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                  <button class="btn btn-sm btn-outline-danger" type="submit" title="Delete"><i class="fa-solid fa-trash"></i></button>
                </form>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
