<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Manage Students';

$pdo = getDB();
$errors = [];

// --- Handle actions ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';

    if ($action === 'toggle_status') {
        $userId = (int) $_POST['user_id'];
        $newStatus = $_POST['new_status'] === 'active' ? 'active' : 'inactive';
        $pdo->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'student'")->execute([$newStatus, $userId]);
        audit_log($_SESSION['user_id'], 'student_status_changed', "User $userId => $newStatus");
        flash('success', 'Student account access updated.');
    } elseif ($action === 'reset_password') {
        $userId = (int) $_POST['user_id'];
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (!is_strong_password($newPassword)) {
            flash('error', 'Password must be at least 8 characters and include letters and numbers.');
        } elseif ($newPassword !== $confirmPassword) {
            flash('error', 'The passwords do not match.');
        } else {
            $hash = password_hash($newPassword, PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ? AND role = 'student'")->execute([$hash, $userId]);
            // Never log the password itself - just that a reset happened, by whom, and when (created_at).
            audit_log($_SESSION['user_id'], 'student_password_reset', "Admin reset password for user #$userId");
            flash('success', "Password reset successfully.");
        }
    } elseif ($action === 'delete') {
        $userId = (int) $_POST['user_id'];
        $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'student'")->execute([$userId]);
        audit_log($_SESSION['user_id'], 'student_deleted', "User $userId");
        flash('success', 'Student record deleted.');
    } elseif ($action === 'reassign_course') {
        $studentId = (int) $_POST['student_id'];
        $newCourseId = !empty($_POST['course_id']) ? (int) $_POST['course_id'] : null;
        $pdo->prepare("UPDATE students SET course_id = ? WHERE id = ?")->execute([$newCourseId, $studentId]);
        audit_log($_SESSION['user_id'], 'student_course_reassigned', "Student $studentId => Course $newCourseId");
        flash('success', 'Student programme assignment updated.');
    } elseif ($action === 'reassign_batch') {
        $studentId = (int) $_POST['student_id'];
        $newBatchId = !empty($_POST['batch_id']) ? (int) $_POST['batch_id'] : null;
        $pdo->prepare("UPDATE students SET batch_id = ? WHERE id = ?")->execute([$newBatchId, $studentId]);
        audit_log($_SESSION['user_id'], 'student_batch_reassigned', "Student $studentId => Batch $newBatchId");
        flash('success', 'Student batch assignment updated.');
    } elseif ($action === 'change_lifecycle') {
        $studentId = (int) $_POST['student_id'];
        $newLifecycle = in_array($_POST['status'] ?? '', ['registered','active','graduated','withdrawn'], true) ? $_POST['status'] : null;
        if ($newLifecycle) {
            if ($newLifecycle === 'graduated') {
                $pdo->prepare("UPDATE students SET status = ?, graduation_date = COALESCE(graduation_date, CURDATE()) WHERE id = ?")
                    ->execute([$newLifecycle, $studentId]);
            } else {
                $pdo->prepare("UPDATE students SET status = ? WHERE id = ?")->execute([$newLifecycle, $studentId]);
            }
            audit_log($_SESSION['user_id'], 'student_lifecycle_changed', "Student $studentId => $newLifecycle");
            flash('success', 'Student status updated.');
        }
    }
    redirect('/admin/students.php');
}

// --- Search / filter / pagination ---
$search = clean_str($_GET['q'] ?? '');
$courseId = (int) ($_GET['course_id'] ?? 0);
$batchFilter = (int) ($_GET['batch_id'] ?? 0);
$lifecycleFilter = in_array($_GET['status'] ?? '', ['registered','active','graduated','withdrawn'], true) ? $_GET['status'] : '';
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 15;

$where = ["1=1"];
$params = [];
if ($search !== '') {
    $where[] = "(s.first_name LIKE ? OR s.last_name LIKE ? OR s.reg_number LIKE ? OR u.email LIKE ?)";
    array_push($params, "%$search%", "%$search%", "%$search%", "%$search%");
}
if ($courseId) { $where[] = "s.course_id = ?"; $params[] = $courseId; }
if ($batchFilter) { $where[] = "s.batch_id = ?"; $params[] = $batchFilter; }
if ($lifecycleFilter) { $where[] = "s.status = ?"; $params[] = $lifecycleFilter; }
$whereSql = implode(' AND ', $where);

$countStmt = $pdo->prepare("SELECT COUNT(*) c FROM students s JOIN users u ON u.id = s.user_id WHERE $whereSql");
$countStmt->execute($params);
$total = (int) $countStmt->fetch()['c'];
$p = paginate($total, $perPage, $page);

$sql = "SELECT s.*, u.email, u.status AS account_status, u.id AS user_id, c.name AS course_name, b.name AS batch_name
        FROM students s JOIN users u ON u.id = s.user_id
        LEFT JOIN courses c ON c.id = s.course_id
        LEFT JOIN batches b ON b.id = s.batch_id
        WHERE $whereSql ORDER BY s.created_at DESC LIMIT {$p['perPage']} OFFSET {$p['offset']}";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$students = $stmt->fetchAll();

$courses = $pdo->query("SELECT id, name FROM courses ORDER BY name")->fetchAll();
$batches = $pdo->query("SELECT id, name, batch_code FROM batches ORDER BY name")->fetchAll();

$lifecycleBadge = fn($status) => match ($status) {
    'active'    => 'active',
    'graduated' => 'graduated',
    'withdrawn' => 'suspended',
    default     => 'inactive', // registered
};

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <h3 class="section-title">Manage Students</h3>

    <div class="card p-3 mb-3">
      <form class="row g-2" method="get">
        <div class="col-md-4"><input type="text" name="q" class="form-control" placeholder="Search by name, reg. no. or email..." value="<?= e($search) ?>"></div>
        <div class="col-md-2">
          <select name="course_id" class="form-select">
            <option value="">All Courses</option>
            <?php foreach ($courses as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $courseId==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-2">
          <select name="batch_id" class="form-select">
            <option value="">All Batches</option>
            <?php foreach ($batches as $b): ?><option value="<?= (int)$b['id'] ?>" <?= $batchFilter==$b['id']?'selected':'' ?>><?= e($b['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-2">
          <select name="status" class="form-select">
            <option value="">Any Status</option>
            <option value="registered" <?= $lifecycleFilter==='registered'?'selected':'' ?>>Registered</option>
            <option value="active" <?= $lifecycleFilter==='active'?'selected':'' ?>>Active Training</option>
            <option value="graduated" <?= $lifecycleFilter==='graduated'?'selected':'' ?>>Graduated</option>
            <option value="withdrawn" <?= $lifecycleFilter==='withdrawn'?'selected':'' ?>>Withdrawn</option>
          </select>
        </div>
        <div class="col-md-2"><button class="btn btn-gold w-100" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button></div>
      </form>
    </div>

    <div class="card p-4">
      <?php if (!$students): ?>
        <div class="empty-state"><i class="fa-solid fa-user-graduate"></i><p>No students found.</p></div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Reg. No.</th><th>Name</th><th>Programme</th><th>Batch</th><th>Status</th><th>Account</th><th class="text-end">Actions</th></tr></thead>
          <tbody>
          <?php foreach ($students as $s): ?>
            <tr>
              <td><?= e($s['reg_number']) ?></td>
              <td><?= e($s['first_name'].' '.$s['last_name']) ?><div class="small text-muted"><?= e($s['email']) ?></div></td>
              <td><?= e($s['course_name'] ?? '-') ?></td>
              <td>
                <?= e($s['batch_name'] ?? '-') ?>
                <button class="btn btn-sm btn-link p-0 ms-1" data-bs-toggle="modal" data-bs-target="#assignBatch<?= (int)$s['id'] ?>" title="Assign Batch"><i class="fa-solid fa-pen small"></i></button>
              </td>
              <td>
                <span class="badge badge-<?= $lifecycleBadge($s['status']) ?> px-2 py-1"><?= e(ucfirst($s['status'])) ?></span>
                <button class="btn btn-sm btn-link p-0 ms-1" data-bs-toggle="modal" data-bs-target="#changeStatus<?= (int)$s['id'] ?>" title="Change Status"><i class="fa-solid fa-pen small"></i></button>
              </td>
              <td><span class="badge badge-<?= $s['account_status']==='active'?'active':'inactive' ?> px-2 py-1"><?= e(ucfirst($s['account_status'])) ?></span></td>
              <td class="text-end">
                <a href="<?= BASE_URL ?>/admin/student-view.php?id=<?= (int)$s['id'] ?>" class="btn btn-sm btn-outline-secondary" title="View"><i class="fa-solid fa-eye"></i></a>
                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#reassign<?= (int)$s['id'] ?>" title="Assign Programme"><i class="fa-solid fa-diagram-project"></i></button>
                <form method="post" class="d-inline">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="toggle_status">
                  <input type="hidden" name="user_id" value="<?= (int)$s['user_id'] ?>">
                  <input type="hidden" name="new_status" value="<?= $s['account_status']==='active' ? 'inactive' : 'active' ?>">
                  <button type="submit" class="btn btn-sm btn-outline-<?= $s['account_status']==='active' ? 'warning' : 'success' ?>" title="Toggle Account Access">
                    <i class="fa-solid fa-<?= $s['account_status']==='active' ? 'ban' : 'check' ?>"></i>
                  </button>
                </form>
                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#resetPw<?= (int)$s['id'] ?>" title="Reset Password"><i class="fa-solid fa-key"></i></button>
                <form method="post" class="d-inline" data-confirm-delete="Permanently delete this student record?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="user_id" value="<?= (int)$s['user_id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="fa-solid fa-trash"></i></button>
                </form>
              </td>
            </tr>

            <!-- Assign Programme Modal -->
            <div class="modal fade" id="reassign<?= (int)$s['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="reassign_course">
                    <input type="hidden" name="student_id" value="<?= (int)$s['id'] ?>">
                    <div class="modal-header"><h5 class="modal-title">Assign Programme &mdash; <?= e($s['first_name'].' '.$s['last_name']) ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body">
                      <label class="form-label">Programme / Course</label>
                      <select name="course_id" class="form-select">
                        <option value="">Unassigned</option>
                        <?php foreach ($courses as $c): ?>
                          <option value="<?= (int)$c['id'] ?>" <?= (int)($s['course_id'] ?? 0) === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                      </select>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Save</button></div>
                  </form>
                </div>
              </div>
            </div>

            <!-- Assign Batch Modal -->
            <div class="modal fade" id="assignBatch<?= (int)$s['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="reassign_batch">
                    <input type="hidden" name="student_id" value="<?= (int)$s['id'] ?>">
                    <div class="modal-header"><h5 class="modal-title">Assign Batch &mdash; <?= e($s['first_name'].' '.$s['last_name']) ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body">
                      <label class="form-label">Batch / Cohort</label>
                      <select name="batch_id" class="form-select">
                        <option value="">Unassigned</option>
                        <?php foreach ($batches as $b): ?>
                          <option value="<?= (int)$b['id'] ?>" <?= (int)($s['batch_id'] ?? 0) === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?> (<?= e($b['batch_code']) ?>)</option>
                        <?php endforeach; ?>
                      </select>
                      <div class="form-text">Content restricted to a specific batch is only visible to students in that batch.</div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Save</button></div>
                  </form>
                </div>
              </div>
            </div>

            <!-- Change Lifecycle Status Modal -->
            <div class="modal fade" id="changeStatus<?= (int)$s['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="change_lifecycle">
                    <input type="hidden" name="student_id" value="<?= (int)$s['id'] ?>">
                    <div class="modal-header"><h5 class="modal-title">Change Status &mdash; <?= e($s['first_name'].' '.$s['last_name']) ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body">
                      <label class="form-label">Lifecycle Status</label>
                      <select name="status" class="form-select">
                        <option value="registered" <?= $s['status']==='registered'?'selected':'' ?>>Registered</option>
                        <option value="active" <?= $s['status']==='active'?'selected':'' ?>>Active Training</option>
                        <option value="graduated" <?= $s['status']==='graduated'?'selected':'' ?>>Graduated</option>
                        <option value="withdrawn" <?= $s['status']==='withdrawn'?'selected':'' ?>>Withdrawn</option>
                      </select>
                      <div class="form-text">Graduated/Withdrawn students immediately lose access to active training materials and tests, while their historical records remain visible to staff.</div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Save</button></div>
                  </form>
                </div>
              </div>
            </div>

            <!-- Reset Password Modal -->
            <div class="modal fade" id="resetPw<?= (int)$s['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" name="user_id" value="<?= (int)$s['user_id'] ?>">
                    <div class="modal-header"><h5 class="modal-title">Reset Password &mdash; <?= e($s['first_name'].' '.$s['last_name']) ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body">
                      <div class="mb-3">
                        <label class="form-label">New Password</label>
                        <input type="password" name="new_password" class="form-control" minlength="8" required>
                        <div class="form-text">Minimum 8 characters, including letters and numbers.</div>
                      </div>
                      <div class="mb-2">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" name="confirm_password" class="form-control" minlength="8" required>
                      </div>
                      <p class="small text-muted mb-0"><i class="fa-solid fa-shield-halved me-1"></i>The student's current password is never shown and is not recoverable - only replaceable.</p>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Reset Password</button></div>
                  </form>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php if ($p['totalPages'] > 1): ?>
        <nav class="mt-3"><ul class="pagination justify-content-center">
          <?php for ($i=1;$i<=$p['totalPages'];$i++): $qs=$_GET; $qs['page']=$i; ?>
            <li class="page-item <?= $i===$p['currentPage']?'active':'' ?>"><a class="page-link" href="?<?= http_build_query($qs) ?>"><?= $i ?></a></li>
          <?php endfor; ?>
        </ul></nav>
      <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
