<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');
$pageTitle = 'Manage Courses';

$pdo = getDB();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name = clean_str($_POST['name'] ?? '');
        $code = strtoupper(clean_str($_POST['code'] ?? ''));
        $description = clean_str($_POST['description'] ?? '');
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $courseId = (int) ($_POST['id'] ?? 0);

        if ($name === '') {
            $errors[] = 'Course name is required.';
        }

        // Auto-generate the code if the admin left it blank (frontend also
        // suggests one live, but the backend never assumes a code was sent).
        if (!$errors && $code === '') {
            $code = generate_course_code($pdo, $name);
        }

        // Uniqueness is always re-validated server-side, whether the code was
        // auto-generated, hand-typed, or edited on an existing course - never
        // rely on the frontend suggestion alone.
        if (!$errors) {
            $chk = $pdo->prepare("SELECT id FROM courses WHERE code = ? AND id != ?");
            $chk->execute([$code, $courseId]);
            if ($chk->fetch()) {
                $errors[] = "The code \"$code\" is already in use by another course. Please choose a different one.";
            }
        }

        if (!$errors) {
            if ($action === 'add') {
                $pdo->prepare("INSERT INTO courses (name, code, description, is_active) VALUES (?,?,?,?)")
                    ->execute([$name, $code, $description, $isActive]);
                flash('success', "Course added successfully with code $code.");
            } else {
                $pdo->prepare("UPDATE courses SET name=?, code=?, description=?, is_active=? WHERE id=?")
                    ->execute([$name, $code, $description, $isActive, $courseId]);
                flash('success', 'Course updated successfully.');
            }
            audit_log($_SESSION['user_id'], 'course_saved', "$name ($code)");
            redirect('/admin/courses.php');
        }
    } elseif ($action === 'delete') {
        $id = (int) $_POST['id'];
        $pdo->prepare("DELETE FROM courses WHERE id = ?")->execute([$id]);
        audit_log($_SESSION['user_id'], 'course_deleted', "ID: $id");
        flash('success', 'Course deleted.');
        redirect('/admin/courses.php');
    } elseif ($action === 'assign_faculty') {
        $courseId = (int) $_POST['course_id'];
        $facultyIds = array_map('intval', $_POST['faculty_ids'] ?? []);

        $pdo->beginTransaction();
        $pdo->prepare("DELETE FROM faculty_courses WHERE course_id = ?")->execute([$courseId]);
        if ($facultyIds) {
            $ins = $pdo->prepare("INSERT IGNORE INTO faculty_courses (faculty_id, course_id) VALUES (?, ?)");
            foreach ($facultyIds as $fid) {
                $ins->execute([$fid, $courseId]);
            }
        }
        $pdo->commit();
        audit_log($_SESSION['user_id'], 'course_faculty_assigned', "Course ID: $courseId, Faculty: " . implode(',', $facultyIds));
        flash('success', 'Faculty assignment updated.');
        redirect('/admin/courses.php');
    }
}

$courses = $pdo->query("SELECT c.*, (SELECT COUNT(*) FROM students s WHERE s.course_id = c.id) AS student_count
                         FROM courses c ORDER BY c.name")->fetchAll();

$allFaculty = $pdo->query("SELECT f.id, f.first_name, f.last_name FROM faculty f ORDER BY f.first_name")->fetchAll();
$assignedByCourseStmt = $pdo->query("SELECT course_id, faculty_id FROM faculty_courses");
$assignedByCourse = [];
foreach ($assignedByCourseStmt->fetchAll() as $row) {
    $assignedByCourse[$row['course_id']][] = (int) $row['faculty_id'];
}

include __DIR__ . '/../includes/header.php';
?>
<div class="dash-wrapper">
  <?php include __DIR__ . '/../includes/admin-sidebar.php'; ?>
  <div class="dash-content">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="section-title mb-0">Manage Courses / Programmes</h3>
      <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#addCourseModal"><i class="fa-solid fa-plus me-2"></i>Add Course</button>
    </div>

    <?php if ($errors): ?><div class="alert alert-danger"><?= e($errors[0]) ?></div><?php endif; ?>

    <div class="card p-4">
      <?php if (!$courses): ?>
        <div class="empty-state"><i class="fa-solid fa-book"></i><p>No courses added yet.</p></div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Code</th><th>Name</th><th>Students</th><th>Faculty</th><th>Status</th><th class="text-end">Actions</th></tr></thead>
          <tbody>
          <?php foreach ($courses as $c):
            $assignedIds = $assignedByCourse[$c['id']] ?? [];
            $assignedNames = array_filter($allFaculty, fn($f) => in_array((int)$f['id'], $assignedIds, true));
          ?>
            <tr>
              <td><?= e($c['code']) ?></td>
              <td><?= e($c['name']) ?></td>
              <td><?= (int)$c['student_count'] ?></td>
              <td class="small">
                <?php if (!$assignedNames): ?>
                  <span class="text-muted">Unassigned</span>
                <?php else: foreach ($assignedNames as $f): ?>
                  <span class="badge text-bg-light mb-1"><?= e($f['first_name'].' '.$f['last_name']) ?></span>
                <?php endforeach; endif; ?>
              </td>
              <td><span class="badge badge-<?= $c['is_active']?'active':'inactive' ?> px-2 py-1"><?= $c['is_active']?'Active':'Inactive' ?></span></td>
              <td class="text-end">
                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#assignFaculty<?= $c['id'] ?>" title="Assign Faculty"><i class="fa-solid fa-chalkboard-user"></i></button>
                <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#editCourse<?= $c['id'] ?>"><i class="fa-solid fa-pen"></i></button>
                <form method="post" class="d-inline" data-confirm-delete="Delete this course? Students assigned to it will keep their record but lose the course link.">
                  <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></button>
                </form>
              </td>
            </tr>
            <!-- Assign Faculty Modal -->
            <div class="modal fade" id="assignFaculty<?= $c['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="assign_faculty">
                    <input type="hidden" name="course_id" value="<?= (int)$c['id'] ?>">
                    <div class="modal-header"><h5 class="modal-title">Assign Faculty &mdash; <?= e($c['name']) ?></h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body">
                      <?php if (!$allFaculty): ?>
                        <p class="text-muted small mb-0">No faculty members exist yet. Add one under Faculty first.</p>
                      <?php else: foreach ($allFaculty as $f): ?>
                        <div class="form-check mb-2">
                          <input type="checkbox" class="form-check-input" name="faculty_ids[]" value="<?= (int)$f['id'] ?>" id="fac<?= $c['id'] ?>_<?= $f['id'] ?>"
                            <?= in_array((int)$f['id'], $assignedIds, true) ? 'checked' : '' ?>>
                          <label class="form-check-label" for="fac<?= $c['id'] ?>_<?= $f['id'] ?>"><?= e($f['first_name'].' '.$f['last_name']) ?></label>
                        </div>
                      <?php endforeach; endif; ?>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Save Assignment</button></div>
                  </form>
                </div>
              </div>
            </div>
            <!-- Edit Modal -->
            <div class="modal fade" id="editCourse<?= $c['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                    <div class="modal-header"><h5 class="modal-title">Edit Course</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body">
                      <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" class="form-control" value="<?= e($c['name']) ?>" required></div>
                      <div class="mb-3"><label class="form-label">Code</label><input type="text" name="code" class="form-control" value="<?= e($c['code']) ?>" required></div>
                      <div class="mb-3"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="3"><?= e($c['description']) ?></textarea></div>
                      <div class="form-check"><input type="checkbox" name="is_active" class="form-check-input" <?= $c['is_active']?'checked':'' ?>><label class="form-check-label">Active</label></div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Save</button></div>
                  </form>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="modal fade" id="addCourseModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post" id="addCourseForm">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <div class="modal-header"><h5 class="modal-title">Add Course</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" id="addCourseName" class="form-control" required></div>
          <div class="mb-3">
            <label class="form-label">Course Code</label>
            <div class="input-group">
              <input type="text" name="code" id="addCourseCode" class="form-control text-uppercase" placeholder="Auto-generated from the name">
              <button type="button" class="btn btn-outline-secondary" id="generateCodeBtn"><i class="fa-solid fa-wand-magic-sparkles me-1"></i>Generate</button>
            </div>
            <div class="form-text">Leave blank to auto-generate a unique code, or type your own. You can edit it anytime before saving.</div>
          </div>
          <div class="mb-3"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="3"></textarea></div>
          <div class="form-check"><input type="checkbox" name="is_active" class="form-check-input" checked><label class="form-check-label">Active</label></div>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-gold">Add Course</button></div>
      </form>
    </div>
  </div>
</div>
<script>
document.getElementById('generateCodeBtn')?.addEventListener('click', async () => {
  const name = document.getElementById('addCourseName').value.trim();
  if (!name) { App.toast('Enter a course name first.', 'warning'); return; }
  try {
    const res = await fetch('<?= BASE_URL ?>/ajax/suggest_course_code.php?name=' + encodeURIComponent(name), { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
    const data = await res.json();
    if (data.success) {
      document.getElementById('addCourseCode').value = data.code;
    } else {
      App.toast(data.message || 'Could not generate a code.', 'error');
    }
  } catch (e) {
    App.toast('Network error while generating the code.', 'error');
  }
});
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
