<?php
require_once __DIR__ . '/config/config.php';
$pageTitle = 'About Us';
include __DIR__ . '/includes/header.php';
?>
<div class="container py-5">
  <h1 class="section-title">About ROS RCCG</h1>
  <div class="row g-5 align-items-center">
    <div class="col-lg-7">
      <p>ROS RCCG is committed to raising well-equipped ministers and church workers through structured, accessible
        training programmes. Our Student Registration and Faculty Learning Management Portal brings registration,
        course materials, and communication together in one secure, easy-to-use platform.</p>
      <p>Students can register for programmes, access learning materials uploaded by our faculty, and stay informed
        through announcements &mdash; all from any device. Faculty members can manage their course content, track
        engagement, and communicate directly with students.</p>
      <ul class="list-unstyled mt-4">
        <li class="mb-2"><i class="fa-solid fa-circle-check text-gold me-2"></i>Structured academic and training sessions</li>
        <li class="mb-2"><i class="fa-solid fa-circle-check text-gold me-2"></i>Secure, role-based digital learning environment</li>
        <li class="mb-2"><i class="fa-solid fa-circle-check text-gold me-2"></i>Dedicated support for students and faculty</li>
      </ul>
    </div>
    <div class="col-lg-5">
      <div class="feature-card p-4 mb-4">
        <h5 class="mb-3"><i class="fa-solid fa-bullseye text-gold me-2"></i>Our Mission</h5>
        <p class="text-muted">To provide excellent, accessible ministry training supported by modern technology,
          empowering every student to grow in knowledge and service.</p>
      </div>
      <div class="feature-card p-4 text-center">
        <div class="icon-wrap mx-auto mb-3"><i class="fa-solid fa-people-roof"></i></div>
        <h5 class="mb-2">Meet Our Leadership</h5>
        <p class="text-muted mb-3">Get to know our General Overseer, Parish Pastor, and their wives.</p>
        <a href="<?= BASE_URL ?>/leadership.php" class="btn btn-gold"><i class="fa-solid fa-arrow-right me-2"></i>View Leadership</a>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
