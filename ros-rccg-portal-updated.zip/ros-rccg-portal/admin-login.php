<?php
require_once __DIR__ . '/config/config.php';
$pageTitle = 'Administrator Login';

if (is_logged_in() && $_SESSION['user_role'] === 'admin') {
    redirect('/admin/dashboard.php');
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $email = clean_str($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Please enter both email and password.';
    } else {
        $result = attempt_login($email, $password, 'admin');
        if ($result['success']) {
            redirect('/admin/dashboard.php');
        }
        $error = $result['message'];
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="auth-wrapper">
  <div class="auth-card">
    <div class="row g-0">
      <div class="col-lg-5 auth-side d-flex flex-column justify-content-center">
        <i class="fa-solid fa-shield-halved fa-3x text-gold mb-3"></i>
        <h3>Administrator</h3>
        <p class="opacity-75">Manage students, faculty, courses, materials and system settings.</p>
      </div>
      <div class="col-lg-7 auth-form">
        <h4 class="mb-4">Admin Login</h4>
        <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
        <form method="post" novalidate>
          <?= csrf_field() ?>
          <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" class="form-control" required autofocus>
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <button type="submit" class="btn btn-gold w-100"><i class="fa-solid fa-right-to-bracket me-2"></i>Login</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
