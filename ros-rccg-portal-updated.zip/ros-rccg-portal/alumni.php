<?php
require_once __DIR__ . '/config/config.php';
$pageTitle = 'Alumni';

$pdo = getDB();

$search = clean_str($_GET['q'] ?? '');
$courseId = (int) ($_GET['course_id'] ?? 0);
$year = (int) ($_GET['year'] ?? 0);
$page = max(1, (int) ($_GET['page'] ?? 1));

// Alumni are never a separate database record - this is simply every
// student whose status is 'graduated' (and who the admin has left visible
// via show_in_alumni). New graduates appear here automatically the moment
// their status changes; nothing needs to be re-entered.
$result = get_alumni($pdo, [
    'search'      => $search,
    'course_id'   => $courseId,
    'year'        => $year,
    'public_only' => true,
    'per_page'    => 12,
    'page'        => $page,
]);
$graduates = $result['rows'];
$p = $result['pagination'];

$courses = $pdo->query("SELECT id, name FROM courses ORDER BY name")->fetchAll();
$years = get_alumni_years($pdo, true);

include __DIR__ . '/includes/header.php';
?>
<div class="container py-5">
  <h1 class="section-title text-center mx-auto" style="border-left:none; border-top:4px solid var(--gold); display:inline-block; padding-left:0; padding-top:10px;">Our Alumni</h1>
  <p class="text-center text-muted col-lg-7 mx-auto mb-4">Celebrating graduates of ROS RCCG's training programmes, now serving in ministry and beyond.</p>

  <div class="card p-3 mb-4">
    <form class="row g-2" method="get">
      <div class="col-md-4"><input type="text" name="q" class="form-control" placeholder="Search by name..." value="<?= e($search) ?>"></div>
      <div class="col-md-3">
        <select name="course_id" class="form-select">
          <option value="">All Programmes</option>
          <?php foreach ($courses as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $courseId==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3">
        <select name="year" class="form-select">
          <option value="">All Years</option>
          <?php foreach ($years as $y): ?><option value="<?= (int)$y ?>" <?= $year==$y?'selected':'' ?>><?= (int)$y ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2"><button class="btn btn-gold w-100" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button></div>
    </form>
  </div>

  <?php if (!$graduates): ?>
    <div class="empty-state"><i class="fa-solid fa-user-graduate"></i><p>No graduates found<?= ($search || $courseId || $year) ? ' for this filter.' : ' yet.' ?></p></div>
  <?php else: ?>
  <p class="text-muted small mb-3"><?= (int)$result['total'] ?> graduate<?= $result['total']==1?'':'s' ?> found</p>
  <div class="row g-4">
    <?php foreach ($graduates as $g): ?>
      <div class="col-6 col-md-4 col-lg-3">
        <div class="feature-card p-3 h-100 text-center d-flex flex-column">
          <?php if ($g['passport_photo']): ?>
            <img src="<?= BASE_URL ?>/media.php?type=alumni&id=<?= (int)$g['id'] ?>" class="rounded-circle mx-auto mb-3" style="width:90px;height:90px;object-fit:cover;" alt="<?= e($g['first_name'].' '.$g['last_name']) ?>">
          <?php else: ?>
            <i class="fa-solid fa-circle-user fa-5x text-secondary mb-3"></i>
          <?php endif; ?>
          <h6 class="mb-1"><?= e($g['first_name'].' '.$g['last_name']) ?></h6>
          <p class="text-gold small fw-semibold mb-1"><?= e($g['course_name'] ?? 'Ministry Training') ?></p>
          <?php if ($g['graduation_date']): ?>
            <p class="text-muted small mb-0">Class of <?= date('Y', strtotime($g['graduation_date'])) ?></p>
          <?php endif; ?>
          <?php if ($g['batch_name']): ?>
            <p class="text-muted small mb-0"><?= e($g['batch_name']) ?></p>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <?php if ($p['totalPages'] > 1): ?>
    <nav class="mt-4"><ul class="pagination justify-content-center">
      <?php for ($i=1;$i<=$p['totalPages'];$i++): $qs=$_GET; $qs['page']=$i; ?>
        <li class="page-item <?= $i===$p['currentPage']?'active':'' ?>"><a class="page-link" href="?<?= http_build_query($qs) ?>"><?= $i ?></a></li>
      <?php endfor; ?>
    </ul></nav>
  <?php endif; ?>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
