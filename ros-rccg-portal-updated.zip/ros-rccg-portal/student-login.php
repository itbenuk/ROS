<?php
require_once __DIR__ . '/config/config.php';
$pageTitle = 'Student Login';

if (is_logged_in() && $_SESSION['user_role'] === 'student') {
    redirect('/student/dashboard.php');
}

$error = null;
if (!empty($_GET['expired'])) {
    $error = 'Your session expired. Please log in again.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_or_die();
    $email = clean_str($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Please enter both email and password.';
    } else {
        $result = attempt_login($email, $password, 'student');
        if ($result['success']) {
            redirect('/student/dashboard.php');
        }
        $error = $result['message'];
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="auth-wrapper">
  <div class="auth-card">
    <div class="row g-0">
      <div class="col-lg-5 auth-side d-flex flex-column justify-content-center">
        <i class="fa-solid fa-graduation-cap fa-3x text-gold mb-3"></i>
        <h3>Student Portal</h3>
        <p class="opacity-75">Access your learning materials, track announcements, and manage your registration.</p>
      </div>
      <div class="col-lg-7 auth-form">
        <h4 class="mb-4">Welcome Back</h4>
        <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
        <form method="post" novalidate>
          <?= csrf_field() ?>
          <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" class="form-control" required autofocus>
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <div class="d-flex justify-content-between mb-3">
            <a href="<?= BASE_URL ?>/forgot-password.php?role=student" class="small">Forgot Password?</a>
          </div>
          <button type="submit" class="btn btn-gold w-100"><i class="fa-solid fa-right-to-bracket me-2"></i>Login</button>
          <p class="mt-3 mb-0 text-center">New student? <a href="<?= BASE_URL ?>/student-register.php">Register here</a></p>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
